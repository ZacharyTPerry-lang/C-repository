/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * boundary_crossing_vocabulary.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : boundary_crossing_system
 *
 * Purpose       : The single instance of the boundary crossing vocabulary. This
 *                 file IS the set of permitted crossing kinds. To add a kind,
 *                 edit the table below and nothing else in the tool changes.
 *
 * Portability   : C99. Static const data.
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "boundary_crossing_vocabulary.h"

#include <string.h>

/* ===========================================================================
 * THE CROSSING KINDS
 * ===========================================================================
 *
 *  Each row is one kind of crossing the boundary permits, with the modality
 *  that decides what an absent declaration means and how a crossing of the
 *  kind is discovered.
 *
 *  The three State Gate kinds are CHOSEN and DECLARED_ONLY: the developer
 *  selects one build-wide state, and a symbol crossing under it is declared,
 *  not discovered. Full isolation is the default and needs no keyword -- a
 *  symbol simply absent from the whitelist does not cross -- so it is not a row
 *  here; it is the absence of a row.
 *
 *  The reverse-dependency kind is COMPELLED and discovered from the vendor
 *  object's undefined symbols. Its absence is an error, because the linker will
 *  bind the crossing whether or not it was declared.
 *
 * ===========================================================================*/

static const BoundaryCrossingKind boundary_crossing_kinds[] = {
        /* State A : the project's macro value crosses into vendor space. The
         * developer chooses this; a symbol declared under it carries the
         * project value ahead of the vendor header. */
        { "PROJECT_VALUE_SUPERSEDES",
          BOUNDARY_CROSSING_MODALITY_CHOSEN,
          BOUNDARY_CROSSING_DISCOVERY_DECLARED_ONLY },

        /* State B : the vendor's macro value crosses into project space under
         * the project prefix. The developer chooses this; a declared symbol is
         * read by project code through its prefixed alias. */
        { "VENDOR_VALUE_SUPERSEDES",
          BOUNDARY_CROSSING_MODALITY_CHOSEN,
          BOUNDARY_CROSSING_DISCOVERY_DECLARED_ONLY },

        /* Reverse dependency : the vendor's compiled object demands a project
         * symbol. Compelled -- the linker binds it regardless -- so an
         * undeclared instance is a build error. Discovered as an undefined
         * symbol in the vendor object. */
        { "VENDOR_LINKS_PROJECT",
          BOUNDARY_CROSSING_MODALITY_COMPELLED,
          BOUNDARY_CROSSING_DISCOVERY_VENDOR_UNDEFINED_SYMBOL }
};

static const BoundaryCrossingVocabulary boundary_crossing_vocabulary = {
        boundary_crossing_kinds,
        sizeof(boundary_crossing_kinds)
                / sizeof(boundary_crossing_kinds[0])
};

/* ===========================================================================
 * ACCESS
 * ===========================================================================*/

const BoundaryCrossingVocabulary *boundary_crossing_vocabulary_get(void)
{
        return &boundary_crossing_vocabulary;
}

const BoundaryCrossingKind *boundary_crossing_kind_by_keyword(const char *keyword)
{
        size_t index;
        for (index = 0; index < boundary_crossing_vocabulary.kind_count; index++) {
                if (strcmp(boundary_crossing_kinds[index].keyword, keyword) == 0) {
                        return &boundary_crossing_kinds[index];
                }
        }
        return NULL;
}

const BoundaryCrossingKind *boundary_crossing_kind_for_discovery(
        BoundaryCrossingDiscovery discovery)
{
        size_t index;
        for (index = 0; index < boundary_crossing_vocabulary.kind_count; index++) {
                if (boundary_crossing_kinds[index].discovery == discovery) {
                        return &boundary_crossing_kinds[index];
                }
        }
        return NULL;
}
