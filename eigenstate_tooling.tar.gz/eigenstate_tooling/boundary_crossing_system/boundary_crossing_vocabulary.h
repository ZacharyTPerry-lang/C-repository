/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * boundary_crossing_vocabulary.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : boundary_crossing_system
 *
 * Purpose       : Define, as DATA, the kinds of crossing permitted at the
 *                 boundary between project code and vendor code. A crossing
 *                 kind is a named category with a MODALITY that determines what
 *                 an absent declaration means. This header declares the shape;
 *                 the paired source holds the one instance.
 *
 * The two modalities (the distinction that makes this its own axis, separate
 * from the macro-value State Gate):
 *
 *   CHOSEN     the developer selects this crossing; absence falls to a
 *              default. The State Gate lives here: a symbol may cross with the
 *              project value, the vendor value, or not at all, and if the
 *              whitelist says nothing the default (full isolation) applies. An
 *              instruction the developer issues.
 *
 *   COMPELLED  the crossing is a fact the toolchain proves; absence is an
 *              ERROR. A reverse dependency lives here: the vendor's compiled
 *              object demands a project symbol, the linker will bind it whether
 *              or not anyone intended it, and if the developer has not written
 *              it down the build stops. An acknowledgement the developer is
 *              required to make.
 *
 * Why a modality column and not two engines : the enforcement engine reads the
 * modality and branches on it -- chosen-absent falls to default, compelled-
 * absent errors. Adding a crossing kind is a data entry; the engine does not
 * grow a case. This is the same grammar-as-data discipline the parameter
 * contract vocabulary uses, applied to crossings.
 *
 * Portability   : C99. Freestanding: depends only on <stddef.h>. Static data.
 *
 * Table of contents:
 *   [1] MODALITY
 *   [2] CROSSING KIND
 *   [3] VOCABULARY ACCESS
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef BOUNDARY_CROSSING_VOCABULARY_H
#define BOUNDARY_CROSSING_VOCABULARY_H

#include <stddef.h>

/* ===========================================================================
 * [1] MODALITY
 * ===========================================================================
 *
 *  What an absent declaration means for a crossing kind. This is the property
 *  that separates a chosen behavior from a compelled fact, and it is read by
 *  the enforcement engine rather than hard-coded per kind.
 *
 * ===========================================================================*/

typedef enum BoundaryCrossingModality {
        /* Developer selects; absence falls to the kind's default. */
        BOUNDARY_CROSSING_MODALITY_CHOSEN,

        /* Toolchain proves; absence is a build error. */
        BOUNDARY_CROSSING_MODALITY_COMPELLED
} BoundaryCrossingModality;

/* Where a crossing of this kind is discovered. The enforcement engine consults
 * this to know which toolchain output to compare a declaration against. */
typedef enum BoundaryCrossingDiscovery {
        /* Not discovered by inspection; selected purely by the developer. The
         * State Gate kinds are declared, not found. */
        BOUNDARY_CROSSING_DISCOVERY_DECLARED_ONLY,

        /* Discovered as an undefined symbol in a vendor object's symbol table
         * (nm 'U'). The reverse-dependency kind is found this way. */
        BOUNDARY_CROSSING_DISCOVERY_VENDOR_UNDEFINED_SYMBOL
} BoundaryCrossingDiscovery;

/* ===========================================================================
 * [2] CROSSING KIND
 * ===========================================================================
 *
 *  One named category of crossing.
 *
 * ---------------------------------------------------------------------------
 *  keyword        the token that names this kind in a whitelist declaration
 *                 (e.g. "VENDOR_LINKS_PROJECT", "PROJECT_VALUE_SUPERSEDES")
 *  modality       chosen or compelled: what absence means
 *  discovery      how a crossing of this kind is found, if at all
 * ---------------------------------------------------------------------------*/

typedef struct BoundaryCrossingKind {
        const char               *keyword;
        BoundaryCrossingModality  modality;
        BoundaryCrossingDiscovery discovery;
} BoundaryCrossingKind;

typedef struct BoundaryCrossingVocabulary {
        const BoundaryCrossingKind *kinds;
        size_t                      kind_count;
} BoundaryCrossingVocabulary;

/* ===========================================================================
 * [3] VOCABULARY ACCESS
 * ===========================================================================*/

/* ---------------------------------------------------------------------------
 *  Operation : boundary_crossing_vocabulary_get
 *
 *  Return the single static vocabulary instance. Static storage; not freed,
 *  not modified by the caller.
 *
 *  OUT return  VALID  POPULATE  ALWAYS  KEEP  NONE  the static vocabulary
 * ---------------------------------------------------------------------------*/
const BoundaryCrossingVocabulary *boundary_crossing_vocabulary_get(void);

/* ---------------------------------------------------------------------------
 *  Operation : boundary_crossing_kind_by_keyword
 *
 *  Look up a crossing kind by its declaration keyword. Returns a pointer to the
 *  static kind, or NULL if no kind uses that keyword.
 *
 *  IN  keyword  VALID  CONSUME  ALWAYS  KEEP  NONE  keyword to look up
 * ---------------------------------------------------------------------------*/
const BoundaryCrossingKind *boundary_crossing_kind_by_keyword(const char *keyword);

/* ---------------------------------------------------------------------------
 *  Operation : boundary_crossing_kind_for_discovery
 *
 *  Return the crossing kind whose discovery mechanism matches the given one, or
 *  NULL if none does. Lets the discovery pass find which kind a nm-discovered
 *  crossing belongs to without hard-coding the keyword.
 *
 *  IN  discovery  VALID  CONSUME  ALWAYS  NONE  NONE  discovery mechanism
 * ---------------------------------------------------------------------------*/
const BoundaryCrossingKind *boundary_crossing_kind_for_discovery(
        BoundaryCrossingDiscovery discovery);

#endif /* BOUNDARY_CROSSING_VOCABULARY_H */
