/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * boundary_crossing_enforcement.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : boundary_crossing_system
 *
 * Purpose       : Implementation of whitelist parsing and the modality
 *                 enforcement rule.
 *
 * Portability   : C99 plus stdio for reading the whitelist file.
 *
 * Table of contents:
 *   [1] TABLE GROWTH
 *   [2] LINE PARSING
 *   [3] LOADING
 *   [4] ENFORCEMENT
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "boundary_crossing_enforcement.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===========================================================================
 * [1] TABLE GROWTH
 * ===========================================================================*/

static void declared_crossing_table_initialize_empty(DeclaredCrossingTable *table)
{
        table->name_storage        = NULL;
        table->name_storage_length = 0;
        table->storage_capacity    = 0;
        table->entry_kinds         = NULL;
        table->entry_name_offsets  = NULL;
        table->entry_count         = 0;
        table->entry_capacity      = 0;
}

/* Returns nonzero on success, zero on allocation failure. */
static int declared_crossing_table_append(DeclaredCrossingTable      *table,
                                          const BoundaryCrossingKind *kind,
                                          const char                 *symbol,
                                          size_t                      symbol_length)
{
        size_t needed = table->name_storage_length + symbol_length + 1;
        if (needed > table->storage_capacity) {
                size_t new_capacity = table->storage_capacity == 0
                                    ? 256 : table->storage_capacity * 2;
                while (new_capacity < needed) {
                        new_capacity *= 2;
                }
                char *grown = realloc(table->name_storage, new_capacity);
                if (grown == NULL) {
                        return 0;
                }
                table->name_storage     = grown;
                table->storage_capacity = new_capacity;
        }

        if (table->entry_count + 1 > table->entry_capacity) {
                size_t new_capacity = table->entry_capacity == 0
                                    ? 16 : table->entry_capacity * 2;
                const BoundaryCrossingKind **grown_kinds =
                        realloc(table->entry_kinds,
                                new_capacity * sizeof(*grown_kinds));
                if (grown_kinds == NULL) {
                        return 0;
                }
                table->entry_kinds = grown_kinds;
                size_t *grown_offsets =
                        realloc(table->entry_name_offsets,
                                new_capacity * sizeof(size_t));
                if (grown_offsets == NULL) {
                        return 0;
                }
                table->entry_name_offsets = grown_offsets;
                table->entry_capacity     = new_capacity;
        }

        table->entry_kinds[table->entry_count]        = kind;
        table->entry_name_offsets[table->entry_count] =
                table->name_storage_length;
        memcpy(table->name_storage + table->name_storage_length,
               symbol, symbol_length);
        table->name_storage[table->name_storage_length + symbol_length] = '\0';
        table->name_storage_length += symbol_length + 1;
        table->entry_count         += 1;
        return 1;
}

/* ===========================================================================
 * [2] LINE PARSING
 * ===========================================================================
 *
 *  A declaration line is KEYWORD(symbol) with optional surrounding space. The
 *  parser splits it into keyword and symbol, both as NUL-terminated substrings
 *  of the line buffer. Returns nonzero on a well-formed line, zero otherwise.
 *  A blank or comment line is signaled separately by the caller before this is
 *  called.
 *
 * ===========================================================================*/

static char *skip_space(char *cursor)
{
        while (*cursor == ' ' || *cursor == '\t') {
                cursor++;
        }
        return cursor;
}

static int parse_declaration_line(char  *line,
                                  char **keyword_out,
                                  char **symbol_out)
{
        /* trim trailing newline and spaces */
        size_t length = strlen(line);
        while (length > 0
               && (line[length - 1] == '\n' || line[length - 1] == '\r'
                || line[length - 1] == ' '  || line[length - 1] == '\t')) {
                line[--length] = '\0';
        }

        char *cursor = skip_space(line);

        /* keyword: run up to '(' or space */
        *keyword_out = cursor;
        while (*cursor != '\0' && *cursor != '(' && *cursor != ' '
               && *cursor != '\t') {
                cursor++;
        }
        if (*cursor == '\0') {
                return 0; /* no '(' : not a declaration */
        }
        char *keyword_end = cursor;
        cursor = skip_space(cursor);
        if (*cursor != '(') {
                return 0;
        }
        *keyword_end = '\0';
        cursor++; /* past '(' */

        cursor = skip_space(cursor);
        *symbol_out = cursor;
        while (*cursor != '\0' && *cursor != ')' && *cursor != ' '
               && *cursor != '\t') {
                cursor++;
        }
        if (*cursor == '\0') {
                return 0; /* no ')' */
        }
        char *symbol_end = cursor;
        cursor = skip_space(cursor);
        if (*cursor != ')') {
                return 0;
        }
        *symbol_end = '\0';

        if (**keyword_out == '\0' || **symbol_out == '\0') {
                return 0; /* empty keyword or symbol */
        }
        return 1;
}

/* ===========================================================================
 * [3] LOADING
 * ===========================================================================*/

static int gate_line_is_blank_or_comment(const char *line)
{
        const char *cursor = line;
        while (*cursor == ' ' || *cursor == '\t') {
                cursor++;
        }
        return *cursor == '\0' || *cursor == '\n' || *cursor == '\r'
            || *cursor == '#';
}

WhitelistLoadResult declared_crossing_table_load(
        const char            *whitelist_path,
        DeclaredCrossingTable *table_out,
        size_t                *malformed_line_number_out)
{
        declared_crossing_table_initialize_empty(table_out);

        FILE *file = fopen(whitelist_path, "r");
        if (file == NULL) {
                return WHITELIST_LOAD_FILE_NOT_FOUND;
        }

        char                line_buffer[4096];
        size_t              line_number = 0;
        WhitelistLoadResult result      = WHITELIST_LOAD_OK;

        while (fgets(line_buffer, sizeof(line_buffer), file) != NULL) {
                line_number++;
                if (gate_line_is_blank_or_comment(line_buffer)) {
                        continue;
                }

                char *keyword;
                char *symbol;
                if (!parse_declaration_line(line_buffer, &keyword, &symbol)) {
                        result = WHITELIST_LOAD_MALFORMED_LINE;
                        break;
                }

                const BoundaryCrossingKind *kind =
                        boundary_crossing_kind_by_keyword(keyword);
                if (kind == NULL) {
                        result = WHITELIST_LOAD_MALFORMED_LINE;
                        break;
                }

                if (!declared_crossing_table_append(table_out, kind, symbol,
                                                    strlen(symbol))) {
                        result = WHITELIST_LOAD_OUT_OF_MEMORY;
                        break;
                }
        }

        fclose(file);

        if (result != WHITELIST_LOAD_OK) {
                if (result == WHITELIST_LOAD_MALFORMED_LINE
                    && malformed_line_number_out != NULL) {
                        *malformed_line_number_out = line_number;
                }
                declared_crossing_table_release(table_out);
                return result;
        }

        return WHITELIST_LOAD_OK;
}

void declared_crossing_table_release(DeclaredCrossingTable *table)
{
        free(table->name_storage);
        free(table->entry_kinds);
        free(table->entry_name_offsets);
        declared_crossing_table_initialize_empty(table);
}

/* ===========================================================================
 * [4] ENFORCEMENT
 * ===========================================================================*/

static int declared_crossing_table_contains(const DeclaredCrossingTable *table,
                                            const BoundaryCrossingKind  *kind,
                                            const char                  *symbol)
{
        size_t index;
        for (index = 0; index < table->entry_count; index++) {
                if (table->entry_kinds[index] != kind) {
                        continue;
                }
                const char *declared_symbol =
                        table->name_storage + table->entry_name_offsets[index];
                if (strcmp(declared_symbol, symbol) == 0) {
                        return 1;
                }
        }
        return 0;
}

CrossingVerdict boundary_crossing_enforce(const DeclaredCrossingTable *table,
                                          const BoundaryCrossingKind  *kind,
                                          const char                  *symbol)
{
        if (declared_crossing_table_contains(table, kind, symbol)) {
                return CROSSING_VERDICT_PERMITTED;
        }
        if (kind->modality == BOUNDARY_CROSSING_MODALITY_COMPELLED) {
                return CROSSING_VERDICT_UNDECLARED_COMPELLED;
        }
        return CROSSING_VERDICT_PERMITTED;
}

int declared_crossing_table_declares_symbol(const DeclaredCrossingTable *table,
                                            const char                  *symbol)
{
        size_t index;
        for (index = 0; index < table->entry_count; index++) {
                const char *declared =
                        table->name_storage + table->entry_name_offsets[index];
                if (strcmp(declared, symbol) == 0) {
                        return 1;
                }
        }
        return 0;
}
