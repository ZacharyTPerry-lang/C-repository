/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * boundary_crossing_enforcement.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : boundary_crossing_system
 *
 * Purpose       : Hold the developer's declared crossings (parsed from a
 *                 whitelist) and enforce the modality rule against a discovered
 *                 crossing: a chosen crossing absent from the whitelist falls
 *                 to its default; a compelled crossing absent from the
 *                 whitelist is a build error naming the symbol.
 *
 * Separation    : this module does not DISCOVER crossings and does not decide
 *                 how a crossing is realized in emitted code. Discovery (which
 *                 vendor symbol is undefined, which macro the vendor defines)
 *                 belongs to the discovery pass; realization (prefixing,
 *                 injection, adapter routing) belongs to the rewriter. This
 *                 module answers one question: given a crossing that exists, is
 *                 it permitted, and if not, what is the verdict.
 *
 * Whitelist form: one declaration per line, a crossing keyword followed by a
 *                 parenthesized symbol name:
 *
 *                   VENDOR_LINKS_PROJECT(project_allocator)
 *                   VENDOR_VALUE_SUPERSEDES(BLAKE3_OUT_LEN)
 *
 *                 Blank lines and lines beginning with '#' are ignored. The
 *                 keyword must name a kind in the crossing vocabulary; an
 *                 unknown keyword is a malformed whitelist, not a silent skip.
 *
 * Portability   : C99 for parsing and enforcement. The whitelist is read from a
 *                 file, so the load call uses stdio.
 *
 * Table of contents:
 *   [1] DECLARED CROSSING TABLE
 *   [2] WHITELIST LOADING
 *   [3] ENFORCEMENT
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef BOUNDARY_CROSSING_ENFORCEMENT_H
#define BOUNDARY_CROSSING_ENFORCEMENT_H

#include <stddef.h>
#include "boundary_crossing_vocabulary.h"

/* ===========================================================================
 * [1] DECLARED CROSSING TABLE
 * ===========================================================================
 *
 *  The set of crossings the developer has written down. Each entry pairs a
 *  crossing kind with the symbol name it was declared for. Stored as parallel
 *  growth like the symbol set: a contiguous name block plus an array of
 *  (kind, name-offset) records.
 *
 * ---------------------------------------------------------------------------
 *  name_storage        contiguous NUL-terminated symbol names
 *  name_storage_length bytes used
 *  storage_capacity    bytes allocated
 *  entry_kinds         crossing kind per declared entry
 *  entry_name_offsets  offset into name_storage per declared entry
 *  entry_count         number of declarations
 *  entry_capacity      allocated entries
 * ---------------------------------------------------------------------------*/

typedef struct DeclaredCrossingTable {
        char                         *name_storage;
        size_t                        name_storage_length;
        size_t                        storage_capacity;
        const BoundaryCrossingKind  **entry_kinds;
        size_t                       *entry_name_offsets;
        size_t                        entry_count;
        size_t                        entry_capacity;
} DeclaredCrossingTable;

/* ===========================================================================
 * [2] WHITELIST LOADING
 * ===========================================================================*/

typedef enum WhitelistLoadResult {
        WHITELIST_LOAD_OK,

        /* The whitelist file could not be opened. */
        WHITELIST_LOAD_FILE_NOT_FOUND,

        /* A line used a keyword that names no crossing kind, or was not in the
         * KEYWORD(symbol) shape. Reported rather than skipped so a typo in a
         * declaration cannot silently drop an intended crossing. */
        WHITELIST_LOAD_MALFORMED_LINE,

        WHITELIST_LOAD_OUT_OF_MEMORY
} WhitelistLoadResult;

/* ---------------------------------------------------------------------------
 *  Operation : declared_crossing_table_load
 *
 *  Parse a whitelist file into a freshly initialized table. On any non-OK
 *  result the table is released internally and left empty. On a malformed
 *  line, malformed_line_number_out (if not NULL) receives the 1-based line.
 *
 *  IN   whitelist_path             VALID    CONSUME   ALWAYS      KEEP  NONE
 *  OUT  table_out                  GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE
 *  OUT  malformed_line_number_out  GARBAGE  POPULATE  IF_FAILURE  KEEP  NONE
 * ---------------------------------------------------------------------------*/
WhitelistLoadResult declared_crossing_table_load(
        const char            *whitelist_path,
        DeclaredCrossingTable *table_out,
        size_t                *malformed_line_number_out);

/* ---------------------------------------------------------------------------
 *  Operation : declared_crossing_table_release
 *
 *  Free a table and reset it to empty. Safe on an empty table.
 *
 *  IN  table  VALID  MUTATE  ALWAYS  GIVE  NONE  table to release
 * ---------------------------------------------------------------------------*/
void declared_crossing_table_release(DeclaredCrossingTable *table);

/* ===========================================================================
 * [3] ENFORCEMENT
 * ===========================================================================*/

/* The verdict for one discovered crossing. */
typedef enum CrossingVerdict {
        /* The crossing is declared, or is chosen and absence is fine: proceed. */
        CROSSING_VERDICT_PERMITTED,

        /* The crossing is compelled and was not declared: build error. */
        CROSSING_VERDICT_UNDECLARED_COMPELLED
} CrossingVerdict;

/* ---------------------------------------------------------------------------
 *  Operation : boundary_crossing_enforce
 *
 *  Given a crossing that has been discovered -- a kind plus the symbol it
 *  applies to -- return the verdict. The rule is read from the kind's modality:
 *
 *    declared in the table              -> PERMITTED
 *    not declared, modality CHOSEN       -> PERMITTED (falls to default)
 *    not declared, modality COMPELLED     -> UNDECLARED_COMPELLED
 *
 *  The engine does not name the kinds; it reads modality from the kind it is
 *  handed. Adding a crossing kind does not change this function.
 *
 *  IN  table    VALID  CONSUME  ALWAYS  KEEP  NONE  the declared crossings
 *  IN  kind     VALID  CONSUME  ALWAYS  KEEP  NONE  the discovered kind
 *  IN  symbol   VALID  CONSUME  ALWAYS  KEEP  NONE  the symbol it applies to
 * ---------------------------------------------------------------------------*/
CrossingVerdict boundary_crossing_enforce(const DeclaredCrossingTable *table,
                                          const BoundaryCrossingKind  *kind,
                                          const char                  *symbol);

/* ---------------------------------------------------------------------------
 *  Operation : declared_crossing_table_declares_symbol
 *
 *  Report whether a symbol is declared under ANY crossing kind. Collision
 *  detection uses this to know a symbol is sanctioned to cross regardless of
 *  which kind sanctioned it: a whitelisted symbol is not an unguarded
 *  collision. Returns nonzero if the symbol appears in any declaration.
 *
 *  IN  table   VALID  CONSUME  ALWAYS  KEEP  NONE  the declared crossings
 *  IN  symbol  VALID  CONSUME  ALWAYS  KEEP  NONE  symbol name to look up
 * ---------------------------------------------------------------------------*/
int declared_crossing_table_declares_symbol(const DeclaredCrossingTable *table,
                                            const char                  *symbol);

#endif /* BOUNDARY_CROSSING_ENFORCEMENT_H */
