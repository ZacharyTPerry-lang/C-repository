/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * boundary_crossing_discovery.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : boundary_crossing_system
 *
 * Purpose       : Discover compelled crossings that actually exist, by asking
 *                 the toolchain rather than reasoning about source. A reverse
 *                 dependency is a project symbol a vendor object leaves
 *                 undefined; discovery finds it by intersecting the vendor
 *                 object's undefined set (U) with the project's defined-external
 *                 set (P). Every name in that intersection is a real crossing
 *                 the linker will bind.
 *
 * Why intersect : a vendor object has many undefined symbols -- libc functions,
 *                 other vendor symbols. Only the ones that match a project
 *                 symbol are crossings into project code. U on its own is too
 *                 broad; U intersect P is exactly the reverse dependencies.
 *
 * Toolchain, not source : both U and P come from nm on compiled objects
 *                 (symbol_set_from_object). This module runs no C parser and
 *                 makes no source-level judgement. It composes two nm results
 *                 and reports their intersection as discovered crossings, each
 *                 tagged with the crossing kind whose discovery mechanism is
 *                 "vendor undefined symbol." Which kind that is comes from the
 *                 vocabulary, not from a hard-coded keyword.
 *
 * Boundary      : discovery finds crossings; it does not judge them. The
 *                 verdict -- declared or error -- is the enforcement module's.
 *                 Discovery hands enforcement a list; enforcement returns a
 *                 verdict per item.
 *
 * Portability   : C99 plus the nm invocation inherited from
 *                 symbol_set_from_object.
 *
 * Table of contents:
 *   [1] DISCOVERED CROSSING LIST
 *   [2] DISCOVERY
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef BOUNDARY_CROSSING_DISCOVERY_H
#define BOUNDARY_CROSSING_DISCOVERY_H

#include <stddef.h>
#include "symbol_set_from_object.h"
#include "boundary_crossing_vocabulary.h"

/* ===========================================================================
 * [1] DISCOVERED CROSSING LIST
 * ===========================================================================
 *
 *  The crossings found in one discovery run. Each is a kind plus the symbol
 *  name it applies to. Names are held in a SymbolSet-style block; the kind is
 *  the same for every entry of one discovery mechanism, so it is stored once.
 *
 * ---------------------------------------------------------------------------
 *  kind             the crossing kind all discovered items share (the kind
 *                   whose discovery is "vendor undefined symbol")
 *  crossing_symbols the symbol names discovered, as a queryable set
 * ---------------------------------------------------------------------------*/

typedef struct DiscoveredCrossings {
        const BoundaryCrossingKind *kind;
        SymbolSet                   crossing_symbols;
} DiscoveredCrossings;

/* ===========================================================================
 * [2] DISCOVERY
 * ===========================================================================*/

typedef enum CrossingDiscoveryResult {
        CROSSING_DISCOVERY_OK,

        /* nm failed on the vendor or project object. */
        CROSSING_DISCOVERY_TOOL_FAILED,

        CROSSING_DISCOVERY_OUT_OF_MEMORY,

        /* The vocabulary defines no kind discovered by vendor undefined
         * symbols, so this discovery mechanism has nothing to produce. Treated
         * as a configuration error rather than an empty result, because the
         * caller asked for a discovery the grammar does not support. */
        CROSSING_DISCOVERY_NO_MATCHING_KIND
} CrossingDiscoveryResult;

/* ---------------------------------------------------------------------------
 *  Operation : boundary_crossing_discover_reverse_dependencies
 *
 *  Find the reverse dependencies of one vendor object against the project's
 *  defined-external symbol set. Runs nm for the vendor object's undefined set,
 *  intersects it with the supplied project set P, and records the intersection
 *  as discovered crossings of the vendor-undefined-symbol kind.
 *
 *  The project set P is supplied by the caller (extracted once from the project
 *  objects and reused across vendors), rather than re-extracted here, so a
 *  multi-vendor run pays for P once.
 *
 *  On success the caller owns discovered_out and releases it with
 *  discovered_crossings_release. On failure it is left empty and released
 *  internally.
 *
 *  IN   vendor_object_path   VALID    CONSUME   ALWAYS      KEEP  NONE  .o path
 *  IN   project_symbol_set_p VALID    CONSUME   ALWAYS      KEEP  NONE  set P
 *  OUT  discovered_out       GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE  result
 * ---------------------------------------------------------------------------*/
CrossingDiscoveryResult boundary_crossing_discover_reverse_dependencies(
        const char          *vendor_object_path,
        const SymbolSet     *project_symbol_set_p,
        DiscoveredCrossings *discovered_out);

/* ---------------------------------------------------------------------------
 *  Operation : discovered_crossings_release
 *
 *  Free a discovery result and reset it to empty. Safe on an empty result.
 *
 *  IN  discovered  VALID  MUTATE  ALWAYS  GIVE  NONE  result to release
 * ---------------------------------------------------------------------------*/
void discovered_crossings_release(DiscoveredCrossings *discovered);

#endif /* BOUNDARY_CROSSING_DISCOVERY_H */
