/* Unit test for boundary_crossing_vocabulary + boundary_crossing_enforcement.
 * Verifies: the vocabulary maps keywords and discovery to kinds; the whitelist
 * parser handles declarations, comments, and malformed lines; the modality
 * rule permits declared and chosen-absent, and errors on compelled-absent. */

#include "boundary_crossing_enforcement.h"
#include "boundary_crossing_vocabulary.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int failures = 0;

static void write_file(const char *path, const char *content)
{
        FILE *f = fopen(path, "w");
        fputs(content, f);
        fclose(f);
}

int main(void)
{
        printf("vocabulary lookup:\n");
        const BoundaryCrossingKind *rev =
                boundary_crossing_kind_by_keyword("VENDOR_LINKS_PROJECT");
        if (rev && rev->modality == BOUNDARY_CROSSING_MODALITY_COMPELLED) {
                printf("  pass: VENDOR_LINKS_PROJECT is COMPELLED\n");
        } else { printf("  FAIL: reverse-dep modality\n"); failures++; }

        const BoundaryCrossingKind *state_a =
                boundary_crossing_kind_by_keyword("PROJECT_VALUE_SUPERSEDES");
        if (state_a && state_a->modality == BOUNDARY_CROSSING_MODALITY_CHOSEN) {
                printf("  pass: PROJECT_VALUE_SUPERSEDES is CHOSEN\n");
        } else { printf("  FAIL: state-A modality\n"); failures++; }

        if (boundary_crossing_kind_by_keyword("NOT_A_KIND") == NULL) {
                printf("  pass: unknown keyword returns NULL\n");
        } else { printf("  FAIL: unknown keyword\n"); failures++; }

        const BoundaryCrossingKind *by_disc =
                boundary_crossing_kind_for_discovery(
                        BOUNDARY_CROSSING_DISCOVERY_VENDOR_UNDEFINED_SYMBOL);
        if (by_disc == rev) {
                printf("  pass: nm-undefined discovery maps to reverse-dep kind\n");
        } else { printf("  FAIL: discovery mapping\n"); failures++; }

        printf("whitelist parsing:\n");
        write_file("/tmp/wl_good.txt",
                "# a comment\n"
                "\n"
                "VENDOR_LINKS_PROJECT(project_allocator)\n"
                "VENDOR_VALUE_SUPERSEDES( BLAKE3_OUT_LEN )\n");
        DeclaredCrossingTable table;
        size_t bad_line = 0;
        WhitelistLoadResult lr =
                declared_crossing_table_load("/tmp/wl_good.txt", &table, &bad_line);
        if (lr == WHITELIST_LOAD_OK && table.entry_count == 2) {
                printf("  pass: parsed 2 declarations, skipped comment/blank\n");
        } else {
                printf("  FAIL: load result %d, %zu entries\n", lr,
                       table.entry_count);
                failures++;
        }

        printf("enforcement:\n");
        /* declared compelled crossing -> permitted */
        CrossingVerdict v1 =
                boundary_crossing_enforce(&table, rev, "project_allocator");
        if (v1 == CROSSING_VERDICT_PERMITTED) {
                printf("  pass: declared reverse-dep permitted\n");
        } else { printf("  FAIL: declared reverse-dep\n"); failures++; }

        /* UNdeclared compelled crossing -> error */
        CrossingVerdict v2 =
                boundary_crossing_enforce(&table, rev, "undeclared_symbol");
        if (v2 == CROSSING_VERDICT_UNDECLARED_COMPELLED) {
                printf("  pass: undeclared reverse-dep -> UNDECLARED_COMPELLED\n");
        } else { printf("  FAIL: undeclared reverse-dep not caught\n"); failures++; }

        /* UNdeclared chosen crossing -> permitted (falls to default) */
        CrossingVerdict v3 =
                boundary_crossing_enforce(&table, state_a, "anything");
        if (v3 == CROSSING_VERDICT_PERMITTED) {
                printf("  pass: undeclared chosen crossing falls to default\n");
        } else { printf("  FAIL: chosen crossing wrongly errored\n"); failures++; }

        declared_crossing_table_release(&table);

        /* malformed line reported, not skipped */
        write_file("/tmp/wl_bad.txt",
                "VENDOR_LINKS_PROJECT(ok)\n"
                "TYPO_KEYWORD(sym)\n");
        DeclaredCrossingTable bad_table;
        size_t bad_ln = 0;
        WhitelistLoadResult br =
                declared_crossing_table_load("/tmp/wl_bad.txt", &bad_table, &bad_ln);
        if (br == WHITELIST_LOAD_MALFORMED_LINE && bad_ln == 2) {
                printf("  pass: malformed keyword reported at line 2\n");
        } else {
                printf("  FAIL: malformed handling result %d line %zu\n",
                       br, bad_ln);
                failures++;
        }

        /* missing file */
        DeclaredCrossingTable missing;
        if (declared_crossing_table_load("/tmp/nope_zzz.txt", &missing, NULL)
            == WHITELIST_LOAD_FILE_NOT_FOUND) {
                printf("  pass: missing file reported\n");
        } else { printf("  FAIL: missing file\n"); failures++; }

        if (failures == 0) {
                printf("ALL BOUNDARY-CROSSING TESTS PASS\n");
                return 0;
        }
        printf("%d BOUNDARY-CROSSING TEST(S) FAILED\n", failures);
        return 1;
}
