/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * boundary_crossing_discovery.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : boundary_crossing_system
 *
 * Purpose       : Implementation of reverse-dependency discovery. Extracts the
 *                 vendor object's undefined set, intersects with the project's
 *                 defined-external set, and records the intersection.
 *
 * Portability   : C99 plus nm (via symbol_set_from_object).
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "boundary_crossing_discovery.h"

#include <string.h>

CrossingDiscoveryResult boundary_crossing_discover_reverse_dependencies(
        const char          *vendor_object_path,
        const SymbolSet     *project_symbol_set_p,
        DiscoveredCrossings *discovered_out)
{
        /* which crossing kind is discovered by vendor undefined symbols */
        const BoundaryCrossingKind *kind =
                boundary_crossing_kind_for_discovery(
                        BOUNDARY_CROSSING_DISCOVERY_VENDOR_UNDEFINED_SYMBOL);

        discovered_out->kind = kind;
        symbol_set_begin(&discovered_out->crossing_symbols);

        if (kind == NULL) {
                return CROSSING_DISCOVERY_NO_MATCHING_KIND;
        }

        /* vendor's undefined set U */
        SymbolSet vendor_undefined;
        SymbolSetResult ur = symbol_set_extract_from_object(
                vendor_object_path,
                SYMBOL_SET_SELECTOR_UNDEFINED, &vendor_undefined);
        if (ur != SYMBOL_SET_RESULT_OK) {
                symbol_set_release(&discovered_out->crossing_symbols);
                return (ur == SYMBOL_SET_RESULT_OUT_OF_MEMORY)
                     ? CROSSING_DISCOVERY_OUT_OF_MEMORY
                     : CROSSING_DISCOVERY_TOOL_FAILED;
        }

        /* U intersect P : walk U, keep names present in P */
        CrossingDiscoveryResult result = CROSSING_DISCOVERY_OK;
        size_t index;
        for (index = 0; index < vendor_undefined.name_count; index++) {
                const char *name =
                        symbol_set_name_at(&vendor_undefined, index);
                if (symbol_set_contains(project_symbol_set_p, name)) {
                        if (!symbol_set_add_name(
                                    &discovered_out->crossing_symbols,
                                    name, strlen(name))) {
                                result = CROSSING_DISCOVERY_OUT_OF_MEMORY;
                                break;
                        }
                }
        }

        symbol_set_release(&vendor_undefined);

        if (result != CROSSING_DISCOVERY_OK) {
                symbol_set_release(&discovered_out->crossing_symbols);
                return result;
        }

        symbol_set_finalize(&discovered_out->crossing_symbols);
        return CROSSING_DISCOVERY_OK;
}

void discovered_crossings_release(DiscoveredCrossings *discovered)
{
        symbol_set_release(&discovered->crossing_symbols);
        discovered->kind = NULL;
}
