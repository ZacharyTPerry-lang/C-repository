#include "boundary_crossing_discovery.h"
#include "symbol_set_from_object.h"
#include <stdio.h>
int main(void){
    int fails=0;
    /* P = project defined-external */
    SymbolSet P;
    if(symbol_set_extract_from_object("/tmp/proj_lib.o",
            SYMBOL_SET_SELECTOR_DEFINED_EXTERNAL,&P)!=SYMBOL_SET_RESULT_OK){
        printf("P extract failed\n");return 1;}
    DiscoveredCrossings disc;
    CrossingDiscoveryResult r=boundary_crossing_discover_reverse_dependencies(
        "/tmp/vend_lib.o",&P,&disc);
    if(r!=CROSSING_DISCOVERY_OK){printf("discovery failed %d\n",r);return 1;}

    /* project_allocator IS a crossing; some_other_lib is NOT */
    if(symbol_set_contains(&disc.crossing_symbols,"project_allocator"))
        printf("  pass: project_allocator discovered as crossing\n");
    else{printf("  FAIL: project_allocator missed\n");fails++;}

    if(!symbol_set_contains(&disc.crossing_symbols,"some_other_lib"))
        printf("  pass: some_other_lib NOT a crossing (not a project symbol)\n");
    else{printf("  FAIL: some_other_lib wrongly discovered\n");fails++;}

    /* the discovered kind must be the compelled reverse-dep kind */
    if(disc.kind && disc.kind->modality==BOUNDARY_CROSSING_MODALITY_COMPELLED)
        printf("  pass: discovered kind is COMPELLED\n");
    else{printf("  FAIL: wrong kind\n");fails++;}

    discovered_crossings_release(&disc);
    symbol_set_release(&P);
    if(fails==0){printf("ALL DISCOVERY TESTS PASS\n");return 0;}
    printf("%d FAILED\n",fails);return 1;
}
