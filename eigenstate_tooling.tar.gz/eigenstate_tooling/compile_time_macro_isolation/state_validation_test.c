#include "state_validation.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static int fails=0;
static void wr(const char*p,const char*c){FILE*f=fopen(p,"w");fputs(c,f);fclose(f);}

int main(void){
    StateValidationResult r;
    /* ---- State C: isolation holds (identifier survives) ---- */
    wr("/tmp/sv_isolated.c","static int lookup(int index){ return index+1; }\n");
    StateValidationOutcome o=state_validation_check_isolation(
        "/tmp/sv_isolated.c","index","",&r);
    if(o==STATE_VALIDATION_HOLDS)printf("  PASS: State C holds (index survived)\n");
    else{printf("  FAIL: State C outcome=%d obs='%s'\n",o,r.observed);fails++;}

    /* ---- State C: isolation VIOLATED (identifier captured) ---- */
    /* simulate a capture: the identifier got rewritten away */
    wr("/tmp/sv_captured.c","static int lookup(int vendor_internal_index){ return vendor_internal_index+1; }\n");
    o=state_validation_check_isolation("/tmp/sv_captured.c","index","",&r);
    if(o==STATE_VALIDATION_VIOLATED)printf("  PASS: State C violation detected (index absent = captured)\n");
    else{printf("  FAIL: State C should detect capture, got %d\n",o);fails++;}

    /* ---- State B: vendor value crosses under prefix, holds ---- */
    wr("/tmp/sv_vendor.h","#ifndef VH\n#define VH\n#define BLAKE3_KEY_LEN 32\n#endif\n");
    wr("/tmp/sv_genB.h","#define COMPILE_TIME_ENFORCEMENT_FRAMEWORK_BLAKE3_KEY_LEN 32\n");
    wr("/tmp/sv_projB.c","#include \"/tmp/sv_genB.h\"\nint project_key = COMPILE_TIME_ENFORCEMENT_FRAMEWORK_BLAKE3_KEY_LEN;\n");
    o=state_validation_check_vendor_supersedes(
        "/tmp/sv_vendor.h","/tmp/sv_projB.c","BLAKE3_KEY_LEN","project_key","",&r);
    if(o==STATE_VALIDATION_HOLDS)printf("  PASS: State B holds (project sees vendor value %s)\n",r.observed);
    else{printf("  FAIL: State B outcome=%d obs='%s' exp='%s'\n",o,r.observed,r.expected);fails++;}

    /* ---- State B: VIOLATED (generated header has WRONG value) ---- */
    wr("/tmp/sv_genB_wrong.h","#define COMPILE_TIME_ENFORCEMENT_FRAMEWORK_BLAKE3_KEY_LEN 99\n");
    wr("/tmp/sv_projB_wrong.c","#include \"/tmp/sv_genB_wrong.h\"\nint project_key = COMPILE_TIME_ENFORCEMENT_FRAMEWORK_BLAKE3_KEY_LEN;\n");
    o=state_validation_check_vendor_supersedes(
        "/tmp/sv_vendor.h","/tmp/sv_projB_wrong.c","BLAKE3_KEY_LEN","project_key","",&r);
    if(o==STATE_VALIDATION_VIOLATED)printf("  PASS: State B violation detected (got %s, vendor says %s)\n",r.observed,r.expected);
    else{printf("  FAIL: State B should detect wrong value, got %d\n",o);fails++;}

    /* ---- State A: project value wins in vendor space, holds ---- */
    wr("/tmp/sv_va.h","#ifndef VA\n#define VA\n#define BUF_SIZE 32\n#endif\n");
    wr("/tmp/sv_genA.h","#include \"/tmp/sv_va.h\"\n#undef BUF_SIZE\n#define BUF_SIZE 64\n");
    wr("/tmp/sv_wrapped.c","#include \"/tmp/sv_genA.h\"\nint vendor_buf = BUF_SIZE;\n");
    o=state_validation_check_project_supersedes(
        "/tmp/sv_wrapped.c","vendor_buf","64","",&r);
    if(o==STATE_VALIDATION_HOLDS)printf("  PASS: State A holds (vendor space sees project value %s)\n",r.observed);
    else{printf("  FAIL: State A outcome=%d obs='%s' exp='%s'\n",o,r.observed,r.expected);fails++;}

    /* ---- State A: VIOLATED (wrapper failed, vendor value still 32) ---- */
    wr("/tmp/sv_genA_bad.h","#include \"/tmp/sv_va.h\"\n");  /* forgot undef+redefine */
    wr("/tmp/sv_wrapped_bad.c","#include \"/tmp/sv_genA_bad.h\"\nint vendor_buf = BUF_SIZE;\n");
    o=state_validation_check_project_supersedes(
        "/tmp/sv_wrapped_bad.c","vendor_buf","64","",&r);
    if(o==STATE_VALIDATION_VIOLATED)printf("  PASS: State A violation detected (got %s, expected 64)\n",r.observed);
    else{printf("  FAIL: State A should detect failed supersede, got %d\n",o);fails++;}

    if(fails==0){printf("ALL STATE-VALIDATION TESTS PASS\n");return 0;}
    printf("%d FAILED\n",fails);return 1;
}
