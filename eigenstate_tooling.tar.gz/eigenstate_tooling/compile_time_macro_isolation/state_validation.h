/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * state_validation.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_macro_isolation
 *
 * Purpose       : Independently verify that a boundary transformation produced
 *                 the behavior its state defines, by reading the compiler's
 *                 actual output -- never by consulting the transformer.
 *
 * Why independent : validation and transformation must share no logic. If this
 *                 module asked collision_detection or the rewriter what it did,
 *                 a bug in that shared logic would pass both the transform and
 *                 its own check -- the validator would inherit the transformer's
 *                 blind spots. So the validator derives its verdict by a
 *                 separate route: preprocess the relevant code, read the tokens
 *                 the compiler actually produced, and assert the state's defined
 *                 behavior against the vendor's own compiler-reported facts. The
 *                 compiler is shared (it is the neutral oracle); no code is.
 *
 * What each state asserts (the definitions, independently checked):
 *
 *   State C (isolation) : a project identifier that collides with a vendor
 *     macro name survives unchanged in the project's preprocessed output --
 *     nothing crossed, so no capture occurred.
 *
 *   State B (vendor supersedes) : project code reading the prefixed name sees
 *     the vendor's value. The validator reads the vendor value from the
 *     vendor header's own -dM dump and the project-side value from the
 *     project's preprocessed output, and asserts they match.
 *
 *   State A (project supersedes) : vendor code compiled through the wrapper
 *     sees the project's value rather than the vendor's. The validator reads
 *     the vendor-space value from the preprocessed wrapper output and asserts
 *     it equals the project value, not the vendor's original.
 *
 * Miss vs overzealous : a MISS is the boundary changing something no crossing
 *                 sanctioned (a capture that slipped through); an OVERZEALOUS
 *                 action is the boundary changing something it should not have.
 *                 Both surface as the asserted behavior failing to hold, caught
 *                 against the compiler's output rather than the transformer's
 *                 claim.
 *
 * Portability   : C99 plus the gcc invocations. Uses the lexical scanner to
 *                 read preprocessed output, and reuses the compiler-query style
 *                 of state_crossing_generation.
 *
 * Table of contents:
 *   [1] VALIDATION OUTCOME
 *   [2] PER-STATE VALIDATION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef STATE_VALIDATION_H
#define STATE_VALIDATION_H

#include <stddef.h>

/* ===========================================================================
 * [1] VALIDATION OUTCOME
 * ===========================================================================*/

typedef enum StateValidationOutcome {
        /* The state's defined behavior holds in the compiler's output. */
        STATE_VALIDATION_HOLDS,

        /* The behavior does not hold: the value or identifier in the output is
         * not what the state defines. The specifics are reported through the
         * detail-carrying fields of the result. */
        STATE_VALIDATION_VIOLATED,

        /* A gcc invocation failed, or an input file was unreadable. */
        STATE_VALIDATION_TOOL_FAILED
} StateValidationOutcome;

/* A validation result carries the outcome and, for a violation, the observed
 * and expected forms so the caller can report exactly what diverged. The string
 * fields point into caller-provided buffers filled by the validation call; they
 * are valid until the next call reusing those buffers. */
typedef struct StateValidationResult {
        StateValidationOutcome outcome;
        char                   observed[256];   /* what the output showed */
        char                   expected[256];   /* what the state defines */
} StateValidationResult;

/* ===========================================================================
 * [2] PER-STATE VALIDATION
 * ===========================================================================*/

/* ---------------------------------------------------------------------------
 *  Operation : state_validation_check_isolation  (State C)
 *
 *  Assert that a project identifier survives unchanged in the project's
 *  preprocessed output -- i.e. no vendor macro captured it. The project source
 *  is preprocessed as the boundary would present it (without the vendor macro
 *  namespace in its translation unit); the named identifier must appear intact.
 *
 *  Holds if the identifier is present unchanged. Violated if it was rewritten
 *  (captured), with observed = the rewritten form found.
 *
 *  IN   project_source_path   VALID    CONSUME   ALWAYS      KEEP  NONE
 *  IN   project_identifier    VALID    CONSUME   ALWAYS      KEEP  NONE  name
 *                                                                        that
 *                                                                        must
 *                                                                        survive
 *  IN   include_flags         VALID    CONSUME   ALWAYS      KEEP  NONE  or ""
 *  OUT  result_out            GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE
 * ---------------------------------------------------------------------------*/
StateValidationOutcome state_validation_check_isolation(
        const char            *project_source_path,
        const char            *project_identifier,
        const char            *include_flags,
        StateValidationResult *result_out);

/* ---------------------------------------------------------------------------
 *  Operation : state_validation_check_vendor_supersedes  (State B)
 *
 *  Assert that project code reading the prefixed name sees the vendor's value.
 *  The validator independently reads the vendor value from the vendor header's
 *  -dM dump, preprocesses the project source (which includes the generated
 *  prefixed header), reads the value the prefixed name resolved to, and asserts
 *  the two agree.
 *
 *  IN   vendor_header_path    VALID    CONSUME   ALWAYS      KEEP  NONE
 *  IN   project_source_path   VALID    CONSUME   ALWAYS      KEEP  NONE  uses the
 *                                                                        prefixed
 *                                                                        name
 *  IN   macro_name            VALID    CONSUME   ALWAYS      KEEP  NONE  vendor
 *                                                                        macro
 *  IN   observed_identifier   VALID    CONSUME   ALWAYS      KEEP  NONE  the
 *                                                                        project
 *                                                                        variable
 *                                                                        assigned
 *                                                                        the value
 *  IN   include_flags         VALID    CONSUME   ALWAYS      KEEP  NONE  or ""
 *  OUT  result_out            GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE
 * ---------------------------------------------------------------------------*/
StateValidationOutcome state_validation_check_vendor_supersedes(
        const char            *vendor_header_path,
        const char            *project_source_path,
        const char            *macro_name,
        const char            *observed_identifier,
        const char            *include_flags,
        StateValidationResult *result_out);

/* ---------------------------------------------------------------------------
 *  Operation : state_validation_check_project_supersedes  (State A)
 *
 *  Assert that vendor code compiled through the wrapper sees the project value.
 *  The validator preprocesses the vendor-side source (through the generated
 *  wrapper), reads the value the macro resolved to, and asserts it equals the
 *  project value and not the vendor's original.
 *
 *  IN   wrapped_source_path   VALID    CONSUME   ALWAYS      KEEP  NONE  vendor
 *                                                                        code via
 *                                                                        wrapper
 *  IN   observed_identifier   VALID    CONSUME   ALWAYS      KEEP  NONE  the
 *                                                                        variable
 *                                                                        assigned
 *  IN   expected_project_value VALID   CONSUME   ALWAYS      KEEP  NONE  value
 *                                                                        text
 *  IN   include_flags         VALID    CONSUME   ALWAYS      KEEP  NONE  or ""
 *  OUT  result_out            GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE
 * ---------------------------------------------------------------------------*/
StateValidationOutcome state_validation_check_project_supersedes(
        const char            *wrapped_source_path,
        const char            *observed_identifier,
        const char            *expected_project_value,
        const char            *include_flags,
        StateValidationResult *result_out);

#endif /* STATE_VALIDATION_H */
