/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * state_validation.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_macro_isolation
 *
 * Purpose       : Implementation of independent state validation. Reads the
 *                 compiler's preprocessed output and the vendor's -dM dump, and
 *                 asserts each state's defined behavior. Consults no transformer
 *                 module.
 *
 * Portability   : C99 plus POSIX (popen) for the gcc invocations.
 *
 * Table of contents:
 *   [1] PREPROCESS AND READ
 *   [2] VALUE-OF-ASSIGNMENT EXTRACTION
 *   [3] PER-STATE VALIDATION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200112L
#endif

#include "state_validation.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===========================================================================
 * [1] PREPROCESS AND READ
 * ===========================================================================
 *
 *  Run gcc -E -P on a source and capture its whole output into a caller
 *  buffer. The pipe is drained fully before pclose so the child is not left
 *  writing into a closed pipe (which would surface as a false tool failure).
 *
 * ===========================================================================*/

/* Returns nonzero on success; fills output_buffer with the preprocessed text
 * (truncated to fit). On tool failure returns zero. */
static int preprocess_capture(const char *source_path,
                              const char *include_flags,
                              char       *output_buffer,
                              size_t      output_buffer_size)
{
        char command[8192];
        int written = snprintf(command, sizeof(command),
                               "gcc -E -P %s '%s' 2>/dev/null",
                               include_flags, source_path);
        if (written <= 0 || (size_t)written >= sizeof(command)) {
                return 0;
        }
        FILE *pipe = popen(command, "r");
        if (pipe == NULL) {
                return 0;
        }

        size_t total = 0;
        int    truncated = 0;
        char   chunk[4096];
        size_t got;
        while ((got = fread(chunk, 1, sizeof(chunk), pipe)) > 0) {
                if (!truncated) {
                        if (total + got < output_buffer_size) {
                                memcpy(output_buffer + total, chunk, got);
                                total += got;
                        } else {
                                /* fill what we can, then keep draining */
                                size_t room = output_buffer_size - 1 - total;
                                if (room > 0) {
                                        memcpy(output_buffer + total,
                                               chunk, room);
                                        total += room;
                                }
                                truncated = 1;
                        }
                }
        }
        output_buffer[total] = '\0';

        if (pclose(pipe) != 0) {
                return 0;
        }
        return 1;
}

/* Read a vendor macro's value from gcc -dM -E into value_out. Returns nonzero
 * if found. */
static int read_vendor_value(const char *vendor_header_path,
                             const char *macro_name,
                             const char *include_flags,
                             char       *value_out,
                             size_t      value_out_size,
                             int        *tool_failed)
{
        *tool_failed = 0;
        char command[8192];
        int written = snprintf(command, sizeof(command),
                               "gcc -dM -E %s '%s'",
                               include_flags, vendor_header_path);
        if (written <= 0 || (size_t)written >= sizeof(command)) {
                *tool_failed = 1;
                return 0;
        }
        FILE *pipe = popen(command, "r");
        if (pipe == NULL) {
                *tool_failed = 1;
                return 0;
        }

        char needle[512];
        int nn = snprintf(needle, sizeof(needle), "#define %s ", macro_name);
        int found = 0;
        if (nn > 0 && (size_t)nn < sizeof(needle)) {
                char line[16384];
                while (fgets(line, sizeof(line), pipe) != NULL) {
                        if (!found
                            && strncmp(line, needle, (size_t)nn) == 0) {
                                const char *value = line + nn;
                                size_t len = strlen(value);
                                while (len > 0 && (value[len - 1] == '\n'
                                               || value[len - 1] == '\r')) {
                                        len--;
                                }
                                if (len < value_out_size) {
                                        memcpy(value_out, value, len);
                                        value_out[len] = '\0';
                                        found = 1;
                                }
                        }
                }
        }
        if (pclose(pipe) != 0) {
                *tool_failed = 1;
                return 0;
        }
        return found;
}

/* ===========================================================================
 * [2] VALUE-OF-ASSIGNMENT EXTRACTION
 * ===========================================================================
 *
 *  The validation sources assign the value under test to a named variable:
 *  "int NAME = VALUE;". Reading the value the compiler produced is a matter of
 *  finding "NAME" in the preprocessed output and reading the token after '='.
 *  This is a deliberately narrow parse of a controlled probe, not a general C
 *  parse.
 *
 * ===========================================================================*/

/* Find "identifier ... = <value> ;" in text and copy the value token into
 * value_out. Returns nonzero if found. */
static int extract_assigned_value(const char *text,
                                  const char *identifier,
                                  char       *value_out,
                                  size_t      value_out_size)
{
        const char *cursor = text;
        size_t      id_len = strlen(identifier);
        while ((cursor = strstr(cursor, identifier)) != NULL) {
                /* ensure whole-token match: boundaries are non-identifier */
                char before = (cursor == text) ? ' ' : cursor[-1];
                char after  = cursor[id_len];
                int before_ok = !((before >= 'A' && before <= 'Z')
                               || (before >= 'a' && before <= 'z')
                               || (before >= '0' && before <= '9')
                               ||  before == '_');
                int after_ok = !((after >= 'A' && after <= 'Z')
                              || (after >= 'a' && after <= 'z')
                              || (after >= '0' && after <= '9')
                              ||  after == '_');
                if (!before_ok || !after_ok) {
                        cursor += id_len;
                        continue;
                }
                /* advance to '=' */
                const char *p = cursor + id_len;
                while (*p != '\0' && *p != '=' && *p != ';') {
                        p++;
                }
                if (*p != '=') {
                        cursor += id_len;
                        continue;
                }
                p++;
                while (*p == ' ' || *p == '\t') {
                        p++;
                }
                /* copy the value token up to ';' or whitespace */
                size_t out = 0;
                while (*p != '\0' && *p != ';' && *p != '\n'
                       && out + 1 < value_out_size) {
                        value_out[out++] = *p++;
                }
                /* trim trailing spaces */
                while (out > 0 && (value_out[out - 1] == ' '
                               || value_out[out - 1] == '\t')) {
                        out--;
                }
                value_out[out] = '\0';
                return 1;
        }
        return 0;
}

/* Report whether identifier appears as a whole token anywhere in text. */
static int contains_identifier(const char *text, const char *identifier)
{
        const char *cursor = text;
        size_t      id_len = strlen(identifier);
        while ((cursor = strstr(cursor, identifier)) != NULL) {
                char before = (cursor == text) ? ' ' : cursor[-1];
                char after  = cursor[id_len];
                int before_ok = !((before >= 'A' && before <= 'Z')
                               || (before >= 'a' && before <= 'z')
                               || (before >= '0' && before <= '9')
                               ||  before == '_');
                int after_ok = !((after >= 'A' && after <= 'Z')
                              || (after >= 'a' && after <= 'z')
                              || (after >= '0' && after <= '9')
                              ||  after == '_');
                if (before_ok && after_ok) {
                        return 1;
                }
                cursor += id_len;
        }
        return 0;
}

/* ===========================================================================
 * [3] PER-STATE VALIDATION
 * ===========================================================================*/

StateValidationOutcome state_validation_check_isolation(
        const char            *project_source_path,
        const char            *project_identifier,
        const char            *include_flags,
        StateValidationResult *result_out)
{
        char output[65536];
        if (!preprocess_capture(project_source_path, include_flags,
                                output, sizeof(output))) {
                result_out->outcome = STATE_VALIDATION_TOOL_FAILED;
                return STATE_VALIDATION_TOOL_FAILED;
        }

        /* State C holds iff the project identifier survived unchanged. */
        if (contains_identifier(output, project_identifier)) {
                result_out->outcome = STATE_VALIDATION_HOLDS;
                snprintf(result_out->observed, sizeof(result_out->observed),
                         "%s", project_identifier);
                snprintf(result_out->expected, sizeof(result_out->expected),
                         "%s", project_identifier);
                return STATE_VALIDATION_HOLDS;
        }
        result_out->outcome = STATE_VALIDATION_VIOLATED;
        snprintf(result_out->observed, sizeof(result_out->observed),
                 "identifier absent (captured or renamed)");
        snprintf(result_out->expected, sizeof(result_out->expected),
                 "%s present unchanged", project_identifier);
        return STATE_VALIDATION_VIOLATED;
}

StateValidationOutcome state_validation_check_vendor_supersedes(
        const char            *vendor_header_path,
        const char            *project_source_path,
        const char            *macro_name,
        const char            *observed_identifier,
        const char            *include_flags,
        StateValidationResult *result_out)
{
        /* independent read of the vendor's value */
        char vendor_value[256];
        int  tool_failed = 0;
        if (!read_vendor_value(vendor_header_path, macro_name, include_flags,
                               vendor_value, sizeof(vendor_value),
                               &tool_failed)) {
                result_out->outcome = STATE_VALIDATION_TOOL_FAILED;
                return STATE_VALIDATION_TOOL_FAILED;
        }

        /* independent read of what project code saw */
        char output[65536];
        if (!preprocess_capture(project_source_path, include_flags,
                                output, sizeof(output))) {
                result_out->outcome = STATE_VALIDATION_TOOL_FAILED;
                return STATE_VALIDATION_TOOL_FAILED;
        }
        char project_value[256];
        if (!extract_assigned_value(output, observed_identifier,
                                    project_value, sizeof(project_value))) {
                result_out->outcome = STATE_VALIDATION_VIOLATED;
                snprintf(result_out->observed, sizeof(result_out->observed),
                         "no value for %s in output", observed_identifier);
                snprintf(result_out->expected, sizeof(result_out->expected),
                         "%s", vendor_value);
                return STATE_VALIDATION_VIOLATED;
        }

        snprintf(result_out->observed, sizeof(result_out->observed),
                 "%s", project_value);
        snprintf(result_out->expected, sizeof(result_out->expected),
                 "%s", vendor_value);
        if (strcmp(project_value, vendor_value) == 0) {
                result_out->outcome = STATE_VALIDATION_HOLDS;
                return STATE_VALIDATION_HOLDS;
        }
        result_out->outcome = STATE_VALIDATION_VIOLATED;
        return STATE_VALIDATION_VIOLATED;
}

StateValidationOutcome state_validation_check_project_supersedes(
        const char            *wrapped_source_path,
        const char            *observed_identifier,
        const char            *expected_project_value,
        const char            *include_flags,
        StateValidationResult *result_out)
{
        char output[65536];
        if (!preprocess_capture(wrapped_source_path, include_flags,
                                output, sizeof(output))) {
                result_out->outcome = STATE_VALIDATION_TOOL_FAILED;
                return STATE_VALIDATION_TOOL_FAILED;
        }
        char observed_value[256];
        if (!extract_assigned_value(output, observed_identifier,
                                    observed_value, sizeof(observed_value))) {
                result_out->outcome = STATE_VALIDATION_VIOLATED;
                snprintf(result_out->observed, sizeof(result_out->observed),
                         "no value for %s in output", observed_identifier);
                snprintf(result_out->expected, sizeof(result_out->expected),
                         "%s", expected_project_value);
                return STATE_VALIDATION_VIOLATED;
        }

        snprintf(result_out->observed, sizeof(result_out->observed),
                 "%s", observed_value);
        snprintf(result_out->expected, sizeof(result_out->expected),
                 "%s", expected_project_value);
        if (strcmp(observed_value, expected_project_value) == 0) {
                result_out->outcome = STATE_VALIDATION_HOLDS;
                return STATE_VALIDATION_HOLDS;
        }
        result_out->outcome = STATE_VALIDATION_VIOLATED;
        return STATE_VALIDATION_VIOLATED;
}
