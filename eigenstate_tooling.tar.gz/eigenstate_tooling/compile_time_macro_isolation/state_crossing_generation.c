/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * state_crossing_generation.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_macro_isolation
 *
 * Purpose       : Implementation of State A/B value-crossing generation and the
 *                 gcc -dU based safety classification.
 *
 * Portability   : C99 plus POSIX (popen) for the gcc invocations.
 *
 * Table of contents:
 *   [1] GCC QUERIES
 *   [2] SAFETY CLASSIFICATION
 *   [3] GENERATION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200112L
#endif

#include "state_crossing_generation.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===========================================================================
 * [1] GCC QUERIES
 * ===========================================================================
 *
 *  Two queries, both reading a compiler stage output rather than reasoning
 *  about source:
 *
 *    -dM -E : dump all defined macros with values. Used to read a macro's
 *             vendor value.
 *    -dU -E : dump macros that were used (expanded or tested). Used to decide
 *             whether the vendor depends on a macro's value.
 *
 * ===========================================================================*/

/* Read one macro's value from gcc -dM -E output into value_out (a caller
 * buffer). Returns nonzero on success (macro found), zero if not found or on
 * tool failure; *tool_failed distinguishes the two. */
static int read_macro_value(const char *vendor_header_path,
                            const char *macro_name,
                            const char *include_flags,
                            const char *config_defines,
                            char       *value_out,
                            size_t      value_out_size,
                            int        *tool_failed)
{
        *tool_failed = 0;
        char command[8192];
        int written = snprintf(command, sizeof(command),
                               "gcc -dM -E %s %s '%s'",
                               include_flags, config_defines,
                               vendor_header_path);
        if (written <= 0 || (size_t)written >= sizeof(command)) {
                *tool_failed = 1;
                return 0;
        }
        FILE *pipe = popen(command, "r");
        if (pipe == NULL) {
                *tool_failed = 1;
                return 0;
        }

        /* build the exact prefix "#define NAME " to match */
        char needle[512];
        int nn = snprintf(needle, sizeof(needle), "#define %s ", macro_name);
        int found = 0;
        if (nn > 0 && (size_t)nn < sizeof(needle)) {
                char line[16384];
                while (fgets(line, sizeof(line), pipe) != NULL) {
                        if (!found
                            && strncmp(line, needle, (size_t)nn) == 0) {
                                const char *value = line + nn;
                                /* strip trailing newline */
                                size_t len = strlen(value);
                                while (len > 0 && (value[len - 1] == '\n'
                                               || value[len - 1] == '\r')) {
                                        len--;
                                }
                                if (len < value_out_size) {
                                        memcpy(value_out, value, len);
                                        value_out[len] = '\0';
                                        found = 1;
                                }
                                /* continue draining rather than break, so the
                                 * child sees its full output consumed and does
                                 * not exit on a broken pipe */
                        }
                }
        }
        if (pclose(pipe) != 0) {
                *tool_failed = 1;
                return 0;
        }
        return found;
}

/* Report whether gcc -dU lists macro_name (i.e. the preprocessor used it).
 * Returns 1 if used, 0 if not; *tool_failed set on tool error. */
static int macro_is_used(const char *vendor_header_path,
                         const char *macro_name,
                         const char *include_flags,
                         const char *config_defines,
                         int        *tool_failed)
{
        *tool_failed = 0;
        char command[8192];
        int written = snprintf(command, sizeof(command),
                               "gcc -dU -E %s %s '%s'",
                               include_flags, config_defines,
                               vendor_header_path);
        if (written <= 0 || (size_t)written >= sizeof(command)) {
                *tool_failed = 1;
                return 0;
        }
        FILE *pipe = popen(command, "r");
        if (pipe == NULL) {
                *tool_failed = 1;
                return 0;
        }

        /* -dU lists used macros as "#define NAME ..." or "#undef NAME". Match
         * the name as a whole token following either directive. */
        char define_needle[512];
        char undef_needle[512];
        int dn = snprintf(define_needle, sizeof(define_needle),
                          "#define %s", macro_name);
        int un = snprintf(undef_needle, sizeof(undef_needle),
                          "#undef %s", macro_name);
        int used = 0;
        if (dn > 0 && (size_t)dn < sizeof(define_needle)
            && un > 0 && (size_t)un < sizeof(undef_needle)) {
                char line[16384];
                while (fgets(line, sizeof(line), pipe) != NULL) {
                        if (used) {
                                continue; /* drain remaining output */
                        }
                        /* require the match be followed by end, space, or '('
                         * so NAME does not match NAME_LONGER */
                        if (strncmp(line, define_needle, (size_t)dn) == 0) {
                                char after = line[dn];
                                if (after == ' ' || after == '\t'
                                    || after == '(' || after == '\n'
                                    || after == '\0') {
                                        used = 1;
                                }
                        } else if (strncmp(line, undef_needle,
                                           (size_t)un) == 0) {
                                char after = line[un];
                                if (after == ' ' || after == '\t'
                                    || after == '\n' || after == '\0') {
                                        used = 1;
                                }
                        }
                }
        }
        if (pclose(pipe) != 0) {
                *tool_failed = 1;
                return 0;
        }
        return used;
}

/* ===========================================================================
 * [2] SAFETY CLASSIFICATION
 * ===========================================================================*/

StateCrossingResult vendor_macro_use_classify(const char     *vendor_header_path,
                                              const char     *macro_name,
                                              const char     *include_flags,
                                              const char     *config_defines,
                                              VendorMacroUse *use_out)
{
        /* is the macro defined at all? read its value; absence means undefined */
        char value[16384];
        int tool_failed = 0;
        int defined = read_macro_value(vendor_header_path, macro_name,
                                       include_flags, config_defines,
                                       value, sizeof(value), &tool_failed);
        if (tool_failed) {
                return STATE_CROSSING_TOOL_FAILED;
        }
        if (!defined) {
                *use_out = VENDOR_MACRO_USE_UNDEFINED;
                return STATE_CROSSING_OK;
        }

        int used = macro_is_used(vendor_header_path, macro_name,
                                 include_flags, config_defines, &tool_failed);
        if (tool_failed) {
                return STATE_CROSSING_TOOL_FAILED;
        }
        *use_out = used ? VENDOR_MACRO_USE_SELF_USED
                        : VENDOR_MACRO_USE_DEFINE_ONLY;
        return STATE_CROSSING_OK;
}

/* ===========================================================================
 * [3] GENERATION
 * ===========================================================================*/

StateCrossingResult state_crossing_generate_vendor_supersedes(
        const char *vendor_header_path,
        const char *macro_name,
        const char *include_flags,
        const char *config_defines,
        const char *output_header_path)
{
        char value[16384];
        int  tool_failed = 0;
        int  defined = read_macro_value(vendor_header_path, macro_name,
                                        include_flags, config_defines,
                                        value, sizeof(value), &tool_failed);
        if (tool_failed) {
                return STATE_CROSSING_TOOL_FAILED;
        }
        if (!defined) {
                return STATE_CROSSING_SYMBOL_UNDEFINED;
        }

        FILE *out = fopen(output_header_path, "w");
        if (out == NULL) {
                return STATE_CROSSING_WRITE_FAILED;
        }
        fprintf(out,
                "/* generated: State B (vendor supersedes) for %s.\n"
                " * The vendor's value is exposed under the project prefix; the\n"
                " * vendor header does not enter project translation units. */\n"
                "#ifndef GENERATED_VENDOR_SUPERSEDES_%s\n"
                "#define GENERATED_VENDOR_SUPERSEDES_%s\n"
                "#define %s%s %s\n"
                "#endif\n",
                macro_name, macro_name, macro_name,
                STATE_CROSSING_UNIVERSAL_PREFIX, macro_name, value);
        if (fclose(out) != 0) {
                return STATE_CROSSING_WRITE_FAILED;
        }
        return STATE_CROSSING_OK;
}

StateCrossingResult state_crossing_generate_project_supersedes(
        const char *vendor_header_path,
        const char *vendor_include_spec,
        const char *macro_name,
        const char *project_value,
        const char *include_flags,
        const char *config_defines,
        const char *output_header_path)
{
        /* safety gate: the vendor must not use the macro itself */
        VendorMacroUse use;
        StateCrossingResult classify =
                vendor_macro_use_classify(vendor_header_path, macro_name,
                                          include_flags, config_defines, &use);
        if (classify != STATE_CROSSING_OK) {
                return classify;
        }
        if (use == VENDOR_MACRO_USE_UNDEFINED) {
                return STATE_CROSSING_SYMBOL_UNDEFINED;
        }
        if (use == VENDOR_MACRO_USE_SELF_USED) {
                return STATE_CROSSING_UNSAFE_SUPERSEDE;
        }

        /* define-only: safe to generate the superseding wrapper */
        FILE *out = fopen(output_header_path, "w");
        if (out == NULL) {
                return STATE_CROSSING_WRITE_FAILED;
        }
        fprintf(out,
                "/* generated: State A (project supersedes) for %s.\n"
                " * The vendor is included, then the macro is redefined to the\n"
                " * project value so vendor code compiled through this wrapper\n"
                " * sees the project's definition. Safe: the vendor does not use\n"
                " * this macro itself (checked via gcc -dU). */\n"
                "%s\n"
                "#undef %s\n"
                "#define %s %s\n",
                macro_name, vendor_include_spec, macro_name,
                macro_name, project_value);
        if (fclose(out) != 0) {
                return STATE_CROSSING_WRITE_FAILED;
        }
        return STATE_CROSSING_OK;
}
