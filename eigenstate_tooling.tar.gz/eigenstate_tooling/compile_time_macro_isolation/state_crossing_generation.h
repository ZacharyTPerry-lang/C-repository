/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * state_crossing_generation.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_macro_isolation
 *
 * Purpose       : Realize the State Gate's directional value crossings for
 *                 whitelisted symbols by generating the headers the build
 *                 compiles. Two directions:
 *
 *   State B (vendor supersedes) : the vendor's value crosses into project space
 *     under the project prefix. A generated header defines the prefixed name to
 *     the vendor's value; project code includes that header and reads the value
 *     through the prefixed name, never touching the vendor header. Always safe:
 *     it introduces a new prefixed name and changes nothing the vendor sees.
 *
 *   State A (project supersedes) : the project's value crosses into vendor
 *     space, so vendor code compiles against the project's definition. A
 *     generated wrapper includes the vendor header, then undefines the macro
 *     and redefines it to the project value. This makes the project value win
 *     without editing the vendor source.
 *
 * The State A safety condition (why the guard is not optional):
 *
 *   Undefining and redefining after the vendor header changes the value only
 *   for code compiled AFTER the wrapper. If the vendor header used the macro in
 *   its OWN declarations, those already fixed the old value before the
 *   redefinition -- so vendor code would see the old value and project code the
 *   new one: the same symbol with two values in one build. Auto-generating the
 *   wrapper is therefore safe only when the vendor does not use the macro
 *   itself.
 *
 *   Whether the vendor uses the macro is read from the compiler, not guessed:
 *   gcc -dU reports every macro that was expanded or whose definedness was
 *   tested during preprocessing. A macro absent from -dU output was defined but
 *   never used -- safe to supersede. A macro present was used somehow (directly,
 *   transitively, in a function-like macro, or in an #if condition) -- unsafe,
 *   and generation errors rather than silently splitting the value. This is
 *   sound where value-probing is not: a use inside "#if X == 32" is invisible
 *   to any scheme that substitutes trial values, but -dU records it because the
 *   preprocessor genuinely read the macro.
 *
 * Portability   : C99 plus the gcc invocations (-dM -E for values, -dU -E for
 *                 the use check). File generation uses stdio.
 *
 * Table of contents:
 *   [1] SAFETY CLASSIFICATION
 *   [2] GENERATION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef STATE_CROSSING_GENERATION_H
#define STATE_CROSSING_GENERATION_H

#include <stddef.h>

#define STATE_CROSSING_UNIVERSAL_PREFIX "COMPILE_TIME_ENFORCEMENT_FRAMEWORK_"

/* ===========================================================================
 * [1] SAFETY CLASSIFICATION
 * ===========================================================================*/

typedef enum VendorMacroUse {
        /* The vendor defines the macro but does not use it: -dU does not list
         * it. State A may auto-generate a superseding wrapper. */
        VENDOR_MACRO_USE_DEFINE_ONLY,

        /* The vendor uses the macro (any form): -dU lists it. State A must not
         * auto-supersede; doing so would split the value. */
        VENDOR_MACRO_USE_SELF_USED,

        /* The macro is not defined by the vendor header at all. */
        VENDOR_MACRO_USE_UNDEFINED
} VendorMacroUse;

typedef enum StateCrossingResult {
        STATE_CROSSING_OK,

        /* A gcc invocation failed. */
        STATE_CROSSING_TOOL_FAILED,

        /* State A was requested for a symbol the vendor uses itself: auto-
         * superseding would give vendor and project code different values.
         * Generation refuses; the developer must define the override
         * explicitly. */
        STATE_CROSSING_UNSAFE_SUPERSEDE,

        /* The requested symbol is not defined by the vendor header. */
        STATE_CROSSING_SYMBOL_UNDEFINED,

        /* A generated file could not be written. */
        STATE_CROSSING_WRITE_FAILED,

        STATE_CROSSING_OUT_OF_MEMORY
} StateCrossingResult;

/* ---------------------------------------------------------------------------
 *  Operation : vendor_macro_use_classify
 *
 *  Determine whether a vendor header uses a given macro, by reading gcc -dU.
 *  The result distinguishes define-only (safe to supersede) from self-used
 *  (unsafe) from undefined.
 *
 *  IN   vendor_header_path  VALID    CONSUME   ALWAYS      KEEP  NONE
 *  IN   macro_name          VALID    CONSUME   ALWAYS      KEEP  NONE
 *  IN   include_flags       VALID    CONSUME   ALWAYS      KEEP  NONE  or ""
 *  IN   config_defines      VALID    CONSUME   ALWAYS      KEEP  NONE  or ""
 *  OUT  use_out             GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE
 * ---------------------------------------------------------------------------*/
StateCrossingResult vendor_macro_use_classify(const char     *vendor_header_path,
                                              const char     *macro_name,
                                              const char     *include_flags,
                                              const char     *config_defines,
                                              VendorMacroUse *use_out);

/* ===========================================================================
 * [2] GENERATION
 * ===========================================================================*/

/* ---------------------------------------------------------------------------
 *  Operation : state_crossing_generate_vendor_supersedes
 *
 *  State B. Extract the vendor's value for macro_name and write a generated
 *  header defining the prefixed name to that value. Always safe.
 *
 *  IN  vendor_header_path   VALID  CONSUME  ALWAYS  KEEP  NONE
 *  IN  macro_name           VALID  CONSUME  ALWAYS  KEEP  NONE
 *  IN  include_flags        VALID  CONSUME  ALWAYS  KEEP  NONE  or ""
 *  IN  config_defines       VALID  CONSUME  ALWAYS  KEEP  NONE  or ""
 *  IN  output_header_path   VALID  CONSUME  ALWAYS  KEEP  NONE  file to write
 * ---------------------------------------------------------------------------*/
StateCrossingResult state_crossing_generate_vendor_supersedes(
        const char *vendor_header_path,
        const char *macro_name,
        const char *include_flags,
        const char *config_defines,
        const char *output_header_path);

/* ---------------------------------------------------------------------------
 *  Operation : state_crossing_generate_project_supersedes
 *
 *  State A. First classify the vendor's use of macro_name; if the vendor uses
 *  it, return STATE_CROSSING_UNSAFE_SUPERSEDE and write nothing. If define-only,
 *  write a generated wrapper that includes the vendor header, then undefines
 *  macro_name and redefines it to project_value, so vendor code compiled through
 *  the wrapper sees the project value.
 *
 *  IN  vendor_header_path   VALID  CONSUME  ALWAYS  KEEP  NONE
 *  IN  vendor_include_spec  VALID  CONSUME  ALWAYS  KEEP  NONE  the #include
 *                                                              text to emit
 *  IN  macro_name           VALID  CONSUME  ALWAYS  KEEP  NONE
 *  IN  project_value        VALID  CONSUME  ALWAYS  KEEP  NONE  value text
 *  IN  include_flags        VALID  CONSUME  ALWAYS  KEEP  NONE  or ""
 *  IN  config_defines       VALID  CONSUME  ALWAYS  KEEP  NONE  or ""
 *  IN  output_header_path   VALID  CONSUME  ALWAYS  KEEP  NONE  file to write
 * ---------------------------------------------------------------------------*/
StateCrossingResult state_crossing_generate_project_supersedes(
        const char *vendor_header_path,
        const char *vendor_include_spec,
        const char *macro_name,
        const char *project_value,
        const char *include_flags,
        const char *config_defines,
        const char *output_header_path);

#endif /* STATE_CROSSING_GENERATION_H */
