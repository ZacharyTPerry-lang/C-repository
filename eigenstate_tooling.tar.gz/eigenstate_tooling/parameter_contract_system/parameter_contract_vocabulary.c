/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * parameter_contract_vocabulary.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : parameter_contract_system
 *
 * Purpose       : The single instance of the parameter contract vocabulary.
 *                 This file IS the grammar. To add a contract term, edit the
 *                 tables below and nothing else in the tool changes.
 *
 * Portability   : C99. All data is static and const.
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "parameter_contract_vocabulary.h"

#include <string.h>

/* ===========================================================================
 * THE VOCABULARY DATA
 * ===========================================================================
 *
 *  Five axes, in source order. Each axis lists its legal tokens. A token that
 *  takes a peer-parameter argument carries the flag 1; a bare token carries 0.
 *
 *  This is the entire grammar of the parameter contract language. Everything
 *  the recognizer accepts and the translator emits is determined by these
 *  tables. Adding a token is a line; adding an axis is a block plus one entry
 *  in the axis array.
 *
 * ===========================================================================*/

/* --- axis 1 : STATE -------------------------------------------------------
 *  "What state is this parameter in when the function is called." */
static const ParameterContractToken parameter_contract_tokens_state[] = {
        { "VALID",   0 },
        { "GARBAGE", 0 }
};

/* --- axis 2 : ACTION ------------------------------------------------------
 *  "What the function does to the parameter." */
static const ParameterContractToken parameter_contract_tokens_action[] = {
        { "CONSUME",  0 },
        { "POPULATE", 0 },
        { "MUTATE",   0 },
        { "FORCE",    0 },
        { "COERCE",   0 },
        { "INVOKE",   0 },
        { "VERIFY",   0 }
};

/* --- axis 3 : CONTRACT ----------------------------------------------------
 *  "When the parameter must be valid." The IF_* tokens take a peer-parameter
 *  argument naming another parameter in the same function signature. */
static const ParameterContractToken parameter_contract_tokens_contract[] = {
        { "ALWAYS",     0 },
        { "NEVER",      0 },
        { "IF_NONZERO", 1 },
        { "IF_ZERO",    1 },
        { "IF_NULL",    1 },
        { "IF_NONNULL", 1 },
        { "IF_SUCCESS", 0 },
        { "IF_FAILURE", 0 }
};

/* --- axis 4 : CONTROL -----------------------------------------------------
 *  "Who owns the parameter's lifetime." */
static const ParameterContractToken parameter_contract_tokens_control[] = {
        { "KEEP", 0 },
        { "GIVE", 0 },
        { "NONE", 0 }
};

/* --- axis 5 : LAYER_TWO_DIAGNOSTIC ----------------------------------------
 *  "Whether the runtime diagnostic system watches this parameter." NONE is the
 *  explicit default, always written, never omitted. Every token here compiles
 *  to nothing in release builds -- but that is the translator's behavior, not
 *  the vocabulary's; here these are simply the legal spellings. */
static const ParameterContractToken parameter_contract_tokens_layer_two[] = {
        { "NONE",       0 },
        { "PROVENANCE", 0 },
        { "TRANSIT",    0 },
        { "ANOMALY",    0 },
        { "SHADOW",     0 }
};

/* --- the axes, in source order ------------------------------------------- */
static const ParameterContractAxis parameter_contract_axes[] = {
        { "STATE",
          parameter_contract_tokens_state,
          sizeof(parameter_contract_tokens_state)
                  / sizeof(parameter_contract_tokens_state[0]) },
        { "ACTION",
          parameter_contract_tokens_action,
          sizeof(parameter_contract_tokens_action)
                  / sizeof(parameter_contract_tokens_action[0]) },
        { "CONTRACT",
          parameter_contract_tokens_contract,
          sizeof(parameter_contract_tokens_contract)
                  / sizeof(parameter_contract_tokens_contract[0]) },
        { "CONTROL",
          parameter_contract_tokens_control,
          sizeof(parameter_contract_tokens_control)
                  / sizeof(parameter_contract_tokens_control[0]) },
        { "LAYER_TWO_DIAGNOSTIC",
          parameter_contract_tokens_layer_two,
          sizeof(parameter_contract_tokens_layer_two)
                  / sizeof(parameter_contract_tokens_layer_two[0]) }
};

static const ParameterContractVocabulary parameter_contract_vocabulary = {
        parameter_contract_axes,
        sizeof(parameter_contract_axes)
                / sizeof(parameter_contract_axes[0])
};

/* ===========================================================================
 * ACCESS
 * ===========================================================================*/

const ParameterContractVocabulary *parameter_contract_vocabulary_get(void)
{
        return &parameter_contract_vocabulary;
}

int parameter_contract_axis_permits(const ParameterContractAxis *axis,
                                     const char                  *spelling,
                                     int                         *takes_peer_argument_out)
{
        size_t index;
        for (index = 0; index < axis->token_count; index++) {
                if (strcmp(axis->tokens[index].spelling, spelling) == 0) {
                        if (takes_peer_argument_out != NULL) {
                                *takes_peer_argument_out =
                                        axis->tokens[index].takes_peer_argument;
                        }
                        return 1;
                }
        }
        return 0;
}
