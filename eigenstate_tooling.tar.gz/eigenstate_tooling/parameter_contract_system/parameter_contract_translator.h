/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * parameter_contract_translator.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : parameter_contract_system
 *
 * Purpose       : Given a recognized annotation, produce what the compiler
 *                 should see in its place. The first four axes are inert to the
 *                 compiler and are removed so the emitted signature is clean C;
 *                 they are recorded as data for the static analyzer and the
 *                 contract index. The fifth axis drives runtime diagnostic
 *                 instrumentation and is emitted or removed according to the
 *                 build mode.
 *
 * Separation    : recognition already found the annotation and its per-axis
 *                 spans; this module decides what to EMIT. It does not scan and
 *                 does not re-check legality. Detection in the recognizer,
 *                 emission here.
 *
 * What "emit"   : this module reports, for a matched annotation, the byte range
 * means            of the source to DROP (the annotation tokens) and, in a
 *                 debug build, any instrumentation text to inject. It does not
 *                 itself write the output stream; the rewriter owns the output
 *                 buffer and applies the drop and inject the translator
 *                 specifies. Keeping emission as a description rather than an
 *                 action lets the rewriter apply contract edits and boundary
 *                 edits to one buffer coherently.
 *
 * Build modes   : RELEASE removes the fifth axis entirely -- every Layer 2
 *                 token compiles to nothing. DEBUG preserves the fifth axis as
 *                 instrumentation. Which text the debug instrumentation is is
 *                 not fixed here beyond a hook, because the Layer 2 runtime is a
 *                 separate subsystem; this module marks WHERE and WITH WHICH
 *                 token instrumentation applies and leaves the expansion to the
 *                 caller-supplied emitter.
 *
 * Portability   : C99. Freestanding: depends on <stddef.h>, the vocabulary, and
 *                 the recognizer's match type.
 *
 * Table of contents:
 *   [1] BUILD MODE
 *   [2] TRANSLATION PLAN
 *   [3] TRANSLATION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef PARAMETER_CONTRACT_TRANSLATOR_H
#define PARAMETER_CONTRACT_TRANSLATOR_H

#include <stddef.h>
#include "parameter_contract_recognizer.h"

/* ===========================================================================
 * [1] BUILD MODE
 * ===========================================================================*/

typedef enum ParameterContractBuildMode {
        /* Fifth axis removed with the rest: the annotation vanishes entirely. */
        PARAMETER_CONTRACT_BUILD_MODE_RELEASE,

        /* Fifth axis preserved as diagnostic instrumentation. */
        PARAMETER_CONTRACT_BUILD_MODE_DEBUG
} ParameterContractBuildMode;

/* ===========================================================================
 * [2] TRANSLATION PLAN
 * ===========================================================================
 *
 *  The description of what to do with one matched annotation. In both build
 *  modes the annotation's source span is dropped; what differs is whether the
 *  fifth axis contributes recorded diagnostic intent.
 *
 * ---------------------------------------------------------------------------
 *  drop_start        byte offset where the removed annotation span begins
 *  drop_end          byte offset one past the removed span; the declarator that
 *                    the annotation qualified begins at or after this offset,
 *                    and is NOT part of the drop
 *  layer_two_start   byte range of the fifth-axis token, recorded so the caller
 *  layer_two_end     can associate diagnostic intent with the parameter; equal
 *                    offsets when there is nothing to record
 *  emit_layer_two    nonzero if the build mode keeps the fifth axis as
 *                    instrumentation; zero if it compiles out
 * ---------------------------------------------------------------------------*/

typedef struct ParameterContractTranslationPlan {
        size_t drop_start;
        size_t drop_end;
        size_t layer_two_start;
        size_t layer_two_end;
        int    emit_layer_two;
} ParameterContractTranslationPlan;

/* ===========================================================================
 * [3] TRANSLATION
 * ===========================================================================*/

/* ---------------------------------------------------------------------------
 *  Operation : parameter_contract_translate
 *
 *  Turn a recognized annotation into a translation plan for the given build
 *  mode. The annotation's whole token span is dropped; the fifth axis's span is
 *  reported for the caller to record, and emit_layer_two reflects the mode.
 *
 *  The four contract axes are not emitted in either mode -- they are compile-
 *  time documentation consumed by analysis, never by the C compiler. Recording
 *  them as data is the caller's step, using the per-axis spans already in the
 *  match; this function's plan concerns only what the emitted C changes.
 *
 *  IN   match       VALID    CONSUME   ALWAYS      KEEP  NONE  a matched
 *                                                              annotation
 *  IN   build_mode  VALID    CONSUME   ALWAYS      NONE  NONE  release or debug
 *  OUT  plan_out    GARBAGE  POPULATE  ALWAYS      KEEP  NONE  the plan
 * ---------------------------------------------------------------------------*/
void parameter_contract_translate(const ParameterContractMatch     *match,
                                  ParameterContractBuildMode        build_mode,
                                  ParameterContractTranslationPlan *plan_out);

#endif /* PARAMETER_CONTRACT_TRANSLATOR_H */
