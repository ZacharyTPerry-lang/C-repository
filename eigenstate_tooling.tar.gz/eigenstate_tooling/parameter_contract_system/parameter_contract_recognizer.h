/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * parameter_contract_recognizer.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : parameter_contract_system
 *
 * Purpose       : Decide whether a run of source tokens is a parameter contract
 *                 annotation, by walking the vocabulary one axis at a time. The
 *                 recognizer's single job is DETECTION: given a position in a
 *                 token stream, does a complete annotation begin here, and if
 *                 so where does it end and what did each axis match.
 *
 * Separation    : the recognizer holds no token spellings and no axis names. It
 *                 asks the vocabulary "is this spelling legal for this axis."
 *                 Adding a token or an axis to the vocabulary changes what the
 *                 recognizer accepts without changing a line of the recognizer.
 *                 Detection here, transformation in the translator, grammar in
 *                 the vocabulary: three jobs, three modules.
 *
 * Method        : for each axis in order, take the next identifier token and
 *                 test it against that axis. A miss on any axis means the run
 *                 is not an annotation, and the recognizer reports no match
 *                 without consuming anything the caller must roll back. A hit
 *                 on every axis, followed by the parameter's declarator, is a
 *                 match. A token that takes a peer argument is followed in
 *                 source by "(peer)", which the recognizer spans as part of
 *                 that axis's match.
 *
 * Portability   : C99. Freestanding: depends on <stddef.h>, the vocabulary, and
 *                 the lexical scanner's token type. No allocation.
 *
 * Table of contents:
 *   [1] MATCH RESULT
 *   [2] RECOGNITION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef PARAMETER_CONTRACT_RECOGNIZER_H
#define PARAMETER_CONTRACT_RECOGNIZER_H

#include <stddef.h>
#include "parameter_contract_vocabulary.h"
#include "lexical_scanner.h"

/* Maximum axes the match result can hold. Sized generously above the current
 * five so adding axes to the vocabulary does not require touching this bound.
 * A vocabulary with more axes than this is rejected at recognition time rather
 * than overrunning. */
#define PARAMETER_CONTRACT_MAX_AXES 16

/* ===========================================================================
 * [1] MATCH RESULT
 * ===========================================================================
 *
 *  What the recognizer found. For a match, it records, per axis, the byte span
 *  of the matched token (including any peer argument) so the translator can
 *  strip exactly those spans. It also records where the whole annotation ends,
 *  which is where the parameter's declarator begins.
 *
 * ---------------------------------------------------------------------------
 *  matched               nonzero if a complete annotation was recognized
 *  axis_token_start[i]   byte offset where axis i's matched token begins
 *  axis_token_end[i]     byte offset one past axis i's matched token (spanning
 *                        a peer argument if the token took one)
 *  axis_match_count      number of axes matched (equals the vocabulary's axis
 *                        count on a match)
 *  annotation_end        byte offset one past the last axis token; the
 *                        declarator that the annotation qualifies starts at or
 *                        after this offset
 * ---------------------------------------------------------------------------*/

typedef struct ParameterContractMatch {
        int    matched;
        size_t axis_token_start[PARAMETER_CONTRACT_MAX_AXES];
        size_t axis_token_end[PARAMETER_CONTRACT_MAX_AXES];
        size_t axis_match_count;
        size_t annotation_end;
} ParameterContractMatch;

/* ===========================================================================
 * [2] RECOGNITION
 * ===========================================================================*/

/* ---------------------------------------------------------------------------
 *  Operation : parameter_contract_recognize
 *
 *  Attempt to recognize a complete annotation beginning at the given token
 *  index within a token array over a source buffer. Whitespace and comment
 *  tokens between axis tokens are skipped. On a match, match_out->matched is
 *  nonzero and the per-axis spans and annotation_end are filled. On no match,
 *  match_out->matched is zero and the rest of match_out is unspecified; the
 *  caller advances past the current token and tries again elsewhere.
 *
 *  The recognizer does not read the meaning of any token. It only confirms
 *  each position holds a spelling the vocabulary permits for that axis. Whether
 *  VALID means one thing and GARBAGE another is the translator's concern.
 *
 *  IN   source_buffer   VALID    CONSUME   ALWAYS      KEEP  NONE  the bytes the
 *                                                                  tokens index
 *  IN   tokens          VALID    CONSUME   ALWAYS      KEEP  NONE  token array
 *  IN   token_count     VALID    CONSUME   ALWAYS      NONE  NONE  tokens length
 *  IN   start_index     VALID    CONSUME   ALWAYS      NONE  NONE  where to try
 *  OUT  match_out       GARBAGE  POPULATE  ALWAYS      KEEP  NONE  the result
 * ---------------------------------------------------------------------------*/
void parameter_contract_recognize(const unsigned char    *source_buffer,
                                  const LexicalToken     *tokens,
                                  size_t                  token_count,
                                  size_t                  start_index,
                                  ParameterContractMatch *match_out);

#endif /* PARAMETER_CONTRACT_RECOGNIZER_H */
