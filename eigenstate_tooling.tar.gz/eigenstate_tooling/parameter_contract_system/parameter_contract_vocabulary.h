/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * parameter_contract_vocabulary.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : parameter_contract_system
 *
 * Purpose       : Define the parameter contract annotation language as DATA.
 *                 The annotation grammar is a fixed number of axes, each in a
 *                 fixed position, each admitting a fixed set of tokens. This
 *                 header declares the shape of that data; the paired source
 *                 file holds the one instance of it.
 *
 * The one rule  : this is the file edited to add or change a contract term.
 *                 Adding a token to an axis is adding an entry to that axis's
 *                 token list. Adding a whole axis is adding an axis entry. The
 *                 recognizer and translator read this data and never hard-code
 *                 a token; they do not change when the vocabulary changes. That
 *                 separation is the point: the grammar grows here, the engine
 *                 stays still.
 *
 * Grammar today : five axes, in this order, every one present on every
 *                 annotated parameter, NONE the explicit default where an axis
 *                 admits it:
 *
 *                   STATE   ACTION   CONTRACT   CONTROL   LAYER_TWO_DIAGNOSTIC
 *
 *                 The first four describe the parameter's contract with the
 *                 function. The fifth describes the parameter's relationship
 *                 with the runtime diagnostic system and compiles out entirely
 *                 in release builds. The vocabulary does not encode that
 *                 release behavior; it encodes only which tokens are legal in
 *                 each position. What a token MEANS is the translator's
 *                 concern, not the vocabulary's.
 *
 * Portability   : C99. Freestanding: depends only on <stddef.h>. No allocation,
 *                 the data is static.
 *
 * Table of contents:
 *   [1] AXIS AND TOKEN SHAPE
 *   [2] VOCABULARY ACCESS
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef PARAMETER_CONTRACT_VOCABULARY_H
#define PARAMETER_CONTRACT_VOCABULARY_H

#include <stddef.h>

/* ===========================================================================
 * [1] AXIS AND TOKEN SHAPE
 * ===========================================================================
 *
 *  A token is a spelling plus a flag marking whether it takes a peer-parameter
 *  argument. Most tokens are bare words (VALID, CONSUME, ALWAYS). Some CONTRACT
 *  tokens are parameterized on a peer: IF_NONZERO(peer) is required only when
 *  the named peer parameter is nonzero. The vocabulary records that a token is
 *  parameterized; it does not record which peer, because the peer is written
 *  at the call site, not in the grammar.
 *
 * ---------------------------------------------------------------------------
 *  spelling               the exact token text as written in source, without
 *                         any peer argument (e.g. "IF_NONZERO", not
 *                         "IF_NONZERO(len)")
 *  takes_peer_argument    nonzero if the token is followed by "(peer)" in
 *                         source; zero for a bare token
 * ---------------------------------------------------------------------------*/

typedef struct ParameterContractToken {
        const char *spelling;
        int         takes_peer_argument;
} ParameterContractToken;

/* ---------------------------------------------------------------------------
 *  An axis is a named position in the annotation, holding the set of tokens
 *  legal in that position. The order of axes in the vocabulary is the order
 *  they appear in source; the recognizer consumes one token per axis in this
 *  order.
 *
 *  axis_name        human-readable name of the position (STATE, ACTION, ...);
 *                   used in diagnostics, not matched in source
 *  tokens           array of legal tokens for this position
 *  token_count      number of tokens in the array
 * ---------------------------------------------------------------------------*/

typedef struct ParameterContractAxis {
        const char                   *axis_name;
        const ParameterContractToken *tokens;
        size_t                        token_count;
} ParameterContractAxis;

/* ---------------------------------------------------------------------------
 *  The vocabulary is the ordered list of axes. This is the whole grammar.
 *
 *  axes         array of axes in source order
 *  axis_count   number of axes; also the exact token count of one annotation
 * ---------------------------------------------------------------------------*/

typedef struct ParameterContractVocabulary {
        const ParameterContractAxis *axes;
        size_t                       axis_count;
} ParameterContractVocabulary;

/* ===========================================================================
 * [2] VOCABULARY ACCESS
 * ===========================================================================*/

/* ---------------------------------------------------------------------------
 *  Operation : parameter_contract_vocabulary_get
 *
 *  Return the single, static vocabulary instance. The returned pointer is to
 *  static storage that lives for the program's duration; the caller does not
 *  free it and must not modify it.
 *
 *  OUT return  VALID  POPULATE  ALWAYS  KEEP  NONE  the static vocabulary
 * ---------------------------------------------------------------------------*/
const ParameterContractVocabulary *parameter_contract_vocabulary_get(void);

/* ---------------------------------------------------------------------------
 *  Operation : parameter_contract_axis_permits
 *
 *  Report whether a spelling is a legal token for a given axis, and if so
 *  whether that token takes a peer argument. Lets the recognizer test a token
 *  against an axis without reaching into the axis's token array itself.
 *
 *  Returns nonzero if the spelling is legal for the axis. When it returns
 *  nonzero and takes_peer_argument_out is not NULL, it is set to the token's
 *  peer-argument flag.
 *
 *  IN   axis                     VALID    CONSUME   ALWAYS      KEEP  NONE  axis
 *  IN   spelling                 VALID    CONSUME   ALWAYS      KEEP  NONE  text
 *  OUT  takes_peer_argument_out  GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE  flag
 * ---------------------------------------------------------------------------*/
int parameter_contract_axis_permits(const ParameterContractAxis *axis,
                                     const char                  *spelling,
                                     int                         *takes_peer_argument_out);

#endif /* PARAMETER_CONTRACT_VOCABULARY_H */
