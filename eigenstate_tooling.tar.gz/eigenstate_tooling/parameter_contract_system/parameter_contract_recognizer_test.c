/* Unit test for parameter_contract_vocabulary + parameter_contract_recognizer.
 * Verifies: the vocabulary reports legal/illegal tokens correctly; the
 * recognizer detects a full five-axis annotation, spans peer arguments, and
 * rejects incomplete or malformed runs. Uses the real lexer to tokenize. */

#include "parameter_contract_recognizer.h"
#include "lexical_scanner.h"
#include <stdio.h>
#include <string.h>

static int failures = 0;

/* tokenize an entire string into a fixed array; return count */
static size_t tokenize(const char *src, LexicalToken *out, size_t max)
{
        LexicalScannerState st;
        LexicalToken t;
        size_t n = 0;
        lexical_scanner_initialize(&st, (const unsigned char *)src, strlen(src));
        while (n < max && lexical_scanner_next_token(&st, &t)) {
                out[n++] = t;
        }
        return n;
}

static void check_recognize(const char *label, const char *src,
                            int expect_match, size_t expect_axes)
{
        LexicalToken tokens[256];
        size_t count = tokenize(src, tokens, 256);
        ParameterContractMatch match;
        /* start at the first significant token */
        parameter_contract_recognize((const unsigned char *)src, tokens, count,
                                      0, &match);
        if (match.matched != expect_match) {
                printf("  FAIL [%s]: matched=%d expected %d\n",
                       label, match.matched, expect_match);
                failures++;
                return;
        }
        if (expect_match && match.axis_match_count != expect_axes) {
                printf("  FAIL [%s]: matched %zu axes, expected %zu\n",
                       label, match.axis_match_count, expect_axes);
                failures++;
                return;
        }
        printf("  pass [%s]: matched=%d axes=%zu\n",
               label, match.matched,
               expect_match ? match.axis_match_count : (size_t)0);
}

int main(void)
{
        const ParameterContractVocabulary *vocab =
                parameter_contract_vocabulary_get();

        printf("vocabulary shape:\n");
        if (vocab->axis_count == 5) {
                printf("  pass: five axes\n");
        } else {
                printf("  FAIL: %zu axes, expected 5\n", vocab->axis_count);
                failures++;
        }

        printf("axis membership:\n");
        int peer = -1;
        if (parameter_contract_axis_permits(&vocab->axes[0], "VALID", &peer)
            && peer == 0) {
                printf("  pass: STATE permits VALID (no peer)\n");
        } else { printf("  FAIL: STATE/VALID\n"); failures++; }

        if (!parameter_contract_axis_permits(&vocab->axes[0], "CONSUME", NULL)) {
                printf("  pass: STATE rejects CONSUME (wrong axis)\n");
        } else { printf("  FAIL: STATE wrongly permits CONSUME\n"); failures++; }

        if (parameter_contract_axis_permits(&vocab->axes[2], "IF_NONZERO", &peer)
            && peer == 1) {
                printf("  pass: CONTRACT permits IF_NONZERO (takes peer)\n");
        } else { printf("  FAIL: CONTRACT/IF_NONZERO peer flag\n"); failures++; }

        printf("recognition:\n");
        /* full five-axis annotation, all bare tokens, then a declarator */
        check_recognize("full-bare",
                "VALID CONSUME ALWAYS KEEP NONE const char *path", 1, 5);
        /* full annotation with a peer-argument CONTRACT token */
        check_recognize("with-peer",
                "GARBAGE POPULATE IF_NONZERO(length) KEEP NONE unsigned char *buffer",
                1, 5);
        /* only four axes present -> not an annotation */
        check_recognize("too-few",
                "VALID CONSUME ALWAYS KEEP int x", 0, 0);
        /* an illegal token in axis 1 -> not an annotation */
        check_recognize("bad-axis-one",
                "MAYBE CONSUME ALWAYS KEEP NONE int x", 0, 0);
        /* peer token missing its (peer) -> not an annotation */
        check_recognize("peer-without-arg",
                "GARBAGE POPULATE IF_NONZERO KEEP NONE int x", 0, 0);
        /* a plain declaration with no annotation -> not an annotation */
        check_recognize("plain-decl",
                "int project_lookup(int index)", 0, 0);

        if (failures == 0) {
                printf("ALL CONTRACT-RECOGNIZER TESTS PASS\n");
                return 0;
        }
        printf("%d CONTRACT-RECOGNIZER TEST(S) FAILED\n", failures);
        return 1;
}
