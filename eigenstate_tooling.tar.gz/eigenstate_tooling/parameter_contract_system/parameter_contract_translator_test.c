#include "parameter_contract_translator.h"
#include "parameter_contract_recognizer.h"
#include "lexical_scanner.h"
#include <stdio.h>
#include <string.h>
static int fails=0;
static size_t tok(const char*s,LexicalToken*o,size_t m){
    LexicalScannerState st;LexicalToken t;size_t n=0;
    lexical_scanner_initialize(&st,(const unsigned char*)s,strlen(s));
    while(n<m&&lexical_scanner_next_token(&st,&t)){o[n++]=t;}
    return n;
}
static void run(const char*label,const char*src,ParameterContractBuildMode mode,
                const char*expect_remainder){
    LexicalToken tk[256];size_t n=tok(src,tk,256);
    ParameterContractMatch m;
    parameter_contract_recognize((const unsigned char*)src,tk,n,0,&m);
    if(!m.matched){printf("  FAIL [%s]: no match\n",label);fails++;return;}
    ParameterContractTranslationPlan plan;
    parameter_contract_translate(&m,mode,&plan);
    /* apply the drop: everything before drop_start + everything from drop_end */
    char out[512];int o=0;
    for(size_t i=0;i<strlen(src);i++){
        if(i>=plan.drop_start && i<plan.drop_end) continue;
        out[o++]=src[i];
    }
    out[o]='\0';
    /* trim leading spaces for comparison */
    char*p=out; while(*p==' ')p++;
    if(strcmp(p,expect_remainder)==0)
        printf("  pass [%s]: remainder '%s' | emit_l2=%d\n",label,p,plan.emit_layer_two);
    else{printf("  FAIL [%s]: got '%s' want '%s'\n",label,p,expect_remainder);fails++;}
}
int main(void){
    /* release: whole annotation dropped, only the declarator remains */
    run("release-bare","VALID CONSUME ALWAYS KEEP NONE const char *path",
        PARAMETER_CONTRACT_BUILD_MODE_RELEASE,"const char *path");
    run("release-peer","GARBAGE POPULATE IF_NONZERO(length) KEEP NONE unsigned char *buffer",
        PARAMETER_CONTRACT_BUILD_MODE_RELEASE,"unsigned char *buffer");
    /* debug: same drop span, but emit_layer_two is set */
    run("debug-bare","VALID CONSUME ALWAYS KEEP SHADOW int *value",
        PARAMETER_CONTRACT_BUILD_MODE_DEBUG,"int *value");
    if(fails==0){printf("ALL TRANSLATOR TESTS PASS\n");return 0;}
    printf("%d FAILED\n",fails);return 1;
}
