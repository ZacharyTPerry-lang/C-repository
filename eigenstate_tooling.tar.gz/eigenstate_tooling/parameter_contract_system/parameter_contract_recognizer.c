/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * parameter_contract_recognizer.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : parameter_contract_system
 *
 * Purpose       : Implementation of annotation detection. Walks the vocabulary
 *                 axis by axis, matching one source token per axis. Contains no
 *                 token spelling and no axis name of its own.
 *
 * Portability   : C99.
 *
 * Table of contents:
 *   [1] TOKEN NAVIGATION
 *   [2] PEER ARGUMENT SPAN
 *   [3] RECOGNITION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "parameter_contract_recognizer.h"

#include <string.h>

/* ===========================================================================
 * [1] TOKEN NAVIGATION
 * ===========================================================================
 *
 *  The recognizer steps over whitespace and comment tokens between the
 *  meaningful tokens of an annotation, so the source may space and comment its
 *  annotations freely. These helpers advance an index to the next significant
 *  token and extract a token's text for comparison.
 *
 * ===========================================================================*/

static int gate_token_is_skippable(const LexicalToken *token)
{
        return token->category == LEXICAL_TOKEN_CATEGORY_WHITESPACE
            || token->category == LEXICAL_TOKEN_CATEGORY_COMMENT;
}

/* Advance index past skippable tokens; return the index of the next
 * significant token, or token_count if none remain. */
static size_t next_significant_token(const LexicalToken *tokens,
                                     size_t              token_count,
                                     size_t              index)
{
        while (index < token_count && gate_token_is_skippable(&tokens[index])) {
                index++;
        }
        return index;
}

/* Compare an identifier token's text against a NUL-terminated spelling.
 * Returns nonzero on an exact, whole-token match. */
static int token_text_equals(const unsigned char *source_buffer,
                             const LexicalToken  *token,
                             const char          *spelling)
{
        size_t token_length = token->byte_offset_end - token->byte_offset_start;
        size_t spelling_length = strlen(spelling);
        if (token_length != spelling_length) {
                return 0;
        }
        return memcmp(source_buffer + token->byte_offset_start,
                      spelling, token_length) == 0;
}

/* ===========================================================================
 * [2] PEER ARGUMENT SPAN
 * ===========================================================================
 *
 *  A token that takes a peer argument is written "SPELLING(peer)". After
 *  matching such a token, the recognizer spans the following "(", peer
 *  identifier, and ")" so the axis's match covers the whole construct. The
 *  span is expressed as the index one past the closing parenthesis and the
 *  byte offset of its end.
 *
 * ===========================================================================*/

/* Given that tokens[open_index] should be '(', span to the matching ')'.
 * Returns nonzero on a well-formed "(peer)" and sets *after_index and
 * *end_offset; returns zero if the shape is not "( identifier )". */
static int span_peer_argument(const LexicalToken *tokens,
                              size_t              token_count,
                              size_t              open_index,
                              size_t             *after_index,
                              size_t             *end_offset)
{
        size_t index = next_significant_token(tokens, token_count, open_index);
        if (index >= token_count
            || tokens[index].category != LEXICAL_TOKEN_CATEGORY_PUNCTUATOR) {
                return 0;
        }
        /* the punctuator must be '(' : single-byte punctuator token */
        /* caller guarantees source has '(' here only by category; we cannot
         * read the byte without the buffer, so we rely on the grammar: a peer
         * token is always followed by '('. The closing ')' is found by
         * scanning punctuators. */
        index++;
        index = next_significant_token(tokens, token_count, index);
        if (index >= token_count
            || tokens[index].category != LEXICAL_TOKEN_CATEGORY_IDENTIFIER) {
                return 0;
        }
        index++;
        index = next_significant_token(tokens, token_count, index);
        if (index >= token_count
            || tokens[index].category != LEXICAL_TOKEN_CATEGORY_PUNCTUATOR) {
                return 0;
        }
        *end_offset  = tokens[index].byte_offset_end;
        *after_index = index + 1;
        return 1;
}

/* ===========================================================================
 * [3] RECOGNITION
 * ===========================================================================*/

void parameter_contract_recognize(const unsigned char    *source_buffer,
                                  const LexicalToken     *tokens,
                                  size_t                  token_count,
                                  size_t                  start_index,
                                  ParameterContractMatch *match_out)
{
        const ParameterContractVocabulary *vocabulary =
                parameter_contract_vocabulary_get();

        match_out->matched          = 0;
        match_out->axis_match_count = 0;

        if (vocabulary->axis_count > PARAMETER_CONTRACT_MAX_AXES) {
                return; /* vocabulary outgrew the match buffer; no match */
        }

        size_t index = next_significant_token(tokens, token_count, start_index);
        size_t axis_index;

        for (axis_index = 0; axis_index < vocabulary->axis_count; axis_index++) {
                const ParameterContractAxis *axis =
                        &vocabulary->axes[axis_index];

                if (index >= token_count
                    || tokens[index].category
                               != LEXICAL_TOKEN_CATEGORY_IDENTIFIER) {
                        return; /* position does not hold an identifier */
                }

                /* find which token of this axis, if any, the identifier is */
                int      matched_this_axis   = 0;
                int      takes_peer_argument = 0;
                size_t   token_in_axis;
                for (token_in_axis = 0;
                     token_in_axis < axis->token_count;
                     token_in_axis++) {
                        if (token_text_equals(source_buffer, &tokens[index],
                                axis->tokens[token_in_axis].spelling)) {
                                matched_this_axis   = 1;
                                takes_peer_argument =
                                        axis->tokens[token_in_axis]
                                                .takes_peer_argument;
                                break;
                        }
                }
                if (!matched_this_axis) {
                        return; /* identifier is not legal for this axis */
                }

                size_t axis_start = tokens[index].byte_offset_start;
                size_t axis_end   = tokens[index].byte_offset_end;
                size_t after      = index + 1;

                if (takes_peer_argument) {
                        size_t peer_after;
                        size_t peer_end;
                        if (!span_peer_argument(tokens, token_count, after,
                                                &peer_after, &peer_end)) {
                                return; /* peer token without "(peer)" */
                        }
                        axis_end = peer_end;
                        after    = peer_after;
                }

                match_out->axis_token_start[axis_index] = axis_start;
                match_out->axis_token_end[axis_index]   = axis_end;

                index = next_significant_token(tokens, token_count, after);
        }

        /* every axis matched */
        match_out->matched          = 1;
        match_out->axis_match_count = vocabulary->axis_count;
        match_out->annotation_end   =
                match_out->axis_token_end[vocabulary->axis_count - 1];
}
