/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * parameter_contract_translator.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : parameter_contract_system
 *
 * Purpose       : Implementation of annotation translation. Computes the source
 *                 span to drop and, per build mode, whether the fifth axis is
 *                 kept as instrumentation.
 *
 * Portability   : C99.
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "parameter_contract_translator.h"
#include "parameter_contract_vocabulary.h"

void parameter_contract_translate(const ParameterContractMatch     *match,
                                  ParameterContractBuildMode        build_mode,
                                  ParameterContractTranslationPlan *plan_out)
{
        /* The dropped span runs from the first axis token to the end of the
         * annotation. The first axis token's start is the annotation's start;
         * the recognizer recorded annotation_end as one past the last axis
         * token. The declarator begins at or after annotation_end and is not
         * dropped. */
        plan_out->drop_start = match->axis_token_start[0];
        plan_out->drop_end   = match->annotation_end;

        /* The fifth axis is the last axis. Its span is recorded so the caller
         * can attach diagnostic intent to the parameter. The vocabulary defines
         * how many axes there are; the fifth is at index axis_match_count - 1. */
        size_t last_axis = match->axis_match_count - 1;
        plan_out->layer_two_start = match->axis_token_start[last_axis];
        plan_out->layer_two_end   = match->axis_token_end[last_axis];

        plan_out->emit_layer_two =
                (build_mode == PARAMETER_CONTRACT_BUILD_MODE_DEBUG);
}
