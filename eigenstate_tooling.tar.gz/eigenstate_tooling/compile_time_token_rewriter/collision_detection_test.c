#include "collision_detection.h"
#include "vendor_macro_table.h"
#include "project_identifier_set.h"
#include "project_macro_set.h"
#include "boundary_crossing_enforcement.h"
#include "lexical_scanner.h"
#include <stdio.h>
#include <string.h>
static int fails=0;
static size_t tok(const char*s,LexicalToken*o,size_t m){
    LexicalScannerState st;LexicalToken t;size_t n=0;
    lexical_scanner_initialize(&st,(const unsigned char*)s,strlen(s));
    while(n<m&&lexical_scanner_next_token(&st,&t)){o[n++]=t;}
    return n;
}
static CollisionReportEntry* find(CollisionReport*r,const char*vname,const char*pname){
    for(size_t i=0;i<r->entry_count;i++)
        if(!strcmp(r->entries[i].vendor_macro_name,vname)&&
           !strcmp(r->entries[i].project_name,pname)) return &r->entries[i];
    return NULL;
}
static const char* catname(CollisionCategory c){
    return c==COLLISION_CATEGORY_WHITELISTED?"WHITELISTED":
           c==COLLISION_CATEGORY_IDENTIFIER_CAPTURE?"IDENTIFIER_CAPTURE":"MACRO_SHADOW";
}
int main(void){
    /* vendor header with every collision vector */
    FILE*f=fopen("/tmp/coll_vendor.h","w");
    fputs("#ifndef CV_H\n#define CV_H\n"
          "#define index vendor_internal_index\n"    /* NAME collides w/ project id 'index' */
          "#define TRUE 0\n"                          /* NAME collides w/ project MACRO 'TRUE' */
          "#define fast_path project_helper\n"        /* EXPANSION collides w/ project id */
          "#define SETUP int count\n"                 /* body token 'count' collides w/ project id */
          "#define BLAKE3_OUT_LEN 32\n"               /* whitelisted */
          "#define no_collision xyzzy_nothing\n"      /* collides w/ nothing */
          "#define TRANSFORM(index) ((index))\n"      /* param 'index' must NOT be flagged */
          "#endif\n",f);
    fclose(f);

    /* project source */
    const char*proj=
        "#define TRUE 1\n"
        "static int project_helper(void){return 0;}\n"
        "int lookup(int index){return index;}\n"
        "int count;\n";
    LexicalToken pt[512]; size_t pn=tok(proj,pt,512);
    SymbolSet ids,macros;
    project_identifier_set_collect((const unsigned char*)proj,pt,pn,&ids);
    project_macro_set_collect((const unsigned char*)proj,pt,pn,&macros);

    /* whitelist: BLAKE3_OUT_LEN crosses */
    FILE*w=fopen("/tmp/coll_wl.txt","w");
    fputs("VENDOR_VALUE_SUPERSEDES(BLAKE3_OUT_LEN)\n",w); fclose(w);
    DeclaredCrossingTable wl; size_t bl;
    declared_crossing_table_load("/tmp/coll_wl.txt",&wl,&bl);

    VendorMacroTable vt;
    vendor_macro_table_extract("/tmp/coll_vendor.h","","",&vt);

    CollisionReport rep;
    if(collision_detection_run(&vt,&ids,&macros,&wl,&rep)!=COLLISION_DETECTION_OK){
        printf("detection failed\n");return 1;
    }

    printf("collisions found: %zu\n",rep.entry_count);
    for(size_t i=0;i<rep.entry_count;i++)
        printf("  %s -> %s [%s%s]\n",rep.entries[i].vendor_macro_name,
               rep.entries[i].project_name,catname(rep.entries[i].category),
               rep.entries[i].through_expansion?", via-expansion":"");

    /* assertions */
    CollisionReportEntry*e;
    e=find(&rep,"index","index");
    if(e&&e->category==COLLISION_CATEGORY_IDENTIFIER_CAPTURE&&!e->through_expansion)
        printf("  PASS: index name -> IDENTIFIER_CAPTURE\n");
    else{printf("  FAIL: index capture\n");fails++;}

    e=find(&rep,"TRUE","TRUE");
    if(e&&e->category==COLLISION_CATEGORY_MACRO_SHADOW)
        printf("  PASS: TRUE name -> MACRO_SHADOW\n");
    else{printf("  FAIL: TRUE shadow\n");fails++;}

    e=find(&rep,"fast_path","project_helper");
    if(e&&e->category==COLLISION_CATEGORY_IDENTIFIER_CAPTURE&&e->through_expansion)
        printf("  PASS: fast_path expansion -> project_helper via-expansion\n");
    else{printf("  FAIL: fast_path expansion\n");fails++;}

    e=find(&rep,"SETUP","count");
    if(e&&e->through_expansion)
        printf("  PASS: SETUP body token 'count' caught via-expansion\n");
    else{printf("  FAIL: SETUP body\n");fails++;}

    e=find(&rep,"BLAKE3_OUT_LEN","BLAKE3_OUT_LEN");
    /* only collides if project has BLAKE3_OUT_LEN — it doesn't, so NOT in report.
       instead verify it's absent (no project collision) */
    if(!e) printf("  PASS: BLAKE3_OUT_LEN no project collision (correctly absent)\n");
    else{printf("  note: BLAKE3_OUT_LEN present as %s\n",catname(e->category));}

    /* TRANSFORM's parameter 'index' must NOT be flagged as a body collision */
    e=find(&rep,"TRANSFORM","index");
    if(!e) printf("  PASS: TRANSFORM param 'index' NOT flagged (local to macro)\n");
    else{printf("  FAIL: TRANSFORM param wrongly flagged\n");fails++;}

    collision_report_release(&rep);
    vendor_macro_table_release(&vt);
    declared_crossing_table_release(&wl);
    symbol_set_release(&ids); symbol_set_release(&macros);
    if(fails==0){printf("ALL COLLISION-DETECTION TESTS PASS\n");return 0;}
    printf("%d FAILED\n",fails);return 1;
}
