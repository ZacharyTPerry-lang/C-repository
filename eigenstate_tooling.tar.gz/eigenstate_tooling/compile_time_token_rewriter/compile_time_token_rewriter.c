/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * compile_time_token_rewriter.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter (orchestrator)
 *
 * Purpose       : Implementation of the two-job transformation. Reads project
 *                 source, prefixes project macro references, strips contract
 *                 annotations, and writes translated source; separately
 *                 discovers and enforces reverse dependencies against the
 *                 whitelist.
 *
 * Portability   : C99 plus POSIX (nm, file I/O, directory walk of the vendor
 *                 root for objects).
 *
 * Table of contents:
 *   [1] FILE IO
 *   [2] SOURCE TRANSLATION (macros + annotations)
 *   [3] REVERSE DEPENDENCY ENFORCEMENT
 *   [4] RUN
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200112L
#endif

#include "compile_time_token_rewriter.h"

#include "lexical_scanner.h"
#include "symbol_set_from_object.h"
#include "project_macro_set.h"
#include "project_identifier_set.h"
#include "vendor_macro_table.h"
#include "collision_detection.h"
#include "parameter_contract_recognizer.h"
#include "parameter_contract_translator.h"
#include "boundary_crossing_vocabulary.h"
#include "boundary_crossing_enforcement.h"
#include "boundary_crossing_discovery.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

#define REWRITER_UNIVERSAL_MACRO_PREFIX "COMPILE_TIME_ENFORCEMENT_FRAMEWORK_"

/* ===========================================================================
 * [1] FILE IO
 * ===========================================================================*/

/* Read an entire file into a heap buffer. Returns the buffer (caller frees) and
 * sets *length_out, or NULL on failure. The buffer is NUL-terminated for
 * convenience but the length is authoritative. */
static unsigned char *read_entire_file(const char *path, size_t *length_out)
{
        FILE *file = fopen(path, "rb");
        if (file == NULL) {
                return NULL;
        }
        if (fseek(file, 0, SEEK_END) != 0) {
                fclose(file);
                return NULL;
        }
        long size = ftell(file);
        if (size < 0) {
                fclose(file);
                return NULL;
        }
        rewind(file);

        unsigned char *buffer = malloc((size_t)size + 1);
        if (buffer == NULL) {
                fclose(file);
                return NULL;
        }
        size_t read = fread(buffer, 1, (size_t)size, file);
        fclose(file);
        if (read != (size_t)size) {
                free(buffer);
                return NULL;
        }
        buffer[size] = '\0';
        *length_out = (size_t)size;
        return buffer;
}

/* Join output_directory and the basename of source_path into out_buffer. */
static int build_output_path(const char *output_directory,
                             const char *source_path,
                             char       *out_buffer,
                             size_t      out_buffer_size)
{
        const char *base = strrchr(source_path, '/');
        base = (base != NULL) ? base + 1 : source_path;
        int written = snprintf(out_buffer, out_buffer_size, "%s/%s",
                               output_directory, base);
        return written > 0 && (size_t)written < out_buffer_size;
}

/* ===========================================================================
 * [2] SOURCE TRANSLATION
 * ===========================================================================
 *
 *  Tokenize the source once, collect the project macro set, then walk the
 *  tokens emitting to the output buffer:
 *
 *    - at the start of a parameter annotation, recognize it and skip the
 *      annotation span (contract stripping);
 *    - for an identifier token that names a project macro, emit the prefix then
 *      the identifier (macro prefixing);
 *    - otherwise emit the token's bytes verbatim.
 *
 *  This is the collision-prevention emission. The boundary discipline that
 *  keeps vendor macros out of this translation unit is a build-layer concern
 *  (the source being translated is project source; it reaches vendor constants
 *  through prefixed generated headers, never the vendor header), so the
 *  rewriter's contribution to collision prevention is the prefixing and the
 *  clean, annotation-free output.
 *
 * ===========================================================================*/

/* Emit a byte range of the source to the output file. */
static void emit_range(FILE                *out,
                       const unsigned char *source,
                       size_t               start,
                       size_t               end)
{
        fwrite(source + start, 1, end - start, out);
}

/* Emit a preprocessor directive spanning [start, end). If it is a
 * "#define NAME ..." for a macro in macro_set, emit the prefix immediately
 * before NAME so the definition is renamed to the prefixed form in step with
 * its uses; otherwise emit the directive verbatim. Only the defined NAME (the
 * token immediately after "define") is considered -- a macro body referencing
 * other project macros is handled by the ordinary identifier path when those
 * bodies are used, and the definition line itself must rename only what it
 * defines. */
static void emit_preprocessor_line_prefixing_define(
        FILE                *out,
        const unsigned char *source,
        size_t               start,
        size_t               end,
        const SymbolSet     *macro_set)
{
        size_t cursor = start;
        /* skip leading whitespace */
        while (cursor < end && (source[cursor] == ' '
                            || source[cursor] == '\t')) {
                cursor++;
        }
        /* require '#' */
        if (cursor >= end || source[cursor] != '#') {
                emit_range(out, source, start, end);
                return;
        }
        cursor++;
        while (cursor < end && (source[cursor] == ' '
                            || source[cursor] == '\t')) {
                cursor++;
        }
        /* require "define" */
        static const char define_keyword[] = "define";
        size_t keyword_length = sizeof(define_keyword) - 1;
        if (cursor + keyword_length > end
            || memcmp(source + cursor, define_keyword, keyword_length) != 0) {
                emit_range(out, source, start, end);
                return;
        }
        size_t after_keyword = cursor + keyword_length;
        /* the character after "define" must be whitespace (else it is a longer
         * word like "defined") */
        if (after_keyword >= end
            || !(source[after_keyword] == ' '
                 || source[after_keyword] == '\t')) {
                emit_range(out, source, start, end);
                return;
        }
        cursor = after_keyword;
        while (cursor < end && (source[cursor] == ' '
                            || source[cursor] == '\t')) {
                cursor++;
        }
        /* the defined name begins here; find its extent */
        size_t name_start = cursor;
        while (cursor < end) {
                unsigned char c = source[cursor];
                int is_identifier_char = (c >= 'A' && c <= 'Z')
                                      || (c >= 'a' && c <= 'z')
                                      || (c >= '0' && c <= '9')
                                      ||  c == '_';
                if (!is_identifier_char) {
                        break;
                }
                cursor++;
        }
        size_t name_end = cursor;
        size_t name_length = name_end - name_start;

        /* decide whether the defined name is a project macro */
        int is_project_macro = 0;
        char name_buffer[512];
        if (name_length > 0 && name_length < sizeof(name_buffer)) {
                memcpy(name_buffer, source + name_start, name_length);
                name_buffer[name_length] = '\0';
                is_project_macro = symbol_set_contains(macro_set, name_buffer);
        }

        /* emit: everything up to the name, then (prefix if project macro), then
         * the name, then the remainder of the directive verbatim */
        emit_range(out, source, start, name_start);
        if (is_project_macro) {
                fputs(REWRITER_UNIVERSAL_MACRO_PREFIX, out);
        }
        emit_range(out, source, name_start, end);
}

/* Returns 0 on success, nonzero on failure. */
static int translate_source_file(const char *source_path,
                                 const char *output_directory)
{
        size_t         source_length;
        unsigned char *source = read_entire_file(source_path, &source_length);
        if (source == NULL) {
                fprintf(stderr,
                        "compile time token rewriter: cannot read %s\n",
                        source_path);
                return 1;
        }

        /* tokenize */
        size_t        token_capacity = source_length + 16;
        LexicalToken *tokens = malloc(token_capacity * sizeof(LexicalToken));
        if (tokens == NULL) {
                free(source);
                return 1;
        }
        LexicalScannerState scanner;
        LexicalToken        token;
        size_t              token_count = 0;
        lexical_scanner_initialize(&scanner, source, source_length);
        while (token_count < token_capacity
               && lexical_scanner_next_token(&scanner, &token)) {
                tokens[token_count++] = token;
        }

        /* project macro set */
        SymbolSet macro_set;
        if (project_macro_set_collect(source, tokens, token_count, &macro_set)
            != PROJECT_MACRO_SET_OK) {
                free(tokens);
                free(source);
                return 1;
        }

        /* open output */
        char output_path[4096];
        if (!build_output_path(output_directory, source_path,
                               output_path, sizeof(output_path))) {
                symbol_set_release(&macro_set);
                free(tokens);
                free(source);
                return 1;
        }
        FILE *out = fopen(output_path, "wb");
        if (out == NULL) {
                fprintf(stderr,
                        "compile time token rewriter: cannot write %s\n",
                        output_path);
                symbol_set_release(&macro_set);
                free(tokens);
                free(source);
                return 1;
        }

        /* emit */
        size_t index = 0;
        while (index < token_count) {
                /* try to recognize a contract annotation starting here */
                ParameterContractMatch match;
                parameter_contract_recognize(source, tokens, token_count,
                                             index, &match);
                if (match.matched) {
                        ParameterContractTranslationPlan plan;
                        parameter_contract_translate(
                                &match,
                                PARAMETER_CONTRACT_BUILD_MODE_RELEASE,
                                &plan);
                        /* skip tokens until we pass the dropped span */
                        while (index < token_count
                               && tokens[index].byte_offset_start
                                          < plan.drop_end) {
                                index++;
                        }
                        continue;
                }

                const LexicalToken *current = &tokens[index];
                if (current->category == LEXICAL_TOKEN_CATEGORY_IDENTIFIER) {
                        size_t length = current->byte_offset_end
                                      - current->byte_offset_start;
                        /* NUL-terminate for the set query */
                        char name_buffer[512];
                        if (length < sizeof(name_buffer)) {
                                memcpy(name_buffer,
                                       source + current->byte_offset_start,
                                       length);
                                name_buffer[length] = '\0';
                                if (symbol_set_contains(&macro_set,
                                                        name_buffer)) {
                                        fputs(REWRITER_UNIVERSAL_MACRO_PREFIX,
                                              out);
                                }
                        }
                        emit_range(out, source, current->byte_offset_start,
                                   current->byte_offset_end);
                        index++;
                        continue;
                }
                if (current->category
                    == LEXICAL_TOKEN_CATEGORY_PREPROCESSOR_LINE) {
                        /* A "#define NAME ..." directive is emitted as one
                         * opaque token by the lexer (directives are not C
                         * grammar). If it defines a project macro, the name must
                         * be prefixed here too, so the definition moves to the
                         * prefixed name in step with its uses. Otherwise the
                         * prefixed uses would reference an undeclared name. */
                        emit_preprocessor_line_prefixing_define(
                                out, source,
                                current->byte_offset_start,
                                current->byte_offset_end,
                                &macro_set);
                        index++;
                        continue;
                }
                emit_range(out, source, current->byte_offset_start,
                           current->byte_offset_end);
                index++;
        }

        fclose(out);
        symbol_set_release(&macro_set);
        free(tokens);
        free(source);
        return 0;
}

/* ===========================================================================
 * [3] REVERSE DEPENDENCY ENFORCEMENT
 * ===========================================================================
 *
 *  Compile the project source to a temporary object to obtain P, walk the
 *  vendor root for vendor objects (both prebuilt .o files and .c files compiled
 *  on demand), discover reverse dependencies against P, and enforce each
 *  against the whitelist. An undeclared compelled crossing fails the run.
 *
 *  P is obtained by compiling the project sources being processed. For the
 *  enforcement test the project provides the symbol the vendor demands, so
 *  compiling it yields a P that contains the crossing symbol.
 *
 * ===========================================================================*/

/* Compile one project source to a temp object and extract P into p_out.
 * Returns 0 on success. */
static int extract_project_symbols(const char *source_path, SymbolSet *p_out)
{
        char command[8192];
        int written = snprintf(command, sizeof(command),
                "gcc -c '%s' -o /tmp/ctr_project_probe.o 2>/dev/null",
                source_path);
        if (written <= 0 || (size_t)written >= sizeof(command)) {
                return 1;
        }
        if (system(command) != 0) {
                return 1;
        }
        SymbolSetResult r = symbol_set_extract_from_object(
                "/tmp/ctr_project_probe.o",
                SYMBOL_SET_SELECTOR_DEFINED_EXTERNAL, p_out);
        return (r == SYMBOL_SET_RESULT_OK) ? 0 : 1;
}

/* Compile a vendor .c to a temp object; return the object path in obj_out or
 * NULL on failure. For an existing .o, returns the path unchanged. */
static int ensure_vendor_object(const char *vendor_path,
                                char       *obj_out,
                                size_t      obj_out_size)
{
        size_t len = strlen(vendor_path);
        if (len >= 2 && strcmp(vendor_path + len - 2, ".o") == 0) {
                if (len >= obj_out_size) {
                        return 1;
                }
                strcpy(obj_out, vendor_path);
                return 0;
        }
        if (len >= 2 && strcmp(vendor_path + len - 2, ".c") == 0) {
                int w = snprintf(obj_out, obj_out_size,
                                 "/tmp/ctr_vendor_probe.o");
                if (w <= 0 || (size_t)w >= obj_out_size) {
                        return 1;
                }
                char command[8192];
                int cw = snprintf(command, sizeof(command),
                        "gcc -c '%s' -o '%s' 2>/dev/null",
                        vendor_path, obj_out);
                if (cw <= 0 || (size_t)cw >= sizeof(command)) {
                        return 1;
                }
                if (system(command) != 0) {
                        return 1;
                }
                return 0;
        }
        return 1; /* not an object or C source */
}

/* Enforce reverse dependencies for one vendor object against P and the
 * whitelist. Returns 0 if all crossings are permitted, nonzero if any
 * undeclared compelled crossing is found (message emitted). */
static int enforce_vendor_object(const char                  *vendor_object_path,
                                 const SymbolSet             *project_p,
                                 const DeclaredCrossingTable *whitelist)
{
        DiscoveredCrossings discovered;
        CrossingDiscoveryResult dr =
                boundary_crossing_discover_reverse_dependencies(
                        vendor_object_path, project_p, &discovered);
        if (dr != CROSSING_DISCOVERY_OK) {
                fprintf(stderr,
                        "compile time token rewriter: discovery failed on %s\n",
                        vendor_object_path);
                return 1;
        }

        int failure = 0;
        size_t index;
        for (index = 0; index < discovered.crossing_symbols.name_count;
             index++) {
                const char *symbol =
                        symbol_set_name_at(&discovered.crossing_symbols, index);
                CrossingVerdict verdict = boundary_crossing_enforce(
                        whitelist, discovered.kind, symbol);
                if (verdict == CROSSING_VERDICT_UNDECLARED_COMPELLED) {
                        fprintf(stderr,
                                "compile time token rewriter: vendor demands "
                                "project symbol '%s' but it is not declared "
                                "as a crossing (add %s(%s) to the whitelist)\n",
                                symbol, discovered.kind->keyword, symbol);
                        failure = 1;
                }
        }

        discovered_crossings_release(&discovered);
        return failure;
}

/* Walk the vendor root, enforcing every vendor object/source found. */
static int enforce_vendor_root(const char                  *vendor_root,
                               const SymbolSet             *project_p,
                               const DeclaredCrossingTable *whitelist)
{
        DIR *dir = opendir(vendor_root);
        if (dir == NULL) {
                /* no vendor root is not an error: nothing to enforce */
                return 0;
        }
        int failure = 0;
        struct dirent *entry;
        while ((entry = readdir(dir)) != NULL) {
                if (entry->d_name[0] == '.') {
                        continue;
                }
                char child[4096];
                int w = snprintf(child, sizeof(child), "%s/%s",
                                 vendor_root, entry->d_name);
                if (w <= 0 || (size_t)w >= sizeof(child)) {
                        continue;
                }

                /* recurse into subdirectories */
                DIR *sub = opendir(child);
                if (sub != NULL) {
                        closedir(sub);
                        if (enforce_vendor_root(child, project_p, whitelist)
                            != 0) {
                                failure = 1;
                        }
                        continue;
                }

                size_t nlen = strlen(entry->d_name);
                int is_c  = (nlen >= 2
                             && strcmp(entry->d_name + nlen - 2, ".c") == 0);
                int is_o  = (nlen >= 2
                             && strcmp(entry->d_name + nlen - 2, ".o") == 0);
                if (!is_c && !is_o) {
                        continue;
                }

                char object_path[4096];
                if (ensure_vendor_object(child, object_path,
                                         sizeof(object_path)) != 0) {
                        continue;
                }
                if (enforce_vendor_object(object_path, project_p, whitelist)
                    != 0) {
                        failure = 1;
                }
        }
        closedir(dir);
        return failure;
}

/* ===========================================================================
 * [3b] COLLISION GUARD
 * ===========================================================================
 *
 *  Before translating, check the project source against every vendor header's
 *  macros. A vendor macro whose name or expansion collides with a project
 *  identifier, and is not whitelisted, is an unguarded capture: prefixing
 *  cannot fix it, so the build must stop with the collision named. A collision
 *  with a project macro is resolved by the prefix system and is reported only
 *  as information, not a failure.
 *
 *  This is the static collision layer. Under the boundary discipline the
 *  vendor header still enters project code -- using a library is not a
 *  violation -- but an UNGUARDED collision within it is.
 *
 * ===========================================================================*/

/* Collect a vendor header's macro table for one header path. */
static int collision_guard_check_header(const char                  *vendor_header_path,
                                        const SymbolSet             *project_identifiers,
                                        const SymbolSet             *project_macros,
                                        const DeclaredCrossingTable *whitelist,
                                        int                         *any_capture)
{
        VendorMacroTable vendor_table;
        if (vendor_macro_table_extract(vendor_header_path, "", "",
                                       &vendor_table)
            != VENDOR_MACRO_TABLE_OK) {
                /* a header we cannot dump is not silently skipped */
                fprintf(stderr,
                        "compile time token rewriter: cannot read vendor "
                        "macros from %s\n", vendor_header_path);
                return 1;
        }

        CollisionReport report;
        if (collision_detection_run(&vendor_table, project_identifiers,
                                    project_macros, whitelist, &report)
            != COLLISION_DETECTION_OK) {
                vendor_macro_table_release(&vendor_table);
                return 1;
        }

        size_t index;
        for (index = 0; index < report.entry_count; index++) {
                const CollisionReportEntry *entry = &report.entries[index];
                if (entry->category == COLLISION_CATEGORY_IDENTIFIER_CAPTURE) {
                        fprintf(stderr,
                                "compile time token rewriter: vendor macro "
                                "'%s' collides with project identifier '%s'%s "
                                "-- unguarded capture (whitelist it to cross, "
                                "or rename)\n",
                                entry->vendor_macro_name, entry->project_name,
                                entry->through_expansion
                                        ? " through its expansion" : "");
                        *any_capture = 1;
                } else if (entry->category
                           == COLLISION_CATEGORY_CONSTRUCTED_CAPTURE) {
                        fprintf(stderr,
                                "compile time token rewriter: vendor macro "
                                "'%s' uses token paste with fixed affix '%s' "
                                "that could construct a project identifier "
                                "-- potential unguarded capture (whitelist the "
                                "affix, or rename)\n",
                                entry->vendor_macro_name, entry->project_name);
                        *any_capture = 1;
                }
        }

        collision_report_release(&report);
        vendor_macro_table_release(&vendor_table);
        return 0;
}

/* Walk the vendor root, checking every vendor header against project space. */
static int collision_guard_walk(const char                  *vendor_root,
                                const SymbolSet             *project_identifiers,
                                const SymbolSet             *project_macros,
                                const DeclaredCrossingTable *whitelist,
                                int                         *any_capture)
{
        DIR *dir = opendir(vendor_root);
        if (dir == NULL) {
                return 0; /* no vendor headers to check */
        }
        int error = 0;
        struct dirent *entry;
        while ((entry = readdir(dir)) != NULL) {
                if (entry->d_name[0] == '.') {
                        continue;
                }
                char child[4096];
                int w = snprintf(child, sizeof(child), "%s/%s",
                                 vendor_root, entry->d_name);
                if (w <= 0 || (size_t)w >= sizeof(child)) {
                        continue;
                }
                DIR *sub = opendir(child);
                if (sub != NULL) {
                        closedir(sub);
                        if (collision_guard_walk(child, project_identifiers,
                                                 project_macros, whitelist,
                                                 any_capture) != 0) {
                                error = 1;
                        }
                        continue;
                }
                size_t nlen = strlen(entry->d_name);
                if (nlen >= 2
                    && strcmp(entry->d_name + nlen - 2, ".h") == 0) {
                        if (collision_guard_check_header(
                                    child, project_identifiers,
                                    project_macros, whitelist,
                                    any_capture) != 0) {
                                error = 1;
                        }
                }
        }
        closedir(dir);
        return error;
}

/* Run the collision guard for one project source file. Returns 0 if no
 * unguarded capture, nonzero on capture or error. */
static int collision_guard_for_source(const char                  *source_path,
                                      const char                  *vendor_root,
                                      const DeclaredCrossingTable *whitelist)
{
        size_t         source_length;
        unsigned char *source = read_entire_file(source_path, &source_length);
        if (source == NULL) {
                return 1;
        }

        size_t        token_capacity = source_length + 16;
        LexicalToken *tokens = malloc(token_capacity * sizeof(LexicalToken));
        if (tokens == NULL) {
                free(source);
                return 1;
        }
        LexicalScannerState scanner;
        LexicalToken        token;
        size_t              token_count = 0;
        lexical_scanner_initialize(&scanner, source, source_length);
        while (token_count < token_capacity
               && lexical_scanner_next_token(&scanner, &token)) {
                tokens[token_count++] = token;
        }

        SymbolSet identifiers;
        SymbolSet macros;
        if (project_identifier_set_collect(source, tokens, token_count,
                                           &identifiers)
            != PROJECT_IDENTIFIER_SET_OK) {
                free(tokens); free(source); return 1;
        }
        if (project_macro_set_collect(source, tokens, token_count, &macros)
            != PROJECT_MACRO_SET_OK) {
                symbol_set_release(&identifiers);
                free(tokens); free(source); return 1;
        }

        int any_capture = 0;
        int error = collision_guard_walk(vendor_root, &identifiers, &macros,
                                         whitelist, &any_capture);

        symbol_set_release(&identifiers);
        symbol_set_release(&macros);
        free(tokens);
        free(source);
        return (error || any_capture) ? 1 : 0;
}

/* ===========================================================================
 * [4] RUN
 * ===========================================================================*/

int compile_time_token_rewriter_run(const RewriterInvocation *invocation)
{
        /* load whitelist (empty table if none supplied) */
        DeclaredCrossingTable whitelist;
        if (invocation->whitelist_path != NULL) {
                size_t bad_line = 0;
                WhitelistLoadResult wl = declared_crossing_table_load(
                        invocation->whitelist_path, &whitelist, &bad_line);
                if (wl == WHITELIST_LOAD_MALFORMED_LINE) {
                        fprintf(stderr,
                                "compile time token rewriter: malformed "
                                "whitelist at line %zu\n", bad_line);
                        return 1;
                }
                if (wl == WHITELIST_LOAD_FILE_NOT_FOUND) {
                        fprintf(stderr,
                                "compile time token rewriter: whitelist not "
                                "found: %s\n", invocation->whitelist_path);
                        return 1;
                }
                if (wl != WHITELIST_LOAD_OK) {
                        return 1;
                }
        } else {
                /* no whitelist supplied: start from a properly empty table.
                 * release() frees pointers and must not be called on
                 * uninitialized memory, so zero the fields directly. */
                whitelist.name_storage        = NULL;
                whitelist.name_storage_length = 0;
                whitelist.storage_capacity    = 0;
                whitelist.entry_kinds         = NULL;
                whitelist.entry_name_offsets  = NULL;
                whitelist.entry_count         = 0;
                whitelist.entry_capacity      = 0;
        }

        /* JOB 2: reverse-dependency enforcement.
         * Build P from the project sources, then enforce the vendor root. */
        int    enforcement_failure = 0;
        size_t index;
        if (invocation->input_source_count > 0) {
                SymbolSet project_p;
                if (extract_project_symbols(invocation->input_source_paths[0],
                                            &project_p) == 0) {
                        if (enforce_vendor_root(invocation->vendor_root,
                                                &project_p, &whitelist) != 0) {
                                enforcement_failure = 1;
                        }
                        symbol_set_release(&project_p);
                }
        }

        if (enforcement_failure) {
                declared_crossing_table_release(&whitelist);
                return 1;
        }

        /* JOB 1a: collision guard. Check each project source against every
         * vendor header's macros; an unguarded identifier capture fails. */
        for (index = 0; index < invocation->input_source_count; index++) {
                if (collision_guard_for_source(
                            invocation->input_source_paths[index],
                            invocation->vendor_root,
                            &whitelist) != 0) {
                        declared_crossing_table_release(&whitelist);
                        return 1;
                }
        }

        declared_crossing_table_release(&whitelist);

        /* Ensure the output directory exists before writing translated files.
         * The tool creates it rather than requiring the caller to, so a missing
         * output directory is not a failure. mkdir returning EEXIST is fine. */
        if (mkdir(invocation->output_directory, 0777) != 0) {
                /* tolerate "already exists"; other errors surface at write */
        }

        /* JOB 1b: translate each source file (macro prefixing + annotation
         * stripping). */
        for (index = 0; index < invocation->input_source_count; index++) {
                if (translate_source_file(
                            invocation->input_source_paths[index],
                            invocation->output_directory) != 0) {
                        return 1;
                }
        }

        return 0;
}
