#include "collision_detection.h"
#include "vendor_macro_table.h"
#include "project_identifier_set.h"
#include "project_macro_set.h"
#include "boundary_crossing_enforcement.h"
#include "lexical_scanner.h"
#include <stdio.h>
#include <string.h>
static int fails=0;
static size_t tok(const char*s,LexicalToken*o,size_t m){
    LexicalScannerState st;LexicalToken t;size_t n=0;
    lexical_scanner_initialize(&st,(const unsigned char*)s,strlen(s));
    while(n<m&&lexical_scanner_next_token(&st,&t)){o[n++]=t;}
    return n;
}
static const char* cat(CollisionCategory c){
    switch(c){case COLLISION_CATEGORY_WHITELISTED:return "WHITELISTED";
    case COLLISION_CATEGORY_IDENTIFIER_CAPTURE:return "IDENTIFIER_CAPTURE";
    case COLLISION_CATEGORY_MACRO_SHADOW:return "MACRO_SHADOW";
    case COLLISION_CATEGORY_CONSTRUCTED_CAPTURE:return "CONSTRUCTED_CAPTURE";}
    return "?";
}
int main(void){
    FILE*f=fopen("/tmp/paste_vendor.h","w");
    fputs("#ifndef PV_H\n#define PV_H\n"
          "#define MAKE(x) project_ ## x\n"      /* prefix paste -> project_* */
          "#define WRAP(y) y ## _handler\n"      /* suffix paste -> *_handler */
          "#define SAFE(z) other_ ## z\n"        /* prefix 'other_' -> no project match */
          "#endif\n",f);
    fclose(f);
    /* project has project_helper (starts with project_) and cleanup_handler (ends _handler) */
    const char*proj=
        "int project_helper(void){return 0;}\n"
        "int cleanup_handler(void){return 0;}\n";
    LexicalToken pt[512];size_t pn=tok(proj,pt,512);
    SymbolSet ids,macros; DeclaredCrossingTable wl;
    project_identifier_set_collect((const unsigned char*)proj,pt,pn,&ids);
    project_macro_set_collect((const unsigned char*)proj,pt,pn,&macros);
    memset(&wl,0,sizeof(wl)); /* empty whitelist */
    VendorMacroTable vt;
    vendor_macro_table_extract("/tmp/paste_vendor.h","","",&vt);
    CollisionReport rep;
    collision_detection_run(&vt,&ids,&macros,&wl,&rep);

    int found_prefix=0, found_suffix=0, found_safe=0;
    printf("constructed-capture collisions:\n");
    for(size_t i=0;i<rep.entry_count;i++){
        if(rep.entries[i].category==COLLISION_CATEGORY_CONSTRUCTED_CAPTURE){
            printf("  %s ## affix '%s' -> [%s]\n",rep.entries[i].vendor_macro_name,
                   rep.entries[i].project_name,cat(rep.entries[i].category));
            if(!strcmp(rep.entries[i].vendor_macro_name,"MAKE"))found_prefix=1;
            if(!strcmp(rep.entries[i].vendor_macro_name,"WRAP"))found_suffix=1;
            if(!strcmp(rep.entries[i].vendor_macro_name,"SAFE"))found_safe=1;
        }
    }
    if(found_prefix)printf("  PASS: MAKE (project_ ## x) flagged -- could build project_helper\n");
    else{printf("  FAIL: MAKE prefix paste missed\n");fails++;}
    if(found_suffix)printf("  PASS: WRAP (y ## _handler) flagged -- could build cleanup_handler\n");
    else{printf("  FAIL: WRAP suffix paste missed\n");fails++;}
    if(!found_safe)printf("  PASS: SAFE (other_ ## z) NOT flagged -- no project name starts with other_\n");
    else{printf("  FAIL: SAFE wrongly flagged\n");fails++;}

    collision_report_release(&rep);vendor_macro_table_release(&vt);
    symbol_set_release(&ids);symbol_set_release(&macros);
    if(fails==0){printf("ALL PASTE-DETECTION TESTS PASS\n");return 0;}
    printf("%d FAILED\n",fails);return 1;
}
