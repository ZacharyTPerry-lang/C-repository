/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * project_macro_set.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter
 *
 * Purpose       : Implementation of project macro name collection. Reads
 *                 PREPROCESSOR_LINE tokens, keeps the #define ones, and records
 *                 the defined name.
 *
 * Portability   : C99.
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "project_macro_set.h"

#include <string.h>

/* ===========================================================================
 * DIRECTIVE PARSING
 * ===========================================================================
 *
 *  A PREPROCESSOR_LINE token spans a whole directive line, "# ... \n" possibly
 *  with continuations. To extract a defined name we scan within the token's
 *  byte range: skip the '#', skip space, require the word "define", skip space,
 *  and take the following identifier as the name. Anything that is not a
 *  #define line contributes no name.
 *
 * ===========================================================================*/

static int gate_is_space(unsigned char byte_value)
{
        return byte_value == ' ' || byte_value == '\t';
}

static int gate_is_identifier_start(unsigned char byte_value)
{
        return (byte_value >= 'A' && byte_value <= 'Z')
            || (byte_value >= 'a' && byte_value <= 'z')
            ||  byte_value == '_';
}

static int gate_is_identifier_continue(unsigned char byte_value)
{
        return gate_is_identifier_start(byte_value)
            || (byte_value >= '0' && byte_value <= '9');
}

/* If the byte range [start, end) is a "#define NAME ..." line, set
 * *name_start and *name_end to the NAME's byte range and return nonzero.
 * Otherwise return zero. */
static int extract_defined_name(const unsigned char *source_buffer,
                                size_t               start,
                                size_t               end,
                                size_t              *name_start,
                                size_t              *name_end)
{
        size_t cursor = start;

        /* '#' */
        while (cursor < end && gate_is_space(source_buffer[cursor])) {
                cursor++;
        }
        if (cursor >= end || source_buffer[cursor] != '#') {
                return 0;
        }
        cursor++;

        /* optional space between '#' and directive keyword */
        while (cursor < end && gate_is_space(source_buffer[cursor])) {
                cursor++;
        }

        /* the word "define" */
        static const char define_keyword[] = "define";
        size_t keyword_length = sizeof(define_keyword) - 1;
        if (cursor + keyword_length > end) {
                return 0;
        }
        if (memcmp(source_buffer + cursor, define_keyword, keyword_length)
            != 0) {
                return 0;
        }
        /* the keyword must be followed by space (not part of a longer word) */
        size_t after_keyword = cursor + keyword_length;
        if (after_keyword >= end
            || !gate_is_space(source_buffer[after_keyword])) {
                return 0;
        }
        cursor = after_keyword;

        while (cursor < end && gate_is_space(source_buffer[cursor])) {
                cursor++;
        }

        /* the defined name */
        if (cursor >= end || !gate_is_identifier_start(source_buffer[cursor])) {
                return 0;
        }
        *name_start = cursor;
        cursor++;
        while (cursor < end && gate_is_identifier_continue(source_buffer[cursor])) {
                cursor++;
        }
        *name_end = cursor;
        return 1;
}

/* ===========================================================================
 * COLLECTION
 * ===========================================================================*/

ProjectMacroSetResult project_macro_set_collect(const unsigned char *source_buffer,
                                                const LexicalToken  *tokens,
                                                size_t               token_count,
                                                SymbolSet           *macro_name_set_out)
{
        symbol_set_begin(macro_name_set_out);

        size_t index;
        for (index = 0; index < token_count; index++) {
                if (tokens[index].category
                    != LEXICAL_TOKEN_CATEGORY_PREPROCESSOR_LINE) {
                        continue;
                }
                size_t name_start;
                size_t name_end;
                if (extract_defined_name(source_buffer,
                                         tokens[index].byte_offset_start,
                                         tokens[index].byte_offset_end,
                                         &name_start, &name_end)) {
                        if (!symbol_set_add_name(
                                    macro_name_set_out,
                                    (const char *)(source_buffer + name_start),
                                    name_end - name_start)) {
                                symbol_set_release(macro_name_set_out);
                                return PROJECT_MACRO_SET_OUT_OF_MEMORY;
                        }
                }
        }

        symbol_set_finalize(macro_name_set_out);
        return PROJECT_MACRO_SET_OK;
}
