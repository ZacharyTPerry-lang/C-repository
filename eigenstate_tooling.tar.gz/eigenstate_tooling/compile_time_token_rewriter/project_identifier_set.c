/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * project_identifier_set.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter
 *
 * Purpose       : Implementation of project identifier collection. Every
 *                 identifier token becomes a member of the set.
 *
 * Portability   : C99.
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "project_identifier_set.h"

ProjectIdentifierSetResult project_identifier_set_collect(
        const unsigned char *source_buffer,
        const LexicalToken  *tokens,
        size_t               token_count,
        SymbolSet           *identifier_set_out)
{
        symbol_set_begin(identifier_set_out);

        size_t index;
        for (index = 0; index < token_count; index++) {
                if (tokens[index].category
                    != LEXICAL_TOKEN_CATEGORY_IDENTIFIER) {
                        continue;
                }
                size_t start  = tokens[index].byte_offset_start;
                size_t length = tokens[index].byte_offset_end - start;
                if (!symbol_set_add_name(identifier_set_out,
                                         (const char *)(source_buffer + start),
                                         length)) {
                        symbol_set_release(identifier_set_out);
                        return PROJECT_IDENTIFIER_SET_OUT_OF_MEMORY;
                }
        }

        symbol_set_finalize(identifier_set_out);
        return PROJECT_IDENTIFIER_SET_OK;
}
