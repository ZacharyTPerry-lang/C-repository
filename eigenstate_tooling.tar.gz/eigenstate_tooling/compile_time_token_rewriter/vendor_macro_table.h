/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * vendor_macro_table.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter
 *
 * Purpose       : Capture the macros a vendor header defines, as name plus
 *                 expansion, so collision detection can check BOTH sides of
 *                 every definition. A vendor macro can collide with project
 *                 space through its name (a vendor "index" capturing a project
 *                 identifier) or through its expansion (a vendor macro that
 *                 expands to a project symbol). Both are found only if both are
 *                 recorded.
 *
 * Source of data: gcc -dM -E on the vendor header, under the build's
 *                 configuration. That dump is the compiler's own statement of
 *                 which macros are defined and what each expands to -- a stage
 *                 output, not an internal, and complete by inheritance because
 *                 the vendor's own includes are resolved (Move 1). This module
 *                 runs that dump and parses its "#define NAME BODY" lines.
 *
 * What it does   : records the NAME and the raw BODY text of each macro. It does
 * NOT do          not tokenize the body here; tokenizing is the lexical
 *                 scanner's job, and collision detection tokenizes each body
 *                 when it needs the individual identifiers inside it. Keeping
 *                 the body as text keeps this module a thin capture of the
 *                 dump. Function-like macros keep their parameter list as part
 *                 of the recorded form; collision detection excludes the
 *                 parameters when scanning the body.
 *
 * Portability   : C99 plus POSIX (popen for the gcc dump), matching
 *                 symbol_set_from_object.
 *
 * Table of contents:
 *   [1] MACRO ENTRY AND TABLE
 *   [2] EXTRACTION
 *   [3] ACCESS
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef VENDOR_MACRO_TABLE_H
#define VENDOR_MACRO_TABLE_H

#include <stddef.h>

/* ===========================================================================
 * [1] MACRO ENTRY AND TABLE
 * ===========================================================================
 *
 *  One macro: its name and its body, both as offsets into a shared text block.
 *  A function-like macro's name is just the identifier before '('; the
 *  parameter list is part of the body span and is skipped by the consumer.
 *
 * ---------------------------------------------------------------------------
 *  name_offset          offset of the macro name in the table's text block
 *  name_length          length of the name
 *  body_offset          offset of the body text (everything after the name and
 *                       one separating space) in the text block
 *  body_length          length of the body; zero for a macro defined with no
 *                       replacement list
 *  is_function_like     nonzero if a '(' immediately followed the name with no
 *                       space, i.e. the macro takes parameters
 * ---------------------------------------------------------------------------*/

typedef struct VendorMacroEntry {
        size_t name_offset;
        size_t name_length;
        size_t body_offset;
        size_t body_length;
        int    is_function_like;
} VendorMacroEntry;

/* ---------------------------------------------------------------------------
 *  The table: a text block holding all names and bodies, and an array of
 *  entries indexing into it.
 *
 *  text                 contiguous block of macro name and body text
 *  text_length          bytes used in text
 *  text_capacity        bytes allocated
 *  entries              one VendorMacroEntry per macro
 *  entry_count          number of macros
 *  entry_capacity       allocated entries
 * ---------------------------------------------------------------------------*/

typedef struct VendorMacroTable {
        char             *text;
        size_t            text_length;
        size_t            text_capacity;
        VendorMacroEntry *entries;
        size_t            entry_count;
        size_t            entry_capacity;
} VendorMacroTable;

/* ===========================================================================
 * [2] EXTRACTION
 * ===========================================================================*/

typedef enum VendorMacroTableResult {
        VENDOR_MACRO_TABLE_OK,
        VENDOR_MACRO_TABLE_TOOL_FAILED,
        VENDOR_MACRO_TABLE_OUT_OF_MEMORY
} VendorMacroTableResult;

/* ---------------------------------------------------------------------------
 *  Operation : vendor_macro_table_extract
 *
 *  Run gcc -dM -E on the vendor header and record every macro it defines into a
 *  freshly initialized table. The include_flags string is passed to gcc so a
 *  vendor header that reaches its own siblings resolves them (its includes are
 *  part of what defines its macros). The config_defines string carries the
 *  build's -D flags so the dump reflects the configuration the real compile
 *  uses (Move 3); pass an empty string for none.
 *
 *  Built-in compiler macros appear in the dump too. They are recorded like any
 *  other; collision detection distinguishes them by the fact that they do not
 *  collide with project space, so no special filtering is needed here.
 *
 *  On success the caller owns the table and releases it with
 *  vendor_macro_table_release. On failure the table is left empty and released
 *  internally.
 *
 *  IN   vendor_header_path  VALID    CONSUME   ALWAYS      KEEP  NONE  .h path
 *  IN   include_flags       VALID    CONSUME   ALWAYS      KEEP  NONE  -I flags
 *                                                                      or ""
 *  IN   config_defines      VALID    CONSUME   ALWAYS      KEEP  NONE  -D flags
 *                                                                      or ""
 *  OUT  table_out           GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE  the table
 * ---------------------------------------------------------------------------*/
VendorMacroTableResult vendor_macro_table_extract(const char       *vendor_header_path,
                                                  const char       *include_flags,
                                                  const char       *config_defines,
                                                  VendorMacroTable *table_out);

/* ---------------------------------------------------------------------------
 *  Operation : vendor_macro_table_release
 *
 *  Free a table and reset it to empty. Safe on an empty table.
 *
 *  IN  table  VALID  MUTATE  ALWAYS  GIVE  NONE  table to release
 * ---------------------------------------------------------------------------*/
void vendor_macro_table_release(VendorMacroTable *table);

/* ===========================================================================
 * [3] ACCESS
 * ===========================================================================*/

/* Return a pointer to the name text of entry index (not NUL-terminated; use
 * with the entry's name_length), or NULL if index is out of range. */
const char *vendor_macro_table_name(const VendorMacroTable *table, size_t index);

/* Return a pointer to the body text of entry index (not NUL-terminated; use
 * with the entry's body_length), or NULL if index is out of range or the body
 * is empty. */
const char *vendor_macro_table_body(const VendorMacroTable *table, size_t index);

#endif /* VENDOR_MACRO_TABLE_H */
