#include "vendor_macro_table.h"
#include <stdio.h>
#include <string.h>
static int fails=0;
static int find_macro(const VendorMacroTable*t,const char*name,size_t*idx){
    for(size_t i=0;i<t->entry_count;i++){
        const char*n=vendor_macro_table_name(t,i);
        if(strlen(name)==t->entries[i].name_length &&
           memcmp(n,name,t->entries[i].name_length)==0){*idx=i;return 1;}
    }
    return 0;
}
static void chk_body(const VendorMacroTable*t,const char*name,const char*want_body){
    size_t i;
    if(!find_macro(t,name,&i)){printf("  FAIL: macro '%s' not found\n",name);fails++;return;}
    const char*b=vendor_macro_table_body(t,i);
    size_t bl=t->entries[i].body_length;
    char buf[256]; if(bl<256){memcpy(buf,b?b:"",bl);buf[bl]='\0';}else buf[0]='\0';
    if(strcmp(buf,want_body)==0)
        printf("  pass: %s -> body '%s' fnlike=%d\n",name,buf,t->entries[i].is_function_like);
    else{printf("  FAIL: %s body '%s' want '%s'\n",name,buf,want_body);fails++;}
}
int main(void){
    /* write a vendor header with the edge cases */
    FILE*f=fopen("/tmp/vmt_vendor.h","w");
    fputs("#ifndef V_H\n#define V_H\n"
          "#define index vendor_internal_index\n"      /* name+expansion */
          "#define SETUP int index; int count\n"        /* multi-token body */
          "#define TRANSFORM(x) ((x)*2)\n"              /* function-like */
          "#define FLAG\n"                              /* no body */
          "#endif\n",f);
    fclose(f);
    VendorMacroTable t;
    VendorMacroTableResult r=vendor_macro_table_extract("/tmp/vmt_vendor.h","","",&t);
    if(r!=VENDOR_MACRO_TABLE_OK){printf("extract failed %d\n",r);return 1;}
    printf("total macros captured (incl. builtins): %zu\n",t.entry_count);
    chk_body(&t,"index","vendor_internal_index");
    chk_body(&t,"SETUP","int index; int count");
    /* function-like: body includes the param list */
    size_t ti; if(find_macro(&t,"TRANSFORM",&ti)){
        printf("  pass: TRANSFORM found, fnlike=%d\n",t.entries[ti].is_function_like);
        if(t.entries[ti].is_function_like!=1){printf("  FAIL: TRANSFORM should be fnlike\n");fails++;}
    } else {printf("  FAIL: TRANSFORM missing\n");fails++;}
    /* FLAG: no body */
    size_t fi; if(find_macro(&t,"FLAG",&fi)){
        if(t.entries[fi].body_length==0) printf("  pass: FLAG has empty body\n");
        else{printf("  FAIL: FLAG body not empty\n");fails++;}
    } else {printf("  FAIL: FLAG missing\n");fails++;}
    vendor_macro_table_release(&t);
    if(fails==0){printf("ALL VENDOR-MACRO-TABLE TESTS PASS\n");return 0;}
    printf("%d FAILED\n",fails);return 1;
}
