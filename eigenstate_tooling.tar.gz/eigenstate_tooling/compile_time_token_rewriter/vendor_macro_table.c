/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * vendor_macro_table.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter
 *
 * Purpose       : Implementation of vendor macro capture. Runs gcc -dM -E and
 *                 parses each "#define NAME BODY" line into a name and a body.
 *
 * Portability   : C99 plus POSIX (popen).
 *
 * Table of contents:
 *   [1] TEXT AND ENTRY GROWTH
 *   [2] DEFINE LINE PARSING
 *   [3] EXTRACTION
 *   [4] ACCESS
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200112L
#endif

#include "vendor_macro_table.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===========================================================================
 * [1] TEXT AND ENTRY GROWTH
 * ===========================================================================*/

static void vendor_macro_table_initialize_empty(VendorMacroTable *table)
{
        table->text           = NULL;
        table->text_length    = 0;
        table->text_capacity  = 0;
        table->entries        = NULL;
        table->entry_count    = 0;
        table->entry_capacity = 0;
}

/* Append raw bytes to the text block, returning the offset where they landed,
 * or (size_t)-1 on allocation failure. */
static size_t vendor_macro_table_append_text(VendorMacroTable *table,
                                             const char       *bytes,
                                             size_t            length)
{
        size_t needed = table->text_length + length;
        if (needed > table->text_capacity) {
                size_t new_capacity = table->text_capacity == 0
                                    ? 512 : table->text_capacity * 2;
                while (new_capacity < needed) {
                        new_capacity *= 2;
                }
                char *grown = realloc(table->text, new_capacity);
                if (grown == NULL) {
                        return (size_t)-1;
                }
                table->text          = grown;
                table->text_capacity = new_capacity;
        }
        size_t offset = table->text_length;
        memcpy(table->text + offset, bytes, length);
        table->text_length += length;
        return offset;
}

/* Returns nonzero on success, zero on allocation failure. */
static int vendor_macro_table_add_entry(VendorMacroTable *table,
                                        VendorMacroEntry  entry)
{
        if (table->entry_count + 1 > table->entry_capacity) {
                size_t new_capacity = table->entry_capacity == 0
                                    ? 64 : table->entry_capacity * 2;
                VendorMacroEntry *grown =
                        realloc(table->entries,
                                new_capacity * sizeof(VendorMacroEntry));
                if (grown == NULL) {
                        return 0;
                }
                table->entries        = grown;
                table->entry_capacity = new_capacity;
        }
        table->entries[table->entry_count++] = entry;
        return 1;
}

/* ===========================================================================
 * [2] DEFINE LINE PARSING
 * ===========================================================================
 *
 *  A -dM -E line is "#define NAME BODY" or "#define NAME(params) BODY" or
 *  "#define NAME" with no body. This parser locates the name, whether a '('
 *  immediately follows (function-like), and where the body begins. It records
 *  the name and the body (which for a function-like macro includes the
 *  parameter list, skipped later by the consumer).
 *
 * ===========================================================================*/

static int gate_is_identifier_start(char c)
{
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_';
}

static int gate_is_identifier_continue(char c)
{
        return gate_is_identifier_start(c) || (c >= '0' && c <= '9');
}

/* Parse one line. On a well-formed "#define ..." line, fills name/body spans
 * (as pointers + lengths into the line) and is_function_like, returns nonzero.
 * Returns zero for any non-#define line. */
static int parse_define_line(char        *line,
                             const char **name_ptr,
                             size_t      *name_len,
                             const char **body_ptr,
                             size_t      *body_len,
                             int         *is_function_like)
{
        /* strip trailing newline */
        size_t length = strlen(line);
        while (length > 0 && (line[length - 1] == '\n'
                           || line[length - 1] == '\r')) {
                line[--length] = '\0';
        }

        char *cursor = line;
        while (*cursor == ' ' || *cursor == '\t') {
                cursor++;
        }
        if (*cursor != '#') {
                return 0;
        }
        cursor++;
        while (*cursor == ' ' || *cursor == '\t') {
                cursor++;
        }

        static const char define_word[] = "define";
        size_t define_len = sizeof(define_word) - 1;
        if (strncmp(cursor, define_word, define_len) != 0) {
                return 0;
        }
        cursor += define_len;
        if (*cursor != ' ' && *cursor != '\t') {
                return 0;
        }
        while (*cursor == ' ' || *cursor == '\t') {
                cursor++;
        }

        /* name */
        if (!gate_is_identifier_start(*cursor)) {
                return 0;
        }
        *name_ptr = cursor;
        while (gate_is_identifier_continue(*cursor)) {
                cursor++;
        }
        *name_len = (size_t)(cursor - *name_ptr);

        /* function-like if '(' immediately follows the name, no space */
        *is_function_like = (*cursor == '(');

        /* body begins after one separating space, or immediately for a
         * function-like macro's parameter list */
        if (*is_function_like) {
                *body_ptr = cursor; /* includes "(params) body" */
        } else if (*cursor == ' ' || *cursor == '\t') {
                cursor++;
                *body_ptr = cursor;
        } else {
                /* no body (e.g. "#define FLAG") */
                *body_ptr = cursor;
        }
        *body_len = strlen(*body_ptr);
        return 1;
}

/* ===========================================================================
 * [3] EXTRACTION
 * ===========================================================================*/

static int build_dump_command(const char *vendor_header_path,
                              const char *include_flags,
                              const char *config_defines,
                              char       *command_buffer,
                              size_t      command_buffer_size)
{
        int written = snprintf(command_buffer, command_buffer_size,
                               "gcc -dM -E %s %s '%s'",
                               include_flags, config_defines,
                               vendor_header_path);
        return written > 0 && (size_t)written < command_buffer_size;
}

VendorMacroTableResult vendor_macro_table_extract(const char       *vendor_header_path,
                                                  const char       *include_flags,
                                                  const char       *config_defines,
                                                  VendorMacroTable *table_out)
{
        vendor_macro_table_initialize_empty(table_out);

        char command_buffer[8192];
        if (!build_dump_command(vendor_header_path, include_flags,
                                config_defines, command_buffer,
                                sizeof(command_buffer))) {
                return VENDOR_MACRO_TABLE_TOOL_FAILED;
        }

        FILE *pipe = popen(command_buffer, "r");
        if (pipe == NULL) {
                return VENDOR_MACRO_TABLE_TOOL_FAILED;
        }

        char                   line_buffer[16384];
        VendorMacroTableResult result = VENDOR_MACRO_TABLE_OK;
        while (fgets(line_buffer, sizeof(line_buffer), pipe) != NULL) {
                const char *name_ptr;
                size_t      name_len;
                const char *body_ptr;
                size_t      body_len;
                int         is_function_like;
                if (!parse_define_line(line_buffer, &name_ptr, &name_len,
                                       &body_ptr, &body_len,
                                       &is_function_like)) {
                        continue; /* non-#define lines are ignored, not errors */
                }

                size_t name_off = vendor_macro_table_append_text(
                        table_out, name_ptr, name_len);
                if (name_off == (size_t)-1) {
                        result = VENDOR_MACRO_TABLE_OUT_OF_MEMORY;
                        break;
                }
                size_t body_off = table_out->text_length;
                if (body_len > 0) {
                        body_off = vendor_macro_table_append_text(
                                table_out, body_ptr, body_len);
                        if (body_off == (size_t)-1) {
                                result = VENDOR_MACRO_TABLE_OUT_OF_MEMORY;
                                break;
                        }
                }

                VendorMacroEntry entry;
                entry.name_offset      = name_off;
                entry.name_length      = name_len;
                entry.body_offset      = body_off;
                entry.body_length      = body_len;
                entry.is_function_like = is_function_like;
                if (!vendor_macro_table_add_entry(table_out, entry)) {
                        result = VENDOR_MACRO_TABLE_OUT_OF_MEMORY;
                        break;
                }
        }

        int close_status = pclose(pipe);
        if (result == VENDOR_MACRO_TABLE_OK && close_status != 0) {
                result = VENDOR_MACRO_TABLE_TOOL_FAILED;
        }

        if (result != VENDOR_MACRO_TABLE_OK) {
                vendor_macro_table_release(table_out);
                return result;
        }
        return VENDOR_MACRO_TABLE_OK;
}

void vendor_macro_table_release(VendorMacroTable *table)
{
        free(table->text);
        free(table->entries);
        vendor_macro_table_initialize_empty(table);
}

/* ===========================================================================
 * [4] ACCESS
 * ===========================================================================*/

const char *vendor_macro_table_name(const VendorMacroTable *table, size_t index)
{
        if (index >= table->entry_count) {
                return NULL;
        }
        return table->text + table->entries[index].name_offset;
}

const char *vendor_macro_table_body(const VendorMacroTable *table, size_t index)
{
        if (index >= table->entry_count
            || table->entries[index].body_length == 0) {
                return NULL;
        }
        return table->text + table->entries[index].body_offset;
}
