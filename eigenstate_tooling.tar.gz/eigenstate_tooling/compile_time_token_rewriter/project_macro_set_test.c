#include "project_macro_set.h"
#include "lexical_scanner.h"
#include <stdio.h>
#include <string.h>
static int fails=0;
static void chk(const char*label,const SymbolSet*s,const char*name,int want){
    int got=symbol_set_contains(s,name);
    if(got==want) printf("  pass [%s]: '%s' %s\n",label,name,want?"present":"absent");
    else{printf("  FAIL [%s]: '%s' got %d want %d\n",label,name,got,want);fails++;}
}
int main(void){
    const char*src=
        "#define PROJECT_TRUE 1\n"
        "#define MAX_BUFFER_LENGTH 4096\n"
        "#define SQUARE(x) ((x)*(x))\n"       /* function-like: name is SQUARE */
        "#  define SPACED_MACRO 7\n"          /* space after # */
        "int not_a_macro = PROJECT_TRUE;\n"   /* a use, not a define */
        "int defined_looking;\n";             /* not a macro at all */
    LexicalToken tk[512]; LexicalScannerState st; LexicalToken t; size_t n=0;
    lexical_scanner_initialize(&st,(const unsigned char*)src,strlen(src));
    while(n<512 && lexical_scanner_next_token(&st,&t)) tk[n++]=t;
    SymbolSet macros;
    if(project_macro_set_collect((const unsigned char*)src,tk,n,&macros)!=PROJECT_MACRO_SET_OK){
        printf("collect failed\n"); return 1;
    }
    chk("obj-like",&macros,"PROJECT_TRUE",1);
    chk("obj-like",&macros,"MAX_BUFFER_LENGTH",1);
    chk("fn-like",&macros,"SQUARE",1);
    chk("spaced",&macros,"SPACED_MACRO",1);
    chk("not-defined",&macros,"not_a_macro",0);
    chk("not-defined",&macros,"defined_looking",0);
    chk("fn-param-not-collected",&macros,"x",0);
    symbol_set_release(&macros);
    if(fails==0){printf("ALL PROJECT-MACRO-SET TESTS PASS\n");return 0;}
    printf("%d FAILED\n",fails);return 1;
}
