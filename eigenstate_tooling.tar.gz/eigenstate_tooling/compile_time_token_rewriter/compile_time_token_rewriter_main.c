/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * compile_time_token_rewriter_main.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter (orchestrator)
 *
 * Purpose       : Command-line front end. Parses flags into a RewriterInvocation
 *                 and runs the rewriter. This file holds argument parsing only;
 *                 all behavior is in compile_time_token_rewriter.c.
 *
 * Flags         : --project-root DIR   --vendor-root DIR   --whitelist FILE
 *                 --state KEYWORD       --output DIR        then source files.
 *
 * Portability   : C99.
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "compile_time_token_rewriter.h"

#include <stdio.h>
#include <string.h>

static int flag_matches(const char *argument, const char *flag)
{
        return strcmp(argument, flag) == 0;
}

int main(int argc, char **argv)
{
        const char  *project_root     = ".";
        const char  *vendor_root      = ".";
        const char  *whitelist_path   = NULL;
        const char  *state_keyword    = "STATE_C_ISOLATE";
        const char  *output_directory = ".";
        const char  *inputs[256];
        size_t       input_count = 0;

        int index = 1;
        while (index < argc) {
                const char *arg = argv[index];
                if (flag_matches(arg, "--project-root") && index + 1 < argc) {
                        project_root = argv[++index];
                } else if (flag_matches(arg, "--vendor-root")
                           && index + 1 < argc) {
                        vendor_root = argv[++index];
                } else if (flag_matches(arg, "--whitelist")
                           && index + 1 < argc) {
                        whitelist_path = argv[++index];
                } else if (flag_matches(arg, "--state") && index + 1 < argc) {
                        state_keyword = argv[++index];
                } else if (flag_matches(arg, "--output") && index + 1 < argc) {
                        output_directory = argv[++index];
                } else if (arg[0] == '-') {
                        fprintf(stderr,
                                "compile time token rewriter: unknown flag %s\n",
                                arg);
                        return 2;
                } else {
                        if (input_count < sizeof(inputs) / sizeof(inputs[0])) {
                                inputs[input_count++] = arg;
                        }
                }
                index++;
        }

        RewriterInvocation invocation;
        invocation.project_root       = project_root;
        invocation.vendor_root        = vendor_root;
        invocation.whitelist_path     = whitelist_path;
        invocation.state_keyword      = state_keyword;
        invocation.output_directory   = output_directory;
        invocation.input_source_paths = inputs;
        invocation.input_source_count = input_count;

        return compile_time_token_rewriter_run(&invocation);
}
