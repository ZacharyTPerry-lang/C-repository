/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * project_macro_set.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter
 *
 * Purpose       : Collect the set of macro names a project source buffer
 *                 defines. The rewriter prefixes references to project macros;
 *                 to do that it must know which identifiers ARE project macros.
 *                 A macro is introduced by a #define directive, which the
 *                 lexical scanner already isolates as a single
 *                 PREPROCESSOR_LINE token. This module reads those tokens and
 *                 extracts the defined name from each.
 *
 * Why not a macro EXPANDER : the rewriter does not expand project macros -- GCC
 *                 does that at the real compile. The rewriter only needs the
 *                 NAMES, so that a later reference to one can be prefixed. This
 *                 module therefore recognizes the shape "#define NAME ..." and
 *                 records NAME; it does not evaluate the replacement list, does
 *                 not track #undef scope, and does not expand.
 *
 * Scope         : project source only. Vendor macros are never collected here;
 *                 vendor macros are handled by the boundary, not by prefixing.
 *                 A project file is scanned for its own #define lines.
 *
 * Portability   : C99. Freestanding: depends on <stddef.h>, the scanner's token
 *                 type, and the SymbolSet storage from symbol_set_from_object,
 *                 reused so macro names live in the same sorted-set structure.
 *
 * Table of contents:
 *   [1] COLLECTION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef PROJECT_MACRO_SET_H
#define PROJECT_MACRO_SET_H

#include <stddef.h>
#include "lexical_scanner.h"
#include "symbol_set_from_object.h"   /* reuse SymbolSet as the name container */

/* ===========================================================================
 * [1] COLLECTION
 * ===========================================================================*/

typedef enum ProjectMacroSetResult {
        PROJECT_MACRO_SET_OK,
        PROJECT_MACRO_SET_OUT_OF_MEMORY
} ProjectMacroSetResult;

/* ---------------------------------------------------------------------------
 *  Operation : project_macro_set_collect
 *
 *  Scan a token array over a project source buffer and collect the name
 *  defined by every #define directive into a freshly initialized SymbolSet,
 *  sorted for query. Object-like and function-like macros both contribute
 *  their name; the parameter list of a function-like macro is not part of the
 *  name and is not collected.
 *
 *  The set is owned by the caller on success and released with
 *  symbol_set_release. On failure the set is left empty and released
 *  internally.
 *
 *  Remark : the defined name is the first identifier on the directive line
 *  after the "define" keyword. For a function-like macro "#define F(x)" the
 *  name is F and the '(' must immediately follow with no intervening space,
 *  per the C rule; this module records F regardless, since it collects names
 *  not signatures.
 *
 *  IN   source_buffer     VALID    CONSUME   ALWAYS      KEEP  NONE  the bytes
 *  IN   tokens            VALID    CONSUME   ALWAYS      KEEP  NONE  token array
 *  IN   token_count       VALID    CONSUME   ALWAYS      NONE  NONE  length
 *  OUT  macro_name_set_out GARBAGE POPULATE  IF_SUCCESS  KEEP  NONE  the set
 * ---------------------------------------------------------------------------*/
ProjectMacroSetResult project_macro_set_collect(const unsigned char *source_buffer,
                                                const LexicalToken  *tokens,
                                                size_t               token_count,
                                                SymbolSet           *macro_name_set_out);

#endif /* PROJECT_MACRO_SET_H */
