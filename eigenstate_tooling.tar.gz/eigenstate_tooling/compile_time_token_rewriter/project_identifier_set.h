/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * project_identifier_set.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter
 *
 * Purpose       : Collect every identifier a project source buffer uses, from
 *                 the lexer's token stream. Collision detection checks vendor
 *                 macro names and expansions against this set; a vendor macro
 *                 that matches any project identifier is a collision.
 *
 * Why the lexer, not nm : the identifiers that can be captured include locals
 *                 and parameters -- the canonical case is a vendor "index"
 *                 macro capturing a project function's "index" parameter. A
 *                 parameter has no linkage, so nm never sees it; only the lexer
 *                 does. The collision-detection identifier set is therefore
 *                 source-scoped (every identifier token), distinct from the
 *                 linkage-scoped set nm provides for reverse-dependency
 *                 discovery. Two jobs, two identifier sources, each correct for
 *                 its job.
 *
 * What counts    : every LEXICAL_TOKEN_CATEGORY_IDENTIFIER token. This
 *                 over-collects harmlessly: it includes type keywords and the
 *                 like, which simply never match a vendor macro that matters,
 *                 and collecting them costs nothing. The set is the raw
 *                 identifier vocabulary of the source.
 *
 * Portability   : C99. Freestanding: depends on the scanner and the SymbolSet
 *                 container.
 *
 * Table of contents:
 *   [1] COLLECTION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef PROJECT_IDENTIFIER_SET_H
#define PROJECT_IDENTIFIER_SET_H

#include <stddef.h>
#include "lexical_scanner.h"
#include "symbol_set_from_object.h"   /* SymbolSet container */

typedef enum ProjectIdentifierSetResult {
        PROJECT_IDENTIFIER_SET_OK,
        PROJECT_IDENTIFIER_SET_OUT_OF_MEMORY
} ProjectIdentifierSetResult;

/* ---------------------------------------------------------------------------
 *  Operation : project_identifier_set_collect
 *
 *  Collect every identifier token in the token array into a freshly
 *  initialized SymbolSet, sorted for query. Duplicates collapse under query.
 *  The set is owned by the caller on success and released with
 *  symbol_set_release.
 *
 *  IN   source_buffer     VALID    CONSUME   ALWAYS      KEEP  NONE  the bytes
 *  IN   tokens            VALID    CONSUME   ALWAYS      KEEP  NONE  token array
 *  IN   token_count       VALID    CONSUME   ALWAYS      NONE  NONE  length
 *  OUT  identifier_set_out GARBAGE POPULATE  IF_SUCCESS  KEEP  NONE  the set
 * ---------------------------------------------------------------------------*/
ProjectIdentifierSetResult project_identifier_set_collect(
        const unsigned char *source_buffer,
        const LexicalToken  *tokens,
        size_t               token_count,
        SymbolSet           *identifier_set_out);

#endif /* PROJECT_IDENTIFIER_SET_H */
