/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * collision_detection.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter
 *
 * Purpose       : Implementation of the static collision layer. Checks each
 *                 vendor macro's name and expansion identifiers against the
 *                 project identifier and macro sets, classifying every match.
 *
 * Portability   : C99. Uses the lexical scanner to tokenize macro bodies.
 *
 * Table of contents:
 *   [1] REPORT GROWTH
 *   [2] CLASSIFICATION
 *   [3] BODY IDENTIFIER SCAN
 *   [4] DETECTION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "collision_detection.h"
#include "lexical_scanner.h"

#include <stdlib.h>
#include <string.h>

/* ===========================================================================
 * [0] EXCLUSIONS
 * ===========================================================================
 *
 *  Two kinds of identifier must never be treated as a collision:
 *
 *  C keywords. The lexical scanner deliberately does not know keywords -- that
 *  keeps it free of grammar -- so a project source's "int" arrives as an
 *  identifier token and lands in the project identifier set. A keyword is not a
 *  project symbol a vendor macro can capture, so keywords are filtered here,
 *  which is the layer that owns this piece of C knowledge.
 *
 *  Function-like macro parameter names. A parameter used in a macro body is a
 *  placeholder replaced by the caller's argument; it is not a free identifier
 *  and cannot collide with project space. Parameter names are extracted from
 *  the macro's parameter list and excluded from the body scan.
 *
 * ===========================================================================*/

static int gate_is_c_keyword(const char *name)
{
        static const char *const keywords[] = {
                "auto", "break", "case", "char", "const", "continue",
                "default", "do", "double", "else", "enum", "extern", "float",
                "for", "goto", "if", "inline", "int", "long", "register",
                "restrict", "return", "short", "signed", "sizeof", "static",
                "struct", "switch", "typedef", "union", "unsigned", "void",
                "volatile", "while", "_Bool", "_Complex", "_Imaginary",
                "_Alignas", "_Alignof", "_Atomic", "_Generic", "_Noreturn",
                "_Static_assert", "_Thread_local"
        };
        size_t count = sizeof(keywords) / sizeof(keywords[0]);
        size_t index;
        for (index = 0; index < count; index++) {
                if (strcmp(keywords[index], name) == 0) {
                        return 1;
                }
        }
        return 0;
}

/* ===========================================================================
 * [1] REPORT GROWTH
 * ===========================================================================*/

static void collision_report_initialize_empty(CollisionReport *report)
{
        report->entries        = NULL;
        report->entry_count    = 0;
        report->entry_capacity = 0;
}

/* Duplicate a byte range into a NUL-terminated heap string. NULL on failure. */
static char *duplicate_name(const char *bytes, size_t length)
{
        char *copy = malloc(length + 1);
        if (copy == NULL) {
                return NULL;
        }
        memcpy(copy, bytes, length);
        copy[length] = '\0';
        return copy;
}

/* Returns nonzero on success, zero on allocation failure. Takes ownership of
 * the two name strings on success; frees them on failure. */
static int collision_report_add(CollisionReport  *report,
                                char             *vendor_macro_name,
                                char             *project_name,
                                int               through_expansion,
                                CollisionCategory category)
{
        if (report->entry_count + 1 > report->entry_capacity) {
                size_t new_capacity = report->entry_capacity == 0
                                    ? 16 : report->entry_capacity * 2;
                CollisionReportEntry *grown =
                        realloc(report->entries,
                                new_capacity * sizeof(CollisionReportEntry));
                if (grown == NULL) {
                        free(vendor_macro_name);
                        free(project_name);
                        return 0;
                }
                report->entries        = grown;
                report->entry_capacity = new_capacity;
        }
        CollisionReportEntry *entry = &report->entries[report->entry_count++];
        entry->vendor_macro_name = vendor_macro_name;
        entry->project_name      = project_name;
        entry->through_expansion = through_expansion;
        entry->category          = category;
        return 1;
}

/* ===========================================================================
 * [2] CLASSIFICATION
 * ===========================================================================
 *
 *  Given a candidate name (a vendor macro name or a body identifier), decide
 *  whether it collides with project space and into which category. Returns
 *  nonzero if a collision was recorded. The whitelist is checked first: a
 *  sanctioned crossing is not an unguarded collision.
 *
 * ===========================================================================*/

/* name_bytes/name_length is the vendor side (macro name or body token). */
static int classify_and_record(CollisionReport             *report,
                               const char                  *vendor_macro_name,
                               size_t                       vendor_macro_name_length,
                               const char                  *candidate,
                               size_t                       candidate_length,
                               int                          through_expansion,
                               const SymbolSet             *project_identifier_set,
                               const SymbolSet             *project_macro_set,
                               const DeclaredCrossingTable *whitelist,
                               int                         *out_of_memory)
{
        char *candidate_z = duplicate_name(candidate, candidate_length);
        if (candidate_z == NULL) {
                *out_of_memory = 1;
                return 0;
        }

        /* a C keyword is not a project symbol; never a collision */
        if (gate_is_c_keyword(candidate_z)) {
                free(candidate_z);
                return 0;
        }

        int in_identifiers = symbol_set_contains(project_identifier_set,
                                                 candidate_z);
        int in_macros      = symbol_set_contains(project_macro_set,
                                                 candidate_z);

        if (!in_identifiers && !in_macros) {
                free(candidate_z);
                return 0; /* no collision */
        }

        CollisionCategory category;
        if (declared_crossing_table_declares_symbol(whitelist, candidate_z)) {
                category = COLLISION_CATEGORY_WHITELISTED;
        } else if (in_identifiers) {
                /* identifier capture takes precedence: prefixing cannot fix it,
                 * so it is the disposition the caller must be warned about even
                 * if the name is also a project macro. */
                category = COLLISION_CATEGORY_IDENTIFIER_CAPTURE;
        } else {
                category = COLLISION_CATEGORY_MACRO_SHADOW;
        }

        char *vendor_name_z = duplicate_name(vendor_macro_name,
                                             vendor_macro_name_length);
        if (vendor_name_z == NULL) {
                free(candidate_z);
                *out_of_memory = 1;
                return 0;
        }

        if (!collision_report_add(report, vendor_name_z, candidate_z,
                                  through_expansion, category)) {
                *out_of_memory = 1;
                return 0;
        }
        return 1;
}

/* ===========================================================================
 * [3] BODY IDENTIFIER SCAN
 * ===========================================================================
 *
 *  Tokenize a macro body and check each identifier. For a function-like macro
 *  the body begins with a parenthesized parameter list; those parameter names
 *  are local to the macro and are skipped by ignoring identifiers up to and
 *  including the closing parenthesis of a leading parameter list.
 *
 * ===========================================================================*/

/* Returns the byte offset within the body at which the real replacement text
 * begins, skipping a leading "(params)" for a function-like macro. For an
 * object-like macro this is 0. */
static size_t body_replacement_offset(const char *body, size_t body_length,
                                      int is_function_like)
{
        if (!is_function_like || body_length == 0 || body[0] != '(') {
                return 0;
        }
        size_t cursor = 0;
        int    depth  = 0;
        while (cursor < body_length) {
                if (body[cursor] == '(') {
                        depth++;
                } else if (body[cursor] == ')') {
                        depth--;
                        if (depth == 0) {
                                return cursor + 1;
                        }
                }
                cursor++;
        }
        return body_length; /* malformed; nothing after */
}

/* ===========================================================================
 * [3b] TOKEN-PASTE AFFIX DETECTION
 * ===========================================================================
 *
 *  A macro body containing the paste operator ## constructs identifiers at
 *  expansion. The constructed name is not literally in the body, so the plain
 *  body scan cannot see it. This scan finds each ##, examines the fixed
 *  (non-parameter) identifier on each side, and asks whether that fixed affix
 *  could construct a project identifier: a prefix affix before ## can build any
 *  project name starting with it, a suffix affix after ## any project name
 *  ending with it. A match is a potential constructed capture, reported
 *  over-cautiously.
 *
 *  The lexer emits ## as two single-byte '#' punctuator tokens (it does not
 *  combine punctuators), so a paste is two adjacent '#' tokens.
 *
 * ===========================================================================*/

/* Returns nonzero if the token at index is a '#' punctuator in the body. */
static int token_is_hash(const char *body, const LexicalToken *token)
{
        return token->category == LEXICAL_TOKEN_CATEGORY_PUNCTUATOR
            && (token->byte_offset_end - token->byte_offset_start) == 1
            && body[token->byte_offset_start] == '#';
}

/* Scan a macro body for ## pastes and record potential constructed captures.
 * A paste affix that is itself a macro parameter is not fixed -- it is replaced
 * by the argument -- so parameter affixes are excluded via parameter_set. */
static int scan_paste_affixes(CollisionReport      *report,
                              const char           *vendor_macro_name,
                              size_t                vendor_macro_name_length,
                              const char           *body,
                              size_t                body_length,
                              const SymbolSet      *project_identifier_set,
                              const SymbolSet      *parameter_set,
                              const DeclaredCrossingTable *whitelist,
                              int                  *out_of_memory)
{
        /* tokenize the whole body (including the parameter list; a fixed affix
         * is any identifier not itself a lone parameter, and matching against
         * project identifiers naturally excludes bare parameter names that are
         * not project symbols). */
        LexicalToken tokens[4096];
        size_t       count = 0;
        LexicalScannerState scanner;
        LexicalToken        token;
        lexical_scanner_initialize(&scanner,
                                   (const unsigned char *)body, body_length);
        while (count < (sizeof(tokens) / sizeof(tokens[0]))
               && lexical_scanner_next_token(&scanner, &token)) {
                tokens[count++] = token;
        }

        size_t index;
        for (index = 0; index + 1 < count; index++) {
                if (!token_is_hash(body, &tokens[index])
                    || !token_is_hash(body, &tokens[index + 1])) {
                        continue;
                }
                /* found "##" at index, index+1. find the identifier token
                 * before it and after it, skipping whitespace. */
                const LexicalToken *before = NULL;
                const LexicalToken *after  = NULL;
                size_t back = index;
                while (back > 0) {
                        back--;
                        if (tokens[back].category
                            == LEXICAL_TOKEN_CATEGORY_WHITESPACE) {
                                continue;
                        }
                        if (tokens[back].category
                            == LEXICAL_TOKEN_CATEGORY_IDENTIFIER) {
                                before = &tokens[back];
                        }
                        break;
                }
                size_t forward = index + 2;
                while (forward < count) {
                        if (tokens[forward].category
                            == LEXICAL_TOKEN_CATEGORY_WHITESPACE) {
                                forward++;
                                continue;
                        }
                        if (tokens[forward].category
                            == LEXICAL_TOKEN_CATEGORY_IDENTIFIER) {
                                after = &tokens[forward];
                        }
                        break;
                }

                /* prefix affix: identifier immediately before ## can build any
                 * project name starting with it. */
                if (before != NULL) {
                        char affix[512];
                        size_t len = before->byte_offset_end
                                   - before->byte_offset_start;
                        if (len < sizeof(affix)) {
                                memcpy(affix, body + before->byte_offset_start,
                                       len);
                                affix[len] = '\0';
                                if (!symbol_set_contains(parameter_set, affix)
                                    && symbol_set_any_starts_with(
                                            project_identifier_set, affix)
                                    && !declared_crossing_table_declares_symbol(
                                            whitelist, affix)) {
                                        char *vn = duplicate_name(
                                                vendor_macro_name,
                                                vendor_macro_name_length);
                                        char *pn = duplicate_name(affix, len);
                                        if (vn == NULL || pn == NULL
                                            || !collision_report_add(
                                                   report, vn, pn, 1,
                                                   COLLISION_CATEGORY_CONSTRUCTED_CAPTURE)) {
                                                free(vn); free(pn);
                                                *out_of_memory = 1;
                                                return 0;
                                        }
                                }
                        }
                }
                /* suffix affix: identifier immediately after ## can build any
                 * project name ending with it. */
                if (after != NULL) {
                        char affix[512];
                        size_t len = after->byte_offset_end
                                   - after->byte_offset_start;
                        if (len < sizeof(affix)) {
                                memcpy(affix, body + after->byte_offset_start,
                                       len);
                                affix[len] = '\0';
                                if (!symbol_set_contains(parameter_set, affix)
                                    && symbol_set_any_ends_with(
                                            project_identifier_set, affix)
                                    && !declared_crossing_table_declares_symbol(
                                            whitelist, affix)) {
                                        char *vn = duplicate_name(
                                                vendor_macro_name,
                                                vendor_macro_name_length);
                                        char *pn = duplicate_name(affix, len);
                                        if (vn == NULL || pn == NULL
                                            || !collision_report_add(
                                                   report, vn, pn, 1,
                                                   COLLISION_CATEGORY_CONSTRUCTED_CAPTURE)) {
                                                free(vn); free(pn);
                                                *out_of_memory = 1;
                                                return 0;
                                        }
                                }
                        }
                }
        }
        return 1;
}

/* ===========================================================================
 * [4] DETECTION
 * ===========================================================================*/

CollisionDetectionResult collision_detection_run(
        const VendorMacroTable      *vendor_table,
        const SymbolSet             *project_identifier_set,
        const SymbolSet             *project_macro_set,
        const DeclaredCrossingTable *whitelist,
        CollisionReport             *report_out)
{
        collision_report_initialize_empty(report_out);

        int    out_of_memory = 0;
        size_t macro_index;
        for (macro_index = 0;
             macro_index < vendor_table->entry_count;
             macro_index++) {
                const char *name = vendor_macro_table_name(vendor_table,
                                                           macro_index);
                size_t name_length =
                        vendor_table->entries[macro_index].name_length;

                /* check the macro name itself */
                classify_and_record(report_out, name, name_length,
                                    name, name_length, 0,
                                    project_identifier_set, project_macro_set,
                                    whitelist, &out_of_memory);
                if (out_of_memory) {
                        collision_report_release(report_out);
                        return COLLISION_DETECTION_OUT_OF_MEMORY;
                }

                /* check identifiers in the body */
                const char *body = vendor_macro_table_body(vendor_table,
                                                           macro_index);
                if (body == NULL) {
                        continue;
                }
                size_t body_length =
                        vendor_table->entries[macro_index].body_length;
                int is_fnlike =
                        vendor_table->entries[macro_index].is_function_like;
                size_t start = body_replacement_offset(body, body_length,
                                                       is_fnlike);

                /* For a function-like macro, collect the parameter names so
                 * body identifiers that are parameters can be excluded: a
                 * parameter is a placeholder, not a free identifier. The
                 * parameter list is body[0 .. start). */
                SymbolSet parameter_set;
                symbol_set_begin(&parameter_set);
                if (is_fnlike && start > 0) {
                        LexicalScannerState param_scanner;
                        LexicalToken        param_token;
                        lexical_scanner_initialize(
                                &param_scanner,
                                (const unsigned char *)body, start);
                        while (lexical_scanner_next_token(&param_scanner,
                                                          &param_token)) {
                                if (param_token.category
                                    != LEXICAL_TOKEN_CATEGORY_IDENTIFIER) {
                                        continue;
                                }
                                if (!symbol_set_add_name(
                                            &parameter_set,
                                            body + param_token.byte_offset_start,
                                            param_token.byte_offset_end
                                                - param_token.byte_offset_start)) {
                                        symbol_set_release(&parameter_set);
                                        collision_report_release(report_out);
                                        return COLLISION_DETECTION_OUT_OF_MEMORY;
                                }
                        }
                        symbol_set_finalize(&parameter_set);
                }

                LexicalScannerState scanner;
                LexicalToken        token;
                lexical_scanner_initialize(
                        &scanner,
                        (const unsigned char *)(body + start),
                        body_length - start);
                while (lexical_scanner_next_token(&scanner, &token)) {
                        if (token.category
                            != LEXICAL_TOKEN_CATEGORY_IDENTIFIER) {
                                continue;
                        }
                        const char *tok = body + start
                                        + token.byte_offset_start;
                        size_t tok_length = token.byte_offset_end
                                          - token.byte_offset_start;
                        /* skip identifiers that are parameters of this macro */
                        char tok_z[512];
                        if (tok_length < sizeof(tok_z)) {
                                memcpy(tok_z, tok, tok_length);
                                tok_z[tok_length] = '\0';
                                if (symbol_set_contains(&parameter_set,
                                                        tok_z)) {
                                        continue;
                                }
                        }
                        classify_and_record(
                                report_out, name, name_length,
                                tok, tok_length, 1,
                                project_identifier_set, project_macro_set,
                                whitelist, &out_of_memory);
                        if (out_of_memory) {
                                symbol_set_release(&parameter_set);
                                collision_report_release(report_out);
                                return COLLISION_DETECTION_OUT_OF_MEMORY;
                        }
                }
                /* also scan the replacement text for ## paste affixes that could
                 * construct a project identifier not literally in the body */
                if (!scan_paste_affixes(report_out, name, name_length,
                                        body + start, body_length - start,
                                        project_identifier_set, &parameter_set,
                                        whitelist, &out_of_memory)) {
                        if (out_of_memory) {
                                symbol_set_release(&parameter_set);
                                collision_report_release(report_out);
                                return COLLISION_DETECTION_OUT_OF_MEMORY;
                        }
                }
                symbol_set_release(&parameter_set);
        }

        return COLLISION_DETECTION_OK;
}

void collision_report_release(CollisionReport *report)
{
        size_t index;
        for (index = 0; index < report->entry_count; index++) {
                free(report->entries[index].vendor_macro_name);
                free(report->entries[index].project_name);
        }
        free(report->entries);
        collision_report_initialize_empty(report);
}
