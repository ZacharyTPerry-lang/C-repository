/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * compile_time_token_rewriter.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter (orchestrator)
 *
 * Purpose       : Compose the leaf modules into the transformation that sits
 *                 between human-readable project source and GCC. Two jobs:
 *
 *                   collision prevention : prefix references to project macros
 *                     so a vendor macro of the same bare name cannot reach
 *                     them, and hold to the boundary discipline (State C by
 *                     default) under which the vendor macro namespace never
 *                     enters a translation unit holding project identifiers, so
 *                     a vendor macro cannot capture a project identifier.
 *
 *                   reverse-dependency enforcement : discover, from the vendor
 *                     objects, every project symbol a vendor demands, and
 *                     require each to be declared in the whitelist. An
 *                     undeclared compelled crossing is a build error naming the
 *                     symbol.
 *
 * Composition   : lexical_scanner tokenizes project source;
 *                 project_macro_set gives the names to prefix;
 *                 parameter_contract_{recognizer,translator} strip annotations;
 *                 symbol_set_from_object + boundary_crossing_discovery find
 *                 reverse dependencies; boundary_crossing_enforcement judges
 *                 them. This module wires those together and writes the
 *                 translated source to the output tree.
 *
 * What it emits : for each input source file, a translated file under the
 *                 output directory with project macros prefixed and contract
 *                 annotations stripped -- valid C for GCC to compile. It does
 *                 not compile; GCC does, from the output tree.
 *
 * Portability   : C99 plus POSIX (inherited via nm and file I/O).
 *
 * Table of contents:
 *   [1] INVOCATION
 *   [2] ENTRY POINT
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef COMPILE_TIME_TOKEN_REWRITER_H
#define COMPILE_TIME_TOKEN_REWRITER_H

#include <stddef.h>

/* ===========================================================================
 * [1] INVOCATION
 * ===========================================================================
 *
 *  The parsed command line. The rewriter is driven from the build system with
 *  these settings; they mirror the flags the acceptance tests pass.
 *
 * ---------------------------------------------------------------------------
 *  project_root        directory of project source (context for the run)
 *  vendor_root         directory of vendored dependencies; vendor objects for
 *                      reverse-dependency discovery are found beneath it
 *  whitelist_path      path to the crossing whitelist, or NULL if none is
 *                      supplied (in which case any compelled crossing is
 *                      undeclared and errors)
 *  state_keyword       the one build-wide state, e.g. "STATE_C_ISOLATE"
 *  output_directory    where translated source files are written
 *  input_source_paths  the source files to translate
 *  input_source_count  number of input source files
 * ---------------------------------------------------------------------------*/

typedef struct RewriterInvocation {
        const char        *project_root;
        const char        *vendor_root;
        const char        *whitelist_path;
        const char        *state_keyword;
        const char        *output_directory;
        const char *const *input_source_paths;
        size_t             input_source_count;
} RewriterInvocation;

/* ===========================================================================
 * [2] ENTRY POINT
 * ===========================================================================*/

/* ---------------------------------------------------------------------------
 *  Operation : compile_time_token_rewriter_run
 *
 *  Execute both jobs for the given invocation. Returns 0 on success; nonzero on
 *  any failure, including an undeclared compelled crossing, a malformed
 *  whitelist, an unreadable input, or a tool failure. Diagnostics naming the
 *  cause are written to standard error.
 *
 *  IN  invocation  VALID  CONSUME  ALWAYS  KEEP  NONE  the parsed command line
 * ---------------------------------------------------------------------------*/
int compile_time_token_rewriter_run(const RewriterInvocation *invocation);

#endif /* COMPILE_TIME_TOKEN_REWRITER_H */
