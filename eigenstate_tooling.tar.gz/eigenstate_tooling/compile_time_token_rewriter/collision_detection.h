/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * collision_detection.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : compile_time_token_rewriter
 *
 * Purpose       : Detect every collision between a vendor's macros and project
 *                 space, and sort each into its category. A collision is a
 *                 vendor macro whose name, or any identifier in its expansion,
 *                 matches a project identifier or a project macro. Both sides of
 *                 every vendor macro are checked, because a vendor macro can
 *                 collide through its name (capturing a project identifier) or
 *                 through its expansion (expanding to a project symbol).
 *
 * Completeness  : the static check here catches every collision that is
 *                 enumerable from the macro table. Collisions constructed only
 *                 at expansion time -- token pasting, transitive chains -- are
 *                 caught by the separate post-preprocessing verification, which
 *                 tokenizes the compiler's actual output; a token that is never
 *                 constructed is a collision that never fires and cannot occur.
 *                 Between the two layers, every collision that can occur in the
 *                 build is seen. This module is the static layer.
 *
 * The sort      : each detected collision is classified so the caller knows how
 *                 to treat it. The categories mirror the boundary's three
 *                 dispositions:
 *
 *   WHITELISTED         the symbol is declared to cross under the state gate;
 *                       the collision is sanctioned, not a problem.
 *   IDENTIFIER_CAPTURE  collides with a project identifier and is not
 *                       whitelisted; prefixing cannot help because identifiers
 *                       are not prefixed. The caller must be notified: this is
 *                       the unguarded hazard.
 *   MACRO_SHADOW        collides with a project macro and is not whitelisted;
 *                       the prefix system resolves it, because the project
 *                       macro reference will be prefixed and the vendor macro
 *                       will not. Informational.
 *
 *  Reverse dependencies are NOT sorted here; they are discovered from vendor
 *  object symbols by boundary_crossing_discovery and enforced separately. This
 *  module concerns macro-level collisions only.
 *
 * Portability   : C99 plus the tools its inputs use (nm, gcc dump). The
 *                 detection logic itself is pure C99.
 *
 * Table of contents:
 *   [1] COLLISION CATEGORY AND REPORT
 *   [2] DETECTION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef COLLISION_DETECTION_H
#define COLLISION_DETECTION_H

#include <stddef.h>
#include "vendor_macro_table.h"
#include "symbol_set_from_object.h"
#include "boundary_crossing_enforcement.h"

/* ===========================================================================
 * [1] COLLISION CATEGORY AND REPORT
 * ===========================================================================*/

typedef enum CollisionCategory {
        COLLISION_CATEGORY_WHITELISTED,
        COLLISION_CATEGORY_IDENTIFIER_CAPTURE,
        COLLISION_CATEGORY_MACRO_SHADOW,
        /* A token-paste (##) whose fixed affix could construct a project
         * identifier. The colliding name is not literally in the macro body; it
         * would be built at expansion from the affix plus an argument. Reported
         * over-cautiously: the paste may never fire with the constructing
         * argument, but a potential capture is surfaced for the whitelist to
         * resolve. project_name holds the affix that matched. */
        COLLISION_CATEGORY_CONSTRUCTED_CAPTURE
} CollisionCategory;

/* One collision: which vendor macro, which project name it collided with,
 * whether the collision was through the macro's name or its expansion, and the
 * category. Names are copied into the report's own storage so the report
 * outlives the tables it was built from. */
typedef struct CollisionReportEntry {
        char             *vendor_macro_name;
        char             *project_name;      /* the colliding project symbol */
        int               through_expansion; /* 0 = name collision, 1 = body */
        CollisionCategory category;
} CollisionReportEntry;

typedef struct CollisionReport {
        CollisionReportEntry *entries;
        size_t                entry_count;
        size_t                entry_capacity;
} CollisionReport;

/* ===========================================================================
 * [2] DETECTION
 * ===========================================================================*/

typedef enum CollisionDetectionResult {
        COLLISION_DETECTION_OK,
        COLLISION_DETECTION_OUT_OF_MEMORY
} CollisionDetectionResult;

/* ---------------------------------------------------------------------------
 *  Operation : collision_detection_run
 *
 *  Check every macro in the vendor table against project space, recording each
 *  collision with its category into a freshly initialized report.
 *
 *  For each vendor macro: the name is checked against the project identifier
 *  set and the project macro set; then each identifier token inside the macro's
 *  body is checked the same way (function-like parameter names are excluded, as
 *  they are local to the macro and cannot collide). A match against a
 *  whitelisted symbol is categorized WHITELISTED; a match against a project
 *  identifier is IDENTIFIER_CAPTURE; a match against a project macro is
 *  MACRO_SHADOW.
 *
 *  On success the caller owns the report and releases it with
 *  collision_report_release. On failure the report is left empty and released
 *  internally.
 *
 *  IN   vendor_table          VALID    CONSUME   ALWAYS      KEEP  NONE
 *  IN   project_identifier_set VALID   CONSUME   ALWAYS      KEEP  NONE
 *  IN   project_macro_set      VALID   CONSUME   ALWAYS      KEEP  NONE
 *  IN   whitelist              VALID   CONSUME   ALWAYS      KEEP  NONE
 *  OUT  report_out             GARBAGE POPULATE  IF_SUCCESS  KEEP  NONE
 * ---------------------------------------------------------------------------*/
CollisionDetectionResult collision_detection_run(
        const VendorMacroTable      *vendor_table,
        const SymbolSet             *project_identifier_set,
        const SymbolSet             *project_macro_set,
        const DeclaredCrossingTable *whitelist,
        CollisionReport             *report_out);

/* ---------------------------------------------------------------------------
 *  Operation : collision_report_release
 *
 *  Free a report and reset it to empty. Safe on an empty report.
 *
 *  IN  report  VALID  MUTATE  ALWAYS  GIVE  NONE  report to release
 * ---------------------------------------------------------------------------*/
void collision_report_release(CollisionReport *report);

#endif /* COLLISION_DETECTION_H */
