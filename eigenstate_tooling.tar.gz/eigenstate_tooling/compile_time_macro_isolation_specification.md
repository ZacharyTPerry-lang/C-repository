# Compile-Time Macro Isolation ("Blackwall") — Specification

**Formal module name:** `compile_time_macro_isolation`
**Informal name:** Blackwall (never used in structural/folder contexts)
**Version:** 0.3.0 (supersedes 0.1.0 / 0.2.0 — those predate the conventions and the proof foundation)
**Status:** Design complete and largely implemented. Fifteen production modules built and strict-clean. Remaining: the independent validation pass and Makefile 3-stage wiring.

---

## 0. Purpose and Placement

Blackwall is the transformation that sits **between human-readable project source and GCC**. It produces the `.intermediate/` tree that GCC compiles and that the static analyzer reads. Its single job is to make the boundary between project code and vendor code **explicit, deterministic, and enforced**, so that:

- a vendor macro cannot silently capture a project identifier;
- a symbol only crosses the boundary when the developer has sanctioned it, in a direction the developer chose;
- a reverse dependency (vendor code demanding a project symbol) is never bound silently;
- every one of these is decided by reading the compiler's own stage outputs, never by reasoning about source or guessing.

The transformation lives in exactly one gap in the build: **after preprocessing is resolvable but before compilation commits**. That is the only place where macros can be read as facts (the preprocessor has the values) and identifiers are still identifiers (not yet compiled away).

### Governing philosophy

> *Convenience is the abstraction of understanding.*

Abstraction exists only where technically necessary. The boundary is exposed, not hidden. Every decision the tool makes is traceable to a compiler stage output. No silent failure: an ambiguous or unsafe situation stops the build loudly rather than proceeding on a guess.

---

## 1. The Proof Foundation

Every design decision rests on empirically verified compiler behavior, not assertion. These six primitives were each tested against GCC/nm/ld directly.

- **P1 — Identifier capture is real.** A vendor `#define index vendor_internal_index` rewrites a project's `index` parameter at GCC preprocessing. Prefixing protects project *macros* but is powerless for project *identifiers* (which cannot be prefixed). This is the tool's reason to exist.

- **P2 — ODR divergence from per-TU state.** Selecting different macro states per translation unit produces one binary in which the same vendor inline was compiled at two different values, with the linker silent. **Therefore the State Gate is one build-wide choice**, never per-TU or per-vendor.

- **P3 — The linker fact.** Only file-scope external-linkage names cross translation-unit boundaries (nm `T`/`D`/`B`). Block-locals get local symbols; parameters and locals get none. Reverse-dependency resolution therefore needs only file-scope symbol facts, which `nm` computes soundly.

- **P4 — Completeness by inheritance.** `gcc -dM -E` on a vendor header resolves the vendor's own includes, so the macro set cannot miss an internal header the vendor includes itself.

- **P5 — The residual discriminator.** After full preprocessing, a token's presence or absence in the output reveals whether the vendor consumed a name internally. The macro layer is sound by dump; the identifier layer is confirmed by the compiler's actual output.

- **P6 — GCC internals are not a data source.** The AST dump is body-centric, lossy, and version-unstable. Blackwall consumes GCC **stage outputs** (`-E` text, `-dM`/`-dU` dumps, `nm` symbols) and never internal state. libclang is likewise verification-only, never a production dependency.

### Governing law

GCC is the single source of truth. "Which internal stage" is an implementation detail — preprocessor, parser, and linker are all "the compiler." Blackwall reads what the compiler *did*; it never predicts what the compiler *will do*.

---

## 2. The Boundary-Crossing Proof

Reverse-dependency detection uses **proof by complement**. Two assertions are exhaustive: either the vendor references a project symbol, or it needs nothing from the project. Only the second is tested:

```
U ∩ P = ∅
```

where **U** is the vendor object's undefined symbols (`nm -u`) and **P** is the project's defined-external symbols (`nm`). Empty intersection → prefix-and-isolate is safe. Non-empty → each symbol in the intersection **must** be whitelisted or the build errors.

There are no coincidental collisions at link scope: one global namespace means the same name *is* the same symbol, and the linker *will* bind it. The answer is therefore **computed** by the tool from compiler outputs, not **known** by inspecting vendor source.

**Soundness closure (three moves):**
1. Inherit macro completeness from the vendor's own includes (P4).
2. Demote any static scan to a conjecture the compiler's residual confirms (P5).
3. Force analysis configuration to equal build configuration, so there is one configuration to certify.

The failure mode is always safe: incompleteness inflates U, which forces "declare or error," which is a loud build failure — never a silent capture.

---

## 3. Collision Domain — "Literally Everything"

The standard is to guard against every collision that can occur. This is achieved not by enumerating cases hopefully, but by a two-layer check backed by a biconditional.

### 3.1 What a collision is

> A collision is when the preprocessor finds a symbol — that is not a reverse dependency — that will affect project code but originated from something the project did not author.

### 3.2 The vectors, and how each is covered

A vendor macro can collide through:

1. **Its name** — a vendor `index` capturing a project `index`. Checked: the macro name against project space.
2. **Its expansion** — a vendor macro expanding to a project symbol (`fast_path → project_helper`). Checked: each identifier in the expansion.
3. **Multi-token expansions** — `SETUP → int index; int count`. Checked: the expansion is tokenized, each identifier checked individually.
4. **Transitive chains** — `LAYER_ONE → LAYER_TWO → project_target`. Checked: the fully expanded form.
5. **Token pasting** — `project_ ## x`, which constructs a name not literally in the `#define`. See §3.3.
6. **Configuration-conditional macro sets** — handled by move 3 (analysis config == build config).

**Not collisions (must not be flagged — over-flagging is a defect):**
- Function-like macro **parameters** (placeholders replaced by the argument).
- **C keywords** appearing as identifier tokens (the lexer is deliberately keyword-free, so the keyword filter lives in the collision layer).
- Identifiers that appear only inside **string literals** (not expanded).

### 3.3 The token-paste biconditional

Token pasting appears to be a gap: `project_ ## x` constructs `project_helper` only when invoked with the argument `helper`, and the constructed token is not in the macro table. The resolution is a biconditional, proven against the compiler:

> A pasted collision exists in the compiled output **⟺** the macro fired **⟺** the invocation (with its argument) is present in what we compile **⟺** we tokenize it and see it.

A pasted token that is never constructed is a collision that never fires and cannot occur. Execution is complete where enumeration is not: the compiler produces exactly the tokens that really occur, which is precisely the set that matters. There is no gap.

This gives a **two-layer check**:
- **Static layer** (`collision_detection`): the vendor macro table under the build configuration — names, tokenized full expansions, `##` affix reasoning (§3.4). Gives specific diagnostics.
- **Post-preprocessing layer** (the validation pass, §6): tokenize the compiler's actual `-E` output. Catches every constructed token because by then it is a real token.

### 3.4 `##` affix reasoning (static, over-checking)

The static layer handles pasting without needing the invocation. A paste body `PREFIX ## x` can construct any project identifier that **starts with** `PREFIX`; `x ## SUFFIX` any that **ends with** `SUFFIX`. The tool prefix/suffix-matches each fixed (non-parameter) affix against the project identifier set. This is sound (no false negatives) and over-checking (may flag a paste that never fires, which the whitelist resolves). Parameter affixes are excluded — they are not fixed.

### 3.5 The three dispositions

Each detected collision is sorted:

| Disposition | Meaning | Response |
|---|---|---|
| **WHITELISTED** | Declared to cross under the State Gate | Permitted (handled per state) |
| **IDENTIFIER_CAPTURE** | Collides with a project identifier, not whitelisted | **Error** — prefixing cannot fix an identifier |
| **MACRO_SHADOW** | Collides with a project macro, not whitelisted | Informational — the prefix system resolves it |
| **CONSTRUCTED_CAPTURE** | A `##` paste could construct a project identifier | **Error** — same class as identifier capture |

Reverse dependencies are handled separately (§2), not sorted here.

### 3.6 Two identifier sources for two jobs

- **Reverse-dependency set (P):** from `nm` — linkage-scoped, correct for what crosses the link boundary.
- **Collision-detection identifier set:** from the **lexer** — source-scoped, every identifier token including parameters and locals like `index` that `nm` cannot see (P3).

Two jobs, two sources, each correct for its job.

---

## 4. The State Gate (Directional Control)

One build-wide state is selected by the developer (P2). It determines how **whitelisted** symbols cross the boundary. Non-whitelisted vendor macros never cross; that is the default and the common case.

### State A — Project Supersedes
Whitelisted symbols carry the **project's** value into vendor space. Vendor code compiles against the project's definition.

### State B — Vendor Supersedes
Whitelisted symbols carry the **vendor's** value into project space, under the project prefix. Project code reads the vendor value through the prefixed name and never touches the vendor header.

### State C — Full Isolation
No symbols cross. Project code uses only prefixed symbols; vendor code uses only its own. **Default and most common.**

The universal prefix is `COMPILE_TIME_ENFORCEMENT_FRAMEWORK_`.

### 4.1 Crossing modality (the axis separate from the state)

A crossing carries a modality that decides what an absent declaration means:

- **CHOSEN** — the developer selects it; absence falls to the default (full isolation). The three states are chosen crossings.
- **COMPELLED** — the toolchain proves it; absence is an **error**. A reverse dependency is compelled: the linker will bind it whether or not it was declared, so an undeclared instance stops the build.

"A dependency is a dependency" — it is not optional, not a fourth state, its own axis. The enforcement engine reads the modality and branches; adding a crossing kind is a data edit, not an engine change.

---

## 5. State A Safety — The Lazy Path Made Robust

State A supersedes a vendor macro by generating a wrapper that includes the vendor header, then `#undef`s the macro and redefines it to the project value. The developer does **not** hand-write guards; the transformation manufactures them.

**The hazard:** if the vendor uses the macro in its own declarations, those fixed the old value *before* the redefinition, so vendor code would see the old value and project code the new one — the same symbol with two values in one build (the ODR hazard of P2, reappearing).

**The safety condition:** auto-superseding is safe **iff the vendor does not use the macro itself**.

**Detection — sound, via the compiler, not by probing.** Whether the vendor uses a macro is read from **`gcc -dU`**, which lists every macro the preprocessor expanded or whose definedness it tested. A macro absent from `-dU` was defined but never used → safe. A macro present was used somehow → unsafe.

This was arrived at by falsifying weaker methods:
- A **source scan** for the macro name outside its `#define` misses **transitive** use (`#define SZ MACRO`; use `SZ`).
- A **grep for a sentinel value** in the output misses **`#if`** use (the value is consumed by the condition, never appears as a token).
- A **two-value diff** misses **`#if X == N`** use (both trial values fail the equality, outputs identical).
- **`-dU`** catches all of these, because the preprocessor genuinely read the macro and records it. It is not a probe that can miss an unknown predicate; it is the compiler's own accounting.

`-dU`'s only imperfection errs on the **safe** side (it may flag a macro named only in a string as used), which asks the developer to be explicit unnecessarily — never the silent false-safe that matters.

**Resulting behavior:**
- Vendor **define-only** → auto-generate the superseding wrapper; project value wins. The lazy path, covering the common case (a vendor exposing a constant).
- Vendor **self-uses** → **error** with `UNSAFE_SUPERSEDE`; the developer defines the override explicitly.

State B is always safe (it introduces a new prefixed name and changes nothing the vendor sees) and needs no such check.

---

## 6. Validation — An Independent Process

Validation and transformation must be **two distinct processes that share no logic.** If the validator asked the transformer what it did, a bug in the shared logic would pass both checks — the validator would inherit the transformer's blind spots. The validator must reach its verdict by an **independent route**: the compiler's actual output, checked against each state's **defined** behavior, not against the transformer's report.

**Mechanism (control/treatment, the compiler as oracle):** run the pipeline with and without the boundary and compare the compiler's output. The difference (or its absence) is observable from outside the compiler — which token provenance is not.

**The assertions:**
- For every state, the output must exhibit the state's *defined* behavior:
  - **State A:** the project value appears in vendor space.
  - **State B:** the vendor value appears in project space under the prefix.
  - **State C:** nothing crosses.
- A **miss** = the boundary changed something no collision was reported for → an undetected capture.
- An **overzealous** action = the boundary changed something with no collision, or claimed to act but did not.

This subsumes the rewriter self-verification: "no miss, no overzealous" is exactly what the with/without comparison detects when checked against the state spec. GCC and `nm` are the backstop — a wrong rename changes the symbol set and breaks linkage.

*Status: designed, not yet built. It is the next module, and it is built independently of the transformer by construction.*

---

## 7. Module Architecture

Leaf-to-orchestrator. Every module has a `.h` contract with five-term parameter annotations, a `.c`, and a unit test. All strict-clean under `-std=c99 -Wall -Wextra -Werror -pedantic`.

```
lexical_scanner/                     boundary-exact C99 tokenizer; single-byte
                                     punctuators (munch is the parser's job);
                                     total coverage; no grammar, no keywords
symbol_set_from_object/              nm -P wrapper → P and U sets; prefix/suffix
                                     affix queries; public builder for non-nm fill
parameter_contract_system/
  parameter_contract_vocabulary      the five axes as pure data (edit to extend)
  parameter_contract_recognizer      detection, zero hardcoded tokens
  parameter_contract_translator      strip annotation, emit axis 5 per build mode
boundary_crossing_system/
  boundary_crossing_vocabulary       crossing kinds + modality as data
  boundary_crossing_enforcement      whitelist parse + modality rule
  boundary_crossing_discovery        U ∩ P via nm → reverse dependencies
compile_time_token_rewriter/
  vendor_macro_table                 gcc -dM -E → name + expansion + fn-like
  project_macro_set                  project #define names (to prefix)
  project_identifier_set             every lexer identifier (catches parameters)
  collision_detection                three-way sort + ## affix reasoning
  compile_time_token_rewriter(.c/.h) orchestrator + CLI
compile_time_macro_isolation/
  state_crossing_generation          State A/B generation + gcc -dU safety gate
```

### Parameter-contract grammar (locked)

Five terms, always present, in order:

```
STATE  ACTION  CONTRACT  CONTROL  LAYER_TWO_DIAGNOSTIC
```

`NONE` is the explicit default for the fifth term. Axes 1–4 are compile-time documentation for analysis (stripped before GCC). Axis 5 drives runtime diagnostic instrumentation and compiles out entirely in release.

---

## 8. Build Integration (planned)

Three-stage build, root Makefile as the single authority:

```
1. transform : project source → .intermediate/   (Blackwall)
2. compile   : GCC from .intermediate/
3. analyze   : static analysis on .intermediate/
```

`.intermediate/` is a real tracked Make output, not `.PHONY`. Two symbol tables (project definitions, vendor headers). Two-pass macro handling: `gcc -dM -E` for vendor extraction, `-imacros`/generated wrappers for injection. All analysis runs under the same configuration as the compile (move 3).

The wiring is realized in `source_transformation_pipeline.makefile`:
`.intermediate/` is a tracked output (retained via `.SECONDARY`, created via
order-only prerequisites); the vendor macro table (`gcc -dM -E`) is a build-wide
prerequisite of every transform, so a vendor header change re-transforms all
sources while a single source change re-transforms only itself; `ISOLATION_STATE`
is validated inline against A/B/C. Verified end-to-end against the real rewriter
binary, with GCC compiling the transformed `.intermediate/` output as the oracle
(acceptance_test_pipeline.sh).

*Status: built and verified end-to-end.*

---

## 9. Invariants (never violated)

1. **One build-wide state.** Never per-TU, never per-vendor (P2).
2. **Vendor source is never edited.** Generated wrappers and prefixed headers do the work; the vendor header is included, never modified.
3. **Using a vendor is not a violation.** The include happens. An *unguarded* collision is the error.
4. **No silent failure.** Ambiguity or an unsafe supersede stops the build with a named cause.
5. **Every decision traces to a compiler stage output.** `-dM`, `-dU`, `-E`, `nm`. Never GCC internals, never a guess.
6. **Validation is independent of transformation.** No shared logic; the verdict comes from compiler output against the state spec.
7. **Determinism is non-negotiable.** Any tool that assumes code shape is disqualified from the production pipeline.

---

## Appendix: Failure-Mode Table

| Situation | Detection | Response |
|---|---|---|
| Vendor macro name captures project identifier | `collision_detection`, static layer | Error (IDENTIFIER_CAPTURE) |
| Vendor macro expansion hits project symbol | `collision_detection`, expansion scan | Error (IDENTIFIER_CAPTURE) |
| `##` paste could construct project identifier | `collision_detection`, affix match | Error (CONSTRUCTED_CAPTURE) |
| Vendor macro shadows project macro | `collision_detection` | Informational; prefix resolves |
| Vendor object demands project symbol | `boundary_crossing_discovery`, U ∩ P | Error unless whitelisted (COMPELLED) |
| State A supersede on vendor-used macro | `state_crossing_generation`, gcc -dU | Error (UNSAFE_SUPERSEDE) |
| Whitelist references unknown crossing kind | `boundary_crossing_enforcement` | Error (malformed whitelist) |
| Constructed token collides only at expansion | validation pass (post-preprocessing) | Caught in `-E` output |
```
