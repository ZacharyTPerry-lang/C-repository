/* Unit test for symbol_set_from_object. Compiles real object files at runtime,
 * extracts P and U sets, and checks them against the linkage facts the proof
 * relies on: comma-lists bind all names, function-pointer names are captured,
 * struct members and internal statics do not appear, undefined uses land in U. */

#include "symbol_set_from_object.h"
#include <stdio.h>
#include <stdlib.h>

static int failures = 0;

static void expect_present(const SymbolSet *set, const char *name,
                           const char *label)
{
        if (symbol_set_contains(set, name)) {
                printf("  pass [%s]: '%s' present\n", label, name);
        } else {
                printf("  FAIL [%s]: '%s' MISSING\n", label, name);
                failures++;
        }
}

static void expect_absent(const SymbolSet *set, const char *name,
                          const char *label)
{
        if (!symbol_set_contains(set, name)) {
                printf("  pass [%s]: '%s' absent\n", label, name);
        } else {
                printf("  FAIL [%s]: '%s' PRESENT (should be absent)\n",
                       label, name);
                failures++;
        }
}

int main(void)
{
        /* write a source file exercising the hard linkage cases */
        FILE *f = fopen("/tmp/sset_fixture.c", "w");
        if (!f) { printf("cannot write fixture\n"); return 2; }
        fputs(
                "int alpha, beta, gamma;\n"            /* comma list: 3 bindings */
                "int (*handler)(void);\n"              /* fn-ptr: name in parens */
                "struct { int member_field; } inst;\n" /* member vs instance */
                "static int internal_static;\n"        /* internal linkage */
                "int provide(unsigned long n){ return (int)n; }\n"
                "int demand(void){ extern int external_need(void);"
                "                  return external_need(); }\n",
                f);
        fclose(f);

        if (system("gcc -c /tmp/sset_fixture.c -o /tmp/sset_fixture.o 2>/dev/null")
            != 0) {
                printf("fixture failed to compile\n");
                return 2;
        }

        /* --- P set: defined external --- */
        printf("defined-external (P) set:\n");
        SymbolSet p_set;
        SymbolSetResult pr = symbol_set_extract_from_object(
                "/tmp/sset_fixture.o",
                SYMBOL_SET_SELECTOR_DEFINED_EXTERNAL, &p_set);
        if (pr != SYMBOL_SET_RESULT_OK) {
                printf("  FAIL: extraction returned %d\n", pr);
                return 1;
        }
        expect_present(&p_set, "alpha",   "comma-list");
        expect_present(&p_set, "beta",    "comma-list");
        expect_present(&p_set, "gamma",   "comma-list");
        expect_present(&p_set, "handler", "fn-ptr-name");
        expect_present(&p_set, "inst",    "struct-instance");
        expect_present(&p_set, "provide", "function");
        expect_absent(&p_set,  "member_field",    "member-not-binding");
        expect_absent(&p_set,  "internal_static", "internal-linkage");
        expect_absent(&p_set,  "external_need",   "undefined-not-in-P");
        symbol_set_release(&p_set);

        /* --- U set: undefined --- */
        printf("undefined (U) set:\n");
        SymbolSet u_set;
        SymbolSetResult ur = symbol_set_extract_from_object(
                "/tmp/sset_fixture.o",
                SYMBOL_SET_SELECTOR_UNDEFINED, &u_set);
        if (ur != SYMBOL_SET_RESULT_OK) {
                printf("  FAIL: extraction returned %d\n", ur);
                return 1;
        }
        expect_present(&u_set, "external_need", "undefined-use");
        expect_absent(&u_set,  "provide",       "defined-not-in-U");
        expect_absent(&u_set,  "alpha",         "defined-not-in-U");
        symbol_set_release(&u_set);

        /* --- error path: nonexistent object --- */
        printf("error path:\n");
        SymbolSet junk;
        SymbolSetResult er = symbol_set_extract_from_object(
                "/tmp/does_not_exist_zzz.o",
                SYMBOL_SET_SELECTOR_DEFINED_EXTERNAL, &junk);
        if (er == SYMBOL_SET_RESULT_TOOL_FAILED) {
                printf("  pass [missing-object]: reported TOOL_FAILED\n");
        } else {
                printf("  FAIL [missing-object]: got %d, expected TOOL_FAILED\n", er);
                failures++;
        }

        if (failures == 0) {
                printf("ALL SYMBOL-SET TESTS PASS\n");
                return 0;
        }
        printf("%d SYMBOL-SET TEST(S) FAILED\n", failures);
        return 1;
}
