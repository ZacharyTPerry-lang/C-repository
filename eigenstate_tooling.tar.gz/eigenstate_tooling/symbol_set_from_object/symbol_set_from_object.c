/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * symbol_set_from_object.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : symbol_set_from_object
 *
 * Purpose       : Implementation of the object-file symbol set extractor. Runs
 *                 nm -P, parses the POSIX portable output, and builds a sorted,
 *                 queryable name set.
 *
 * Portability   : C99 plus POSIX (popen for the nm pipe). Everything except the
 *                 extraction call is pure C99.
 *
 * Table of contents:
 *   [1] SET GROWTH
 *   [2] SET SORT AND QUERY
 *   [3] NM OUTPUT PARSING
 *   [4] PUBLIC OPERATIONS
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

/* popen and pclose are POSIX, not ISO C. This module is documented as C99 plus
 * POSIX process control; requesting the POSIX.1-2001 feature level exposes them
 * while the rest of the file remains strict C99. This must precede every
 * include, since the first system header pulled in fixes the feature level. */
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200112L
#endif

#include "symbol_set_from_object.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===========================================================================
 * [1] SET GROWTH
 * ===========================================================================
 *
 *  A set is grown by appending names. Each append copies the name into the
 *  contiguous storage block and records its offset. Both the storage block and
 *  the offset index grow geometrically so that building a set of N names is
 *  amortized linear.
 *
 * ===========================================================================*/

static void symbol_set_initialize_empty(SymbolSet *symbol_set)
{
        symbol_set->name_storage        = NULL;
        symbol_set->name_storage_length = 0;
        symbol_set->name_offsets        = NULL;
        symbol_set->name_count          = 0;
        symbol_set->storage_capacity    = 0;
        symbol_set->offset_capacity     = 0;
}

/* Returns nonzero on success, zero on allocation failure. */
static int symbol_set_append_name(SymbolSet  *symbol_set,
                                  const char *name,
                                  size_t      name_length)
{
        size_t needed_storage = symbol_set->name_storage_length
                              + name_length + 1;
        if (needed_storage > symbol_set->storage_capacity) {
                size_t new_capacity = symbol_set->storage_capacity == 0
                                    ? 256 : symbol_set->storage_capacity * 2;
                while (new_capacity < needed_storage) {
                        new_capacity *= 2;
                }
                char *grown = realloc(symbol_set->name_storage, new_capacity);
                if (grown == NULL) {
                        return 0;
                }
                symbol_set->name_storage     = grown;
                symbol_set->storage_capacity = new_capacity;
        }

        if (symbol_set->name_count + 1 > symbol_set->offset_capacity) {
                size_t new_capacity = symbol_set->offset_capacity == 0
                                    ? 32 : symbol_set->offset_capacity * 2;
                size_t *grown = realloc(symbol_set->name_offsets,
                                        new_capacity * sizeof(size_t));
                if (grown == NULL) {
                        return 0;
                }
                symbol_set->name_offsets    = grown;
                symbol_set->offset_capacity = new_capacity;
        }

        symbol_set->name_offsets[symbol_set->name_count] =
                symbol_set->name_storage_length;
        memcpy(symbol_set->name_storage + symbol_set->name_storage_length,
               name, name_length);
        symbol_set->name_storage[symbol_set->name_storage_length + name_length]
                = '\0';
        symbol_set->name_storage_length += name_length + 1;
        symbol_set->name_count          += 1;
        return 1;
}

/* ===========================================================================
 * [2] SET SORT AND QUERY
 * ===========================================================================*/

static const char *symbol_set_name_by_offset(const SymbolSet *symbol_set,
                                              size_t           offset)
{
        return symbol_set->name_storage + offset;
}

/* qsort comparator over offsets, comparing the names they point at. The
 * comparison base is passed through a file-scope pointer because C89/C99 qsort
 * gives the comparator no user context; the pointer is set immediately before
 * qsort and used only during the sort, which is single-threaded here. */
static const SymbolSet *symbol_set_sort_context = NULL;

static int symbol_set_offset_compare(const void *left, const void *right)
{
        size_t left_offset  = *(const size_t *)left;
        size_t right_offset = *(const size_t *)right;
        return strcmp(
                symbol_set_name_by_offset(symbol_set_sort_context, left_offset),
                symbol_set_name_by_offset(symbol_set_sort_context, right_offset));
}

static void symbol_set_sort(SymbolSet *symbol_set)
{
        symbol_set_sort_context = symbol_set;
        qsort(symbol_set->name_offsets, symbol_set->name_count,
              sizeof(size_t), symbol_set_offset_compare);
        symbol_set_sort_context = NULL;
}

int symbol_set_contains(const SymbolSet *symbol_set, const char *name)
{
        size_t low  = 0;
        size_t high = symbol_set->name_count;
        while (low < high) {
                size_t mid = low + (high - low) / 2;
                const char *mid_name = symbol_set_name_by_offset(
                        symbol_set, symbol_set->name_offsets[mid]);
                int comparison = strcmp(name, mid_name);
                if (comparison == 0) {
                        return 1;
                }
                if (comparison < 0) {
                        high = mid;
                } else {
                        low = mid + 1;
                }
        }
        return 0;
}

const char *symbol_set_name_at(const SymbolSet *symbol_set, size_t index)
{
        if (index >= symbol_set->name_count) {
                return NULL;
        }
        return symbol_set_name_by_offset(symbol_set,
                                         symbol_set->name_offsets[index]);
}

int symbol_set_any_starts_with(const SymbolSet *symbol_set, const char *affix)
{
        size_t affix_length = strlen(affix);
        if (affix_length == 0) {
                return 0;
        }
        /* the set is sorted; binary search for the first name >= affix, then
         * check whether it begins with the affix. strncmp against the affix
         * length gives prefix comparison. */
        size_t low  = 0;
        size_t high = symbol_set->name_count;
        while (low < high) {
                size_t mid = low + (high - low) / 2;
                const char *mid_name = symbol_set_name_by_offset(
                        symbol_set, symbol_set->name_offsets[mid]);
                if (strncmp(mid_name, affix, affix_length) < 0) {
                        low = mid + 1;
                } else {
                        high = mid;
                }
        }
        if (low < symbol_set->name_count) {
                const char *candidate = symbol_set_name_by_offset(
                        symbol_set, symbol_set->name_offsets[low]);
                if (strncmp(candidate, affix, affix_length) == 0) {
                        return 1;
                }
        }
        return 0;
}

int symbol_set_any_ends_with(const SymbolSet *symbol_set, const char *affix)
{
        size_t affix_length = strlen(affix);
        if (affix_length == 0) {
                return 0;
        }
        /* suffix is not aligned with the sort order, so this is a linear scan.
         * paste suffixes are rare, so the cost is acceptable. */
        size_t index;
        for (index = 0; index < symbol_set->name_count; index++) {
                const char *name = symbol_set_name_by_offset(
                        symbol_set, symbol_set->name_offsets[index]);
                size_t name_length = strlen(name);
                if (name_length >= affix_length
                    && strcmp(name + name_length - affix_length, affix) == 0) {
                        return 1;
                }
        }
        return 0;
}

/* ===========================================================================
 * [3] NM OUTPUT PARSING
 * ===========================================================================
 *
 *  nm -P emits one symbol per line in POSIX portable format:
 *
 *      name type [value] [size]
 *
 *  The name is first, followed by whitespace and a single type character. For
 *  the two sets this module extracts, the type character alone decides
 *  inclusion: uppercase means defined with external linkage, 'U' means
 *  undefined. A line that does not present a name and a single type character
 *  is malformed and fails the extraction rather than being skipped, so a
 *  change in nm output cannot silently thin a set and weaken the boundary.
 *
 * ===========================================================================*/

/* Returns nonzero if the type character selects a symbol for the requested
 * set. */
static int gate_type_matches_selector(char type_character,
                                      SymbolSetSelector selector)
{
        if (selector == SYMBOL_SET_SELECTOR_UNDEFINED) {
                return type_character == 'U';
        }
        /* DEFINED_EXTERNAL: any uppercase type other than U. U is undefined,
         * not defined-external, and is excluded here. Uppercase is the nm
         * convention for external linkage; lowercase is internal linkage and
         * never crosses. */
        return type_character >= 'A' && type_character <= 'Z'
            && type_character != 'U';
}

/* Parse one nm -P line into (name, type). Returns nonzero on a well-formed
 * line, zero if the line is malformed. name_out points into the line buffer. */
static int parse_nm_line(char  *line,
                         char **name_out,
                         char  *type_out)
{
        char *cursor = line;

        /* strip trailing newline */
        size_t length = strlen(cursor);
        while (length > 0 && (cursor[length - 1] == '\n'
                           || cursor[length - 1] == '\r')) {
                cursor[--length] = '\0';
        }
        if (length == 0) {
                return 0;
        }

        /* name is the leading run of non-space characters */
        *name_out = cursor;
        while (*cursor != '\0' && *cursor != ' ' && *cursor != '\t') {
                cursor++;
        }
        if (*cursor == '\0') {
                return 0; /* no type field */
        }
        *cursor = '\0';
        cursor++;

        /* skip whitespace to the type character */
        while (*cursor == ' ' || *cursor == '\t') {
                cursor++;
        }
        if (*cursor == '\0') {
                return 0; /* no type character */
        }

        /* the type field must be a single character followed by end or space */
        *type_out = *cursor;
        char following = *(cursor + 1);
        if (following != '\0' && following != ' ' && following != '\t') {
                return 0; /* multi-character type field: not POSIX -P */
        }
        return 1;
}

/* ===========================================================================
 * [4] PUBLIC OPERATIONS
 * ===========================================================================*/

/* Build the nm command. The object path is placed after "--" so a path that
 * begins with '-' is not read as an option. The path is the caller's; it is
 * not sanitized here because the caller is the build system, not untrusted
 * input, and quoting is handled by passing through the shell exactly once. */
static int build_nm_command(const char *object_file_path,
                            char       *command_buffer,
                            size_t      command_buffer_size)
{
        int written = snprintf(command_buffer, command_buffer_size,
                               "nm -P -- '%s'", object_file_path);
        return written > 0 && (size_t)written < command_buffer_size;
}

SymbolSetResult symbol_set_extract_from_object(const char        *object_file_path,
                                               SymbolSetSelector  selector,
                                               SymbolSet         *symbol_set_out)
{
        symbol_set_initialize_empty(symbol_set_out);

        char command_buffer[4096];
        if (!build_nm_command(object_file_path, command_buffer,
                              sizeof(command_buffer))) {
                return SYMBOL_SET_RESULT_TOOL_FAILED;
        }

        FILE *nm_pipe = popen(command_buffer, "r");
        if (nm_pipe == NULL) {
                return SYMBOL_SET_RESULT_TOOL_FAILED;
        }

        char            line_buffer[8192];
        SymbolSetResult result = SYMBOL_SET_RESULT_OK;
        while (fgets(line_buffer, sizeof(line_buffer), nm_pipe) != NULL) {
                char *name;
                char  type_character;
                if (!parse_nm_line(line_buffer, &name, &type_character)) {
                        result = SYMBOL_SET_RESULT_MALFORMED_OUTPUT;
                        break;
                }
                if (gate_type_matches_selector(type_character, selector)) {
                        if (!symbol_set_append_name(symbol_set_out, name,
                                                    strlen(name))) {
                                result = SYMBOL_SET_RESULT_OUT_OF_MEMORY;
                                break;
                        }
                }
        }

        int close_status = pclose(nm_pipe);
        if (result == SYMBOL_SET_RESULT_OK && close_status != 0) {
                result = SYMBOL_SET_RESULT_TOOL_FAILED;
        }

        if (result != SYMBOL_SET_RESULT_OK) {
                symbol_set_release(symbol_set_out);
                return result;
        }

        symbol_set_sort(symbol_set_out);
        return SYMBOL_SET_RESULT_OK;
}

void symbol_set_release(SymbolSet *symbol_set)
{
        free(symbol_set->name_storage);
        free(symbol_set->name_offsets);
        symbol_set_initialize_empty(symbol_set);
}

/* ===========================================================================
 * DIRECT CONSTRUCTION
 * ===========================================================================
 *
 *  Thin public wrappers over the internal growth and sort used by extraction,
 *  so a set can be built from names a caller already holds.
 *
 * ===========================================================================*/

void symbol_set_begin(SymbolSet *symbol_set)
{
        symbol_set_initialize_empty(symbol_set);
}

int symbol_set_add_name(SymbolSet  *symbol_set,
                        const char *name,
                        size_t      name_length)
{
        return symbol_set_append_name(symbol_set, name, name_length);
}

void symbol_set_finalize(SymbolSet *symbol_set)
{
        symbol_set_sort(symbol_set);
}
