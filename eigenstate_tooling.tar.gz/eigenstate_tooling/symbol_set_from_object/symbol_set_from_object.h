/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * symbol_set_from_object.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : symbol_set_from_object (leaf; depends only on the toolchain)
 *
 * Purpose       : Extract, from a compiled object file, the two symbol sets the
 *                 boundary proof rests on:
 *
 *                   the DEFINED-EXTERNAL set : names this object binds with
 *                     external linkage. For project objects this is the set P
 *                     -- every project symbol a vendor could resolve against.
 *
 *                   the UNDEFINED set : names this object references but does
 *                     not define -- unbound uses that must be satisfied from
 *                     outside. For vendor objects this is the set U -- every
 *                     symbol the vendor demands, including any it demands from
 *                     project code.
 *
 * Why nm        : whether a name crosses the link boundary is a linkage
 *                 property, and the linker's symbol table is the authority on
 *                 linkage. Computing these sets by parsing C source would mean
 *                 re-deriving, fallibly, what the toolchain already computes
 *                 exactly: a comma-separated declaration binds several names, a
 *                 function-pointer declarator hides its name in parentheses, a
 *                 struct member is not a binding, an internal-linkage static
 *                 does not cross. The symbol table gets every one of these
 *                 right by construction. This module therefore consumes a
 *                 toolchain STAGE OUTPUT (the symbol table, via nm -P) rather
 *                 than reasoning about source. It never parses C.
 *
 * Boundary      : this module runs nm and parses its POSIX output. It does not
 *                 decide what the sets MEAN -- intersection against the
 *                 whitelist, and the declared-or-error rule, belong to the
 *                 boundary_crossing modules. This module answers only "what
 *                 does this object bind, and what does it demand."
 *
 * Portability   : C99 plus POSIX process control (the nm invocation). The set
 *                 storage itself is freestanding-compatible; only the
 *                 population step shells out. nm -P is the POSIX-specified
 *                 portable output format: one symbol per line, name first, then
 *                 a single type character, stable across nm implementations.
 *
 * Table of contents:
 *   [1] SYMBOL SET
 *   [2] SET QUERY
 *   [3] EXTRACTION
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef SYMBOL_SET_FROM_OBJECT_H
#define SYMBOL_SET_FROM_OBJECT_H

#include <stddef.h>

/* ===========================================================================
 * [1] SYMBOL SET
 * ===========================================================================
 *
 *  An ordered set of symbol names. Names are stored as a single contiguous
 *  block of NUL-terminated strings with an index of offsets, so the whole set
 *  is two allocations regardless of symbol count and a name lookup is a
 *  binary search over the sorted index.
 *
 *  The caller creates a set, hands it to an extraction call to populate, then
 *  queries it. The set owns its storage and is released with
 *  symbol_set_release.
 *
 * ---------------------------------------------------------------------------
 *  name_storage        contiguous block of NUL-terminated names
 *  name_storage_length bytes used in name_storage
 *  name_offsets        sorted offsets into name_storage, one per name
 *  name_count          number of names
 *  storage_capacity    allocated bytes of name_storage
 *  offset_capacity     allocated entries of name_offsets
 * ---------------------------------------------------------------------------*/

typedef struct SymbolSet {
        char   *name_storage;
        size_t  name_storage_length;
        size_t *name_offsets;
        size_t  name_count;
        size_t  storage_capacity;
        size_t  offset_capacity;
} SymbolSet;

/* Which symbols an extraction should collect from an object. The two sets the
 * proof needs are requested by these selectors; they map to the linker symbol
 * classes, not to any source-level notion. */
typedef enum SymbolSetSelector {
        /* Names defined in this object with external linkage: nm -P type
         * character is uppercase (T, D, B, C, R, G, ...). This is P. */
        SYMBOL_SET_SELECTOR_DEFINED_EXTERNAL,

        /* Names referenced but undefined in this object: nm -P type character
         * is 'U'. This is U. */
        SYMBOL_SET_SELECTOR_UNDEFINED
} SymbolSetSelector;

/* ===========================================================================
 * [2] SET QUERY
 * ===========================================================================*/

/* ---------------------------------------------------------------------------
 *  Operation : symbol_set_contains
 *
 *  Report whether a name is present in the set. Binary search over the sorted
 *  index; the set is not modified.
 *
 *  Returns nonzero if present, zero if absent.
 *
 *  IN  symbol_set   VALID  CONSUME  ALWAYS  KEEP  NONE  the set to search
 *  IN  name         VALID  CONSUME  ALWAYS  KEEP  NONE  NUL-terminated name
 * ---------------------------------------------------------------------------*/
int symbol_set_contains(const SymbolSet *symbol_set, const char *name);

/* ---------------------------------------------------------------------------
 *  Operation : symbol_set_name_at
 *
 *  Return the name at a given index in sorted order, or NULL if the index is
 *  out of range. Lets a caller enumerate the set, e.g. to compute an
 *  intersection by walking one set and testing membership in another.
 *
 *  IN  symbol_set   VALID  CONSUME  ALWAYS  KEEP  NONE  the set
 *  IN  index        VALID  CONSUME  ALWAYS  NONE  NONE  position in sort order
 * ---------------------------------------------------------------------------*/
const char *symbol_set_name_at(const SymbolSet *symbol_set, size_t index);

/* ---------------------------------------------------------------------------
 *  Operation : symbol_set_any_starts_with / symbol_set_any_ends_with
 *
 *  Report whether any name in the set begins with (respectively ends with) the
 *  given affix. Used to decide whether a token-paste affix could construct a
 *  member of the set: a paste "PREFIX ## arg" can build any name that starts
 *  with PREFIX; "arg ## SUFFIX" any name that ends with SUFFIX. An empty affix
 *  matches nothing. The set is not modified.
 *
 *  IN  symbol_set  VALID  CONSUME  ALWAYS  KEEP  NONE  the set
 *  IN  affix       VALID  CONSUME  ALWAYS  KEEP  NONE  NUL-terminated affix
 * ---------------------------------------------------------------------------*/
int symbol_set_any_starts_with(const SymbolSet *symbol_set, const char *affix);
int symbol_set_any_ends_with(const SymbolSet *symbol_set, const char *affix);

/* ===========================================================================
 * [3] EXTRACTION
 * ===========================================================================*/

/* Result of an extraction. Distinguishes a clean run from the ways it can
 * fail, so the caller can report the exact cause rather than a generic
 * failure. */
typedef enum SymbolSetResult {
        SYMBOL_SET_RESULT_OK,

        /* nm could not be run, or exited nonzero (missing object, unreadable
         * file, nm not on PATH). */
        SYMBOL_SET_RESULT_TOOL_FAILED,

        /* A memory allocation failed while building the set. */
        SYMBOL_SET_RESULT_OUT_OF_MEMORY,

        /* nm produced output that did not match the POSIX -P line format. This
         * is treated as a hard failure rather than skipped, so a change in nm
         * output does not silently drop symbols and weaken the boundary. */
        SYMBOL_SET_RESULT_MALFORMED_OUTPUT
} SymbolSetResult;

/* ---------------------------------------------------------------------------
 *  Operation : symbol_set_extract_from_object
 *
 *  Run nm on one object file, collect the names matching the selector into a
 *  freshly initialized set, and sort them for query. The set is fully owned by
 *  the caller on success and must be released with symbol_set_release.
 *
 *  On any non-OK result the set is left empty and released internally; the
 *  caller must not release it again.
 *
 *  Remark : the object must already be compiled. This module does not compile;
 *  it reads the symbol table of an object the build produced. For project P
 *  the caller passes project objects with SYMBOL_SET_SELECTOR_DEFINED_EXTERNAL;
 *  for vendor U the caller passes vendor objects with
 *  SYMBOL_SET_SELECTOR_UNDEFINED.
 *
 *  IN   object_file_path  VALID    CONSUME   ALWAYS      KEEP  NONE  path to a
 *                                                                    .o file
 *  IN   selector          VALID    CONSUME   ALWAYS      NONE  NONE  which set
 *  OUT  symbol_set_out    GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE  the set
 * ---------------------------------------------------------------------------*/
SymbolSetResult symbol_set_extract_from_object(const char        *object_file_path,
                                               SymbolSetSelector  selector,
                                               SymbolSet         *symbol_set_out);

/* ---------------------------------------------------------------------------
 *  Operation : symbol_set_release
 *
 *  Free a set's storage and reset it to empty. Safe to call on an
 *  already-empty set.
 *
 *  IN  symbol_set  VALID  MUTATE  ALWAYS  GIVE  NONE  set to release
 * ---------------------------------------------------------------------------*/
void symbol_set_release(SymbolSet *symbol_set);

/* ===========================================================================
 * [4] DIRECT CONSTRUCTION
 * ===========================================================================
 *
 *  Extraction from an object is one way to fill a set; some callers build a set
 *  from names they already hold (for example macro names scanned from source).
 *  These operations expose the set's growth and finalization so a set can be
 *  populated without an object file, using the same sorted storage.
 *
 *  Usage : initialize an empty set, add each name, then finalize once. After
 *  finalize the set is sorted and queryable with symbol_set_contains. Add and
 *  finalize must not be interleaved with queries.
 *
 * ===========================================================================*/

/* Initialize a set to empty, ready for symbol_set_add_name. */
void symbol_set_begin(SymbolSet *symbol_set);

/* Append one name (by pointer and length, not necessarily NUL-terminated).
 * Returns nonzero on success, zero on allocation failure. Duplicates are
 * permitted here and collapse harmlessly under query; the caller need not
 * de-duplicate. */
int symbol_set_add_name(SymbolSet    *symbol_set,
                        const char   *name,
                        size_t        name_length);

/* Sort the set for query. Call once after all names are added. */
void symbol_set_finalize(SymbolSet *symbol_set);

#endif /* SYMBOL_SET_FROM_OBJECT_H */
