#!/bin/sh
# Build and test the compile_time_token_rewriter tree.
# All modules compile under strict flags; no module depends on a build system
# beyond this script (the real project uses GNU Make; this is a portable check).
set -e
STRICT="-std=c99 -Wall -Wextra -Werror -pedantic"
INC="-Ilexical_scanner -Isymbol_set_from_object -Iparameter_contract_system -Iboundary_crossing_system -Icompile_time_token_rewriter"

echo "=== building orchestrator binary ==="
gcc $STRICT $INC \
    lexical_scanner/lexical_scanner.c \
    symbol_set_from_object/symbol_set_from_object.c \
    parameter_contract_system/parameter_contract_vocabulary.c \
    parameter_contract_system/parameter_contract_recognizer.c \
    parameter_contract_system/parameter_contract_translator.c \
    boundary_crossing_system/boundary_crossing_vocabulary.c \
    boundary_crossing_system/boundary_crossing_enforcement.c \
    boundary_crossing_system/boundary_crossing_discovery.c \
    compile_time_token_rewriter/project_macro_set.c \
    compile_time_token_rewriter/project_identifier_set.c \
    compile_time_token_rewriter/vendor_macro_table.c \
    compile_time_token_rewriter/collision_detection.c \
    compile_time_token_rewriter/compile_time_token_rewriter.c \
    compile_time_token_rewriter/compile_time_token_rewriter_main.c \
    -o compile_time_token_rewriter_binary
echo "  built: ./compile_time_token_rewriter"

echo "=== unit tests ==="
gcc $STRICT -Ilexical_scanner lexical_scanner/lexical_scanner.c lexical_scanner/lexical_scanner_test.c -o /tmp/t && /tmp/t | tail -1
gcc $STRICT -Isymbol_set_from_object symbol_set_from_object/symbol_set_from_object.c symbol_set_from_object/symbol_set_from_object_test.c -o /tmp/t && /tmp/t | tail -1
gcc $STRICT -Iparameter_contract_system -Ilexical_scanner parameter_contract_system/parameter_contract_vocabulary.c parameter_contract_system/parameter_contract_recognizer.c parameter_contract_system/parameter_contract_recognizer_test.c lexical_scanner/lexical_scanner.c -o /tmp/t && /tmp/t | tail -1
gcc $STRICT -Iboundary_crossing_system boundary_crossing_system/boundary_crossing_vocabulary.c boundary_crossing_system/boundary_crossing_enforcement.c boundary_crossing_system/boundary_crossing_enforcement_test.c -o /tmp/t && /tmp/t | tail -1
gcc $STRICT -Icompile_time_macro_isolation compile_time_macro_isolation/state_crossing_generation.c compile_time_macro_isolation/state_crossing_generation_test.c -o /tmp/t && /tmp/t | tail -1
gcc $STRICT -Icompile_time_macro_isolation compile_time_macro_isolation/state_validation.c compile_time_macro_isolation/state_validation_test.c -o /tmp/t && /tmp/t | tail -1
gcc $STRICT -Icompile_time_token_rewriter -Ilexical_scanner -Isymbol_set_from_object -Iboundary_crossing_system compile_time_token_rewriter/collision_detection.c compile_time_token_rewriter/vendor_macro_table.c compile_time_token_rewriter/project_identifier_set.c compile_time_token_rewriter/project_macro_set.c boundary_crossing_system/boundary_crossing_vocabulary.c boundary_crossing_system/boundary_crossing_enforcement.c symbol_set_from_object/symbol_set_from_object.c lexical_scanner/lexical_scanner.c compile_time_token_rewriter/paste_detection_test.c -o /tmp/t && /tmp/t | tail -1

echo "=== acceptance tests (GCC/nm oracle) ==="
export COMPILE_TIME_TOKEN_REWRITER="$(pwd)/compile_time_token_rewriter_binary"
sh acceptance/acceptance_test_collision_prevention.sh | grep RESULT
sh acceptance/acceptance_test_reverse_dependency.sh | grep RESULT
sh acceptance/acceptance_test_pipeline.sh | grep RESULT
