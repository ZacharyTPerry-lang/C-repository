# compile_time_token_rewriter — module tree

The transformation between human-readable project source and GCC. Detects and
sorts vendor/project macro collisions, enforces reverse dependencies, prefixes
project macros, strips parameter-contract annotations. Consumes GCC/nm stage
outputs; never parses C itself; never depends on compiler internals.

## Modules (leaf → orchestrator)

lexical_scanner/
  Boundary-exact C99 tokenizer. Single-byte punctuators (munch is the parser's
  job). Total-coverage guarantee. No grammar, no keyword knowledge.

symbol_set_from_object/
  nm -P wrapper. Extracts P (defined-external) and U (undefined) symbol sets.
  Sound where a hand parser is not: comma-lists, function-pointer names,
  members excluded, internal linkage excluded. Also a public builder for
  non-nm population.

parameter_contract_system/
  parameter_contract_vocabulary  — the 5 axes as pure data (STATE ACTION
    CONTRACT CONTROL LAYER_TWO_DIAGNOSTIC). Edit this to add a term.
  parameter_contract_recognizer  — detects an annotation by walking the
    vocabulary. Zero hardcoded tokens (extensibility proven by test).
  parameter_contract_translator  — strips a matched annotation; emits axis 5
    per build mode (RELEASE drops, DEBUG keeps).

boundary_crossing_system/
  boundary_crossing_vocabulary   — crossing kinds as data with modality
    (CHOSEN vs COMPELLED) and discovery mechanism.
  boundary_crossing_enforcement  — whitelist parser + modality rule
    (chosen-absent → default, compelled-absent → error).
  boundary_crossing_discovery    — U ∩ P via nm; the reverse-dependency set.

compile_time_macro_isolation/
  state_crossing_generation — State A/B value crossing. -dU safety gate: auto-
    guards define-only vendor macros (project value wins), errors on vendor
    self-use (would split the value). The "lazy path" made robust.
  state_validation          — INDEPENDENT verification. Asserts each state's
    defined behavior from the compiler's actual output (gcc -E) against the
    vendor's own -dM value. Shares NO logic with the transformer; catches
    misses and overzealous action. State A/B/C each checked; violations
    detected, not just successes confirmed.

compile_time_token_rewriter/
  vendor_macro_table       — gcc -dM -E capture: name + expansion + fn-like.
  project_macro_set        — project #define names (to prefix).
  project_identifier_set   — every lexer identifier (source-scoped; catches
    parameters like `index` that nm cannot see).
  collision_detection      — the three-way sort. Checks vendor macro NAME and
    each EXPANSION token against project space. Keyword filter + fn-like
    parameter exclusion. Categories: WHITELISTED / IDENTIFIER_CAPTURE /
    MACRO_SHADOW.
  compile_time_token_rewriter(.c/.h) + _main.c — orchestrator + CLI.
    Job 2: reverse-dependency enforcement. Job 1a: collision guard. Job 1b:
    translate (prefix macros, strip annotations).

acceptance/
  Two endstate tests validated against GCC and nm (pass = compiler's verdict).
  collision_prevention: unguarded capture refused+named; whitelisted permitted.
  reverse_dependency:   undeclared errors+names symbol; declared accepted.

source_transformation_pipeline.makefile — the three-stage build fragment
  (transform -> GCC from .intermediate/ -> analysis on .intermediate/).
  .intermediate/ is a tracked output (.SECONDARY, order-only dir prereqs);
  vendor macro table is a build-wide prerequisite so a vendor change
  re-transforms all, a source change only itself. Verified end-to-end against
  the real rewriter binary. ISOLATION_STATE validated inline (A/B/C).

acceptance/acceptance_test_pipeline.sh — end-to-end: real tool drives the real
  Makefile; GCC compiling the transformed output is the oracle.

build_and_test.sh — portable strict-flag build + full test run.

## Status
16 production modules, all strict-clean (-std=c99 -Wall -Wextra -Werror
-pedantic). Unit suites + 2 acceptance tests green. See
compile_time_macro_isolation_specification.md for the full design.

collision_detection now includes ## token-paste affix reasoning
(CONSTRUCTED_CAPTURE) in addition to name/expansion/multi-token collision.

## Built and verified end-to-end
- The three-stage Makefile pipeline, driven by the real rewriter binary,
  producing output GCC compiles cleanly. This closes the end-to-end path:
  the tool is now runnable in a build.

## Bugs the real-binary integration surfaced (fixed)
- Rewriter --output is a directory (writes <dir>/<basename>); the Makefile now
  passes the directory rather than a per-file path.
- The transform prefixed macro USES but not the macro DEFINITION (the lexer
  emits #define directives as opaque tokens, so the identifier path never saw
  the defined name). The transform now prefixes the name inside a #define
  directive too, keeping definition and uses in step. The lexer stays pure
  (no directive grammar in the leaf); the transform, which already parses
  directive tokens to collect the macro set, handles the rename symmetrically.

## Completed since last checkpoint
- state_validation: the independent validation pass. Proven independent before
  building (all three states validate from gcc output + spec alone). Catches
  wrong State B values and failed State A supersedes, not just successes.

## Completed the checkpoint before
- State A/B value-crossing generation with the gcc -dU safety discriminator.
- ## token-paste collision detection (CONSTRUCTED_CAPTURE category).
