/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * lexical_scanner.c
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : lexical_scanner (leaf module, no project dependencies)
 *
 * Purpose       : Implementation of the boundary-exact C99 tokenizer declared
 *                 in lexical_scanner.h. Classifies each byte range and never
 *                 transforms it.
 *
 * Portability   : C99. Depends only on the paired header and the freestanding
 *                 headers it includes. No allocation, no I/O, no locale.
 *
 * Table of contents:
 *   [1] BYTE CLASSIFICATION PREDICATES
 *   [2] TOKEN SCANNERS (one per category)
 *   [3] PUBLIC OPERATIONS
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#include "lexical_scanner.h"

/* ===========================================================================
 * [1] BYTE CLASSIFICATION PREDICATES
 * ===========================================================================
 *
 *  Locale-independent classification of a single byte per the C99 source
 *  character set. The standard library ctype functions are locale-sensitive
 *  and are deliberately not used; the scanner must classify identically
 *  regardless of the environment it runs in, because determinism is the
 *  property the whole tool is built to preserve.
 *
 * ===========================================================================*/

static int gate_byte_is_identifier_start(uint8_t byte_value)
{
        return (byte_value >= 'A' && byte_value <= 'Z')
            || (byte_value >= 'a' && byte_value <= 'z')
            ||  byte_value == '_';
}

static int gate_byte_is_identifier_continue(uint8_t byte_value)
{
        return gate_byte_is_identifier_start(byte_value)
            || (byte_value >= '0' && byte_value <= '9');
}

static int gate_byte_is_digit(uint8_t byte_value)
{
        return byte_value >= '0' && byte_value <= '9';
}

static int gate_byte_is_horizontal_or_vertical_space(uint8_t byte_value)
{
        return byte_value == ' '
            || byte_value == '\t'
            || byte_value == '\n'
            || byte_value == '\r'
            || byte_value == '\f'
            || byte_value == '\v';
}

/* ===========================================================================
 * [2] TOKEN SCANNERS
 * ===========================================================================
 *
 *  Each scanner receives the buffer, its length, and the offset of the first
 *  byte of the token. Each returns the offset one past the end of the token.
 *  The caller has already determined which scanner applies by inspecting the
 *  first byte, so each scanner may assume its own first byte and is
 *  responsible only for finding where its token ends.
 *
 *  Longest run within a category : each scanner consumes the longest run that
 *  forms a single token of its own category, so "0x1p3" is one number and
 *  "project_lookup" is one identifier. This does not extend across punctuator
 *  bytes: ">>=" is three punctuator tokens, because merging them into one
 *  operator is a grammatical decision the scanner does not make (see the
 *  PUNCTUATOR note in the header).
 *
 * ===========================================================================*/

static size_t scan_identifier(const uint8_t *source_buffer,
                              size_t         source_length,
                              size_t         token_start)
{
        size_t cursor = token_start + 1;
        while (cursor < source_length
               && gate_byte_is_identifier_continue(source_buffer[cursor])) {
                cursor++;
        }
        return cursor;
}

/* ---------------------------------------------------------------------------
 *  Remark : a preprocessing number in C99 is a superset of valid numeric
 *  constants. It begins with a digit, or a period followed by a digit, and
 *  continues over digits, identifier characters, periods, and the two-
 *  character exponent sequences e+ e- p+ p-. The scanner captures this
 *  extent; it does not validate that the result is a well-formed constant,
 *  because validation is a semantic question and the scanner is lexical.
 * ---------------------------------------------------------------------------*/
static size_t scan_number(const uint8_t *source_buffer,
                          size_t         source_length,
                          size_t         token_start)
{
        size_t cursor = token_start + 1;
        while (cursor < source_length) {
                uint8_t byte_value = source_buffer[cursor];
                if (byte_value == 'e' || byte_value == 'E'
                 || byte_value == 'p' || byte_value == 'P') {
                        if (cursor + 1 < source_length
                            && (source_buffer[cursor + 1] == '+'
                             || source_buffer[cursor + 1] == '-')) {
                                cursor += 2;
                                continue;
                        }
                }
                if (gate_byte_is_identifier_continue(byte_value)
                 || byte_value == '.') {
                        cursor++;
                        continue;
                }
                break;
        }
        return cursor;
}

/* ---------------------------------------------------------------------------
 *  Remark : a string or character literal runs to the matching unescaped
 *  delimiter. A backslash escapes the next byte, including the delimiter and
 *  including a newline (line continuation inside the literal). If the closing
 *  delimiter is never found the token extends to end of buffer; the caller
 *  detects the unterminated literal by comparing the returned end against the
 *  buffer length, and the boundary of no later token is disturbed because
 *  there is no later token.
 * ---------------------------------------------------------------------------*/
static size_t scan_string_or_character_literal(const uint8_t *source_buffer,
                                               size_t         source_length,
                                               size_t         token_start)
{
        uint8_t delimiter = source_buffer[token_start];
        size_t  cursor    = token_start + 1;
        while (cursor < source_length) {
                uint8_t byte_value = source_buffer[cursor];
                if (byte_value == '\\') {
                        cursor += 2;
                        continue;
                }
                if (byte_value == delimiter) {
                        return cursor + 1;
                }
                cursor++;
        }
        return cursor;
}

static size_t scan_whitespace(const uint8_t *source_buffer,
                              size_t         source_length,
                              size_t         token_start)
{
        size_t cursor = token_start + 1;
        while (cursor < source_length
               && gate_byte_is_horizontal_or_vertical_space(
                          source_buffer[cursor])) {
                cursor++;
        }
        return cursor;
}

/* ---------------------------------------------------------------------------
 *  Remark : the caller reaches this scanner only after confirming the two
 *  bytes at token_start open a comment. A line comment runs to but not
 *  including the newline. A block comment runs through its closing star-slash;
 *  if unterminated it extends to end of buffer, detected the same way as an
 *  unterminated literal.
 * ---------------------------------------------------------------------------*/
static size_t scan_comment(const uint8_t *source_buffer,
                           size_t         source_length,
                           size_t         token_start)
{
        if (source_buffer[token_start + 1] == '/') {
                size_t cursor = token_start + 2;
                while (cursor < source_length
                       && source_buffer[cursor] != '\n') {
                        cursor++;
                }
                return cursor;
        }
        size_t cursor = token_start + 2;
        while (cursor + 1 < source_length) {
                if (source_buffer[cursor] == '*'
                 && source_buffer[cursor + 1] == '/') {
                        return cursor + 2;
                }
                cursor++;
        }
        return source_length;
}

/* ---------------------------------------------------------------------------
 *  Remark : a directive token is recognized only when the first non-space
 *  byte on a line is '#'. It runs to end of line, honoring backslash-newline
 *  continuation so a multi-line macro-ish directive on unpreprocessed input
 *  is captured as one token. On GCC-preprocessed input the only survivors are
 *  single-line line markers.
 * ---------------------------------------------------------------------------*/
static size_t scan_preprocessor_line(const uint8_t *source_buffer,
                                     size_t         source_length,
                                     size_t         token_start)
{
        size_t cursor = token_start + 1;
        while (cursor < source_length) {
                if (source_buffer[cursor] == '\\'
                    && cursor + 1 < source_length
                    && source_buffer[cursor + 1] == '\n') {
                        cursor += 2;
                        continue;
                }
                if (source_buffer[cursor] == '\n') {
                        break;
                }
                cursor++;
        }
        return cursor;
}

/* ---------------------------------------------------------------------------
 *  Definition : gate for the start of a directive. A '#' opens a directive
 *  token only if every byte before it on the current line is horizontal
 *  space. Scans backward to the preceding newline or buffer start.
 * ---------------------------------------------------------------------------*/
static int gate_hash_begins_line(const uint8_t *source_buffer,
                                 size_t         token_start)
{
        size_t cursor = token_start;
        while (cursor > 0) {
                uint8_t byte_value = source_buffer[cursor - 1];
                if (byte_value == '\n') {
                        return 1;
                }
                if (byte_value != ' ' && byte_value != '\t') {
                        return 0;
                }
                cursor--;
        }
        return 1;
}

/* ===========================================================================
 * [3] PUBLIC OPERATIONS
 * ===========================================================================*/

void lexical_scanner_initialize(LexicalScannerState *scanner_state,
                                const uint8_t       *source_buffer,
                                size_t               source_length)
{
        scanner_state->source_buffer       = source_buffer;
        scanner_state->source_length        = source_length;
        scanner_state->current_byte_offset  = 0;
}

int lexical_scanner_next_token(LexicalScannerState *scanner_state,
                               LexicalToken        *token_out)
{
        const uint8_t *source_buffer = scanner_state->source_buffer;
        size_t         source_length = scanner_state->source_length;
        size_t         token_start   = scanner_state->current_byte_offset;

        if (token_start >= source_length) {
                return 0;
        }

        uint8_t              first_byte = source_buffer[token_start];
        LexicalTokenCategory category;
        size_t               token_end;

        if (gate_byte_is_horizontal_or_vertical_space(first_byte)) {
                category  = LEXICAL_TOKEN_CATEGORY_WHITESPACE;
                token_end = scan_whitespace(source_buffer, source_length,
                                            token_start);
        } else if (first_byte == '#'
                   && gate_hash_begins_line(source_buffer, token_start)) {
                category  = LEXICAL_TOKEN_CATEGORY_PREPROCESSOR_LINE;
                token_end = scan_preprocessor_line(source_buffer,
                                                   source_length, token_start);
        } else if (first_byte == '/'
                   && token_start + 1 < source_length
                   && (source_buffer[token_start + 1] == '/'
                    || source_buffer[token_start + 1] == '*')) {
                category  = LEXICAL_TOKEN_CATEGORY_COMMENT;
                token_end = scan_comment(source_buffer, source_length,
                                         token_start);
        } else if (gate_byte_is_identifier_start(first_byte)) {
                category  = LEXICAL_TOKEN_CATEGORY_IDENTIFIER;
                token_end = scan_identifier(source_buffer, source_length,
                                            token_start);
        } else if (gate_byte_is_digit(first_byte)
                   || (first_byte == '.'
                       && token_start + 1 < source_length
                       && gate_byte_is_digit(source_buffer[token_start + 1]))) {
                category  = LEXICAL_TOKEN_CATEGORY_NUMBER;
                token_end = scan_number(source_buffer, source_length,
                                        token_start);
        } else if (first_byte == '"' || first_byte == '\'') {
                category  = LEXICAL_TOKEN_CATEGORY_STRING_OR_CHARACTER_LITERAL;
                token_end = scan_string_or_character_literal(
                                    source_buffer, source_length, token_start);
        } else {
                /* Any remaining printable byte is a punctuator. A byte that is
                 * none of the above and not printable is invalid; both consume
                 * exactly one byte so the boundary of the next token is never
                 * disturbed. The punctuator scanner is one byte because multi-
                 * byte operator recognition is a parser concern: the parser
                 * reads adjacent punctuator tokens and combines them, keeping
                 * the scanner free of the C operator table. */
                if (first_byte >= 0x21 && first_byte <= 0x7E) {
                        category = LEXICAL_TOKEN_CATEGORY_PUNCTUATOR;
                } else {
                        category = LEXICAL_TOKEN_CATEGORY_INVALID;
                }
                token_end = token_start + 1;
        }

        token_out->byte_offset_start = token_start;
        token_out->byte_offset_end   = token_end;
        token_out->category          = category;
        scanner_state->current_byte_offset = token_end;
        return 1;
}
