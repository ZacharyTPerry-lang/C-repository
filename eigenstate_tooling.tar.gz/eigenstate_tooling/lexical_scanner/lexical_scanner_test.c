/* Unit test for lexical_scanner. Verifies the two load-bearing invariants:
 * total coverage (concatenated token ranges reproduce the input exactly) and
 * correct classification of each category. Self-contained; links only the
 * scanner. */

#include "lexical_scanner.h"
#include <stdio.h>
#include <string.h>

static int failures = 0;

static const char *category_name(LexicalTokenCategory category)
{
        switch (category) {
        case LEXICAL_TOKEN_CATEGORY_IDENTIFIER:                 return "IDENTIFIER";
        case LEXICAL_TOKEN_CATEGORY_NUMBER:                     return "NUMBER";
        case LEXICAL_TOKEN_CATEGORY_STRING_OR_CHARACTER_LITERAL:return "LITERAL";
        case LEXICAL_TOKEN_CATEGORY_PUNCTUATOR:                 return "PUNCTUATOR";
        case LEXICAL_TOKEN_CATEGORY_WHITESPACE:                 return "WHITESPACE";
        case LEXICAL_TOKEN_CATEGORY_COMMENT:                    return "COMMENT";
        case LEXICAL_TOKEN_CATEGORY_PREPROCESSOR_LINE:          return "PREPROCESSOR";
        case LEXICAL_TOKEN_CATEGORY_INVALID:                    return "INVALID";
        }
        return "?";
}

/* Invariant 1: token ranges are contiguous, non-overlapping, and cover the
 * whole buffer. This is what makes the stream reconstruct the source. */
static void test_total_coverage(const char *label, const char *source)
{
        LexicalScannerState state;
        LexicalToken        token;
        size_t              expected_next = 0;
        size_t              length        = strlen(source);

        lexical_scanner_initialize(&state, (const uint8_t *)source, length);
        while (lexical_scanner_next_token(&state, &token)) {
                if (token.byte_offset_start != expected_next) {
                        printf("  FAIL [%s]: gap/overlap at %zu (expected %zu)\n",
                               label, token.byte_offset_start, expected_next);
                        failures++;
                        return;
                }
                if (token.byte_offset_end <= token.byte_offset_start) {
                        printf("  FAIL [%s]: empty token at %zu\n",
                               label, token.byte_offset_start);
                        failures++;
                        return;
                }
                expected_next = token.byte_offset_end;
        }
        if (expected_next != length) {
                printf("  FAIL [%s]: coverage ended at %zu, length %zu\n",
                       label, expected_next, length);
                failures++;
                return;
        }
        printf("  pass [%s]: total coverage\n", label);
}

/* Invariant 2: the first token of a snippet has the expected category and
 * exact span. */
static void test_first_token(const char          *label,
                             const char          *source,
                             LexicalTokenCategory expected_category,
                             size_t               expected_end)
{
        LexicalScannerState state;
        LexicalToken        token;

        lexical_scanner_initialize(&state, (const uint8_t *)source,
                                   strlen(source));
        if (!lexical_scanner_next_token(&state, &token)) {
                printf("  FAIL [%s]: no token produced\n", label);
                failures++;
                return;
        }
        if (token.category != expected_category
            || token.byte_offset_end != expected_end) {
                printf("  FAIL [%s]: got %s [0,%zu), expected %s [0,%zu)\n",
                       label, category_name(token.category),
                       token.byte_offset_end,
                       category_name(expected_category), expected_end);
                failures++;
                return;
        }
        printf("  pass [%s]: %s span [0,%zu)\n",
               label, category_name(expected_category), expected_end);
}

int main(void)
{
        printf("total-coverage tests:\n");
        test_total_coverage("function",
                "int project_lookup(int index) { return index + 1; }");
        test_total_coverage("literal-with-escape",
                "char c = '\\'' ; char *s = \"a\\\"b\";");
        test_total_coverage("block-comment",
                "int x /* mid */ = 3;");
        test_total_coverage("line-marker",
                "# 1 \"blake3.h\"\nint blake3_out_len;");
        test_total_coverage("unterminated-string",
                "char *s = \"no end");
        test_total_coverage("number-forms",
                "0x1p3 + 3.14e-2 + 42u;");

        printf("first-token tests:\n");
        test_first_token("identifier", "index;",
                         LEXICAL_TOKEN_CATEGORY_IDENTIFIER, 5);
        test_first_token("number-hex-float", "0x1p3 ",
                         LEXICAL_TOKEN_CATEGORY_NUMBER, 5);
        test_first_token("string", "\"abc\" ",
                         LEXICAL_TOKEN_CATEGORY_STRING_OR_CHARACTER_LITERAL, 5);
        test_first_token("line-marker", "# 1 \"x\"\n",
                         LEXICAL_TOKEN_CATEGORY_PREPROCESSOR_LINE, 7);
        test_first_token("block-comment", "/* hi */rest",
                         LEXICAL_TOKEN_CATEGORY_COMMENT, 8);
        test_first_token("single-punctuator", "+x",
                         LEXICAL_TOKEN_CATEGORY_PUNCTUATOR, 1);

        if (failures == 0) {
                printf("ALL SCANNER TESTS PASS\n");
                return 0;
        }
        printf("%d SCANNER TEST(S) FAILED\n", failures);
        return 1;
}
