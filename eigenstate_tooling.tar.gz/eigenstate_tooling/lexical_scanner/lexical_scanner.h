/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * lexical_scanner.h
 *
 * System        : Compile Time Token Rewriter tooling
 * Belongs to    : lexical_scanner (leaf module, no project dependencies)
 *
 * Purpose       : Convert a byte buffer of preprocessed C source into a flat
 *                 stream of tokens with exact source boundaries. This is the
 *                 single tokenization primitive shared by every consumer that
 *                 must reason about C text: the token rewriter and the static
 *                 analysis front end both build on it.
 *
 * Design        : Boundary-exact. Every token records the half-open byte range
 *                 [start, end) it occupies in the original buffer, so a
 *                 consumer can reconstruct the source verbatim by concatenating
 *                 ranges. No token is ever paraphrased, normalized, or
 *                 rewritten by the scanner; rewriting is a later pass that
 *                 operates on this stream. The scanner classifies, it does not
 *                 transform.
 *
 *                 Determinism : the classification of a byte range depends only
 *                 on the bytes, never on external state. The scanner holds no
 *                 symbol table and makes no decision that depends on the
 *                 meaning of a prior token. Meaning is assigned downstream.
 *
 * Portability   : C99. Freestanding-compatible: depends only on <stddef.h> and
 *                 <stdint.h>. No allocation inside the scanner; the caller owns
 *                 all storage. No I/O. No locale dependence: byte values are
 *                 interpreted as C source per the C99 lexical grammar, not per
 *                 the current locale.
 *
 * Table of contents:
 *   [1] TOKEN CATEGORY
 *   [2] TOKEN RECORD
 *   [3] SCANNER STATE
 *   [4] SCANNER OPERATIONS
 *
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

#ifndef LEXICAL_SCANNER_H
#define LEXICAL_SCANNER_H

#include <stddef.h>
#include <stdint.h>

/* ===========================================================================
 * [1] TOKEN CATEGORY
 * ===========================================================================
 *
 *  The classification assigned to each token. The category set is
 *  deliberately coarse: it is exactly what a file-scope declaration parser
 *  needs to recognize declarations and uses, and no finer. The scanner does
 *  not distinguish keywords from other identifiers, because whether an
 *  identifier is a type name is a downstream question that depends on the
 *  symbol table, not on the bytes.
 *
 * ===========================================================================*/

typedef enum LexicalTokenCategory {
        /* An identifier or keyword: [A-Za-z_][A-Za-z0-9_]*. Keyword-ness is
         * not decided here. */
        LEXICAL_TOKEN_CATEGORY_IDENTIFIER,

        /* A numeric constant, integer or floating, in any C99 form. The
         * scanner captures the full pp-number extent; it does not evaluate. */
        LEXICAL_TOKEN_CATEGORY_NUMBER,

        /* A character constant or string literal, including its delimiters and
         * any escape sequences, captured verbatim. */
        LEXICAL_TOKEN_CATEGORY_STRING_OR_CHARACTER_LITERAL,

        /* A single punctuator byte. Each punctuator byte is its own token:
         * ">>=" is three PUNCTUATOR tokens, not one. Combining adjacent
         * punctuators into a multi-byte operator is a grammatical act, not a
         * lexical one -- it depends on the C operator table, which is
         * knowledge the scanner deliberately does not hold. A consumer that
         * needs multi-byte operators reconstructs them from adjacent
         * single-byte punctuator tokens in its own parser. This keeps the
         * scanner free of any grammar that would tie it to a particular C
         * standard's operator set, so a new operator never changes the
         * scanner -- it is merely more adjacent punctuator bytes, which the
         * scanner already emits one at a time. */
        LEXICAL_TOKEN_CATEGORY_PUNCTUATOR,

        /* A run of whitespace, including newlines. Preserved rather than
         * discarded so the stream can reconstruct the source exactly. */
        LEXICAL_TOKEN_CATEGORY_WHITESPACE,

        /* A comment. Preprocessed input from GCC will normally have stripped
         * these to a single space, but the scanner recognizes them so it can
         * also operate on unpreprocessed source when a consumer requires it. */
        LEXICAL_TOKEN_CATEGORY_COMMENT,

        /* A preprocessing directive line beginning with '#'. On GCC-
         * preprocessed input the only directives that survive are line
         * markers (# linenum "file"); the scanner captures the whole line as
         * one token and does not interpret it. */
        LEXICAL_TOKEN_CATEGORY_PREPROCESSOR_LINE,

        /* A byte or byte sequence that is not a valid token under the C99
         * lexical grammar. Recorded rather than skipped so that malformed
         * input fails loudly and locally instead of shifting every subsequent
         * boundary. */
        LEXICAL_TOKEN_CATEGORY_INVALID
} LexicalTokenCategory;

/* ===========================================================================
 * [2] TOKEN RECORD
 * ===========================================================================
 *
 *  One token. The record is a classification plus a half-open byte range into
 *  the buffer the caller supplied. The scanner never copies token text; the
 *  bytes remain in the caller's buffer and the record points at them by
 *  offset. Offsets, not pointers, so a record survives the buffer being moved
 *  or serialized.
 *
 * ---------------------------------------------------------------------------
 *  byte_offset_start   inclusive start of the token in the source buffer
 *  byte_offset_end     exclusive end; token text is buffer[start .. end)
 *  category            the classification assigned to this range
 *
 *  Invariant : end > start for every token. The ranges of a token stream are
 *  contiguous and non-overlapping and cover the entire buffer: for adjacent
 *  tokens t[i] and t[i+1], t[i].byte_offset_end == t[i+1].byte_offset_start.
 *  Concatenating every token's range reproduces the input byte for byte.
 * ---------------------------------------------------------------------------*/

typedef struct LexicalToken {
        size_t               byte_offset_start;
        size_t               byte_offset_end;
        LexicalTokenCategory category;
} LexicalToken;

/* ===========================================================================
 * [3] SCANNER STATE
 * ===========================================================================
 *
 *  The scanner is a cursor over an immutable input buffer. All state is the
 *  buffer, its length, and the current read position. The caller creates the
 *  state, then drives it one token at a time. The scanner allocates nothing
 *  and frees nothing; when the caller is done it discards the state by letting
 *  it go out of scope.
 *
 * ---------------------------------------------------------------------------
 *  source_buffer         the bytes to scan; owned by the caller, not the
 *                        scanner; must outlive the scanner state
 *  source_length         number of bytes in source_buffer
 *  current_byte_offset   read cursor; advances by exactly one token per
 *                        successful call to lexical_scanner_next_token
 * ---------------------------------------------------------------------------*/

typedef struct LexicalScannerState {
        const uint8_t *source_buffer;
        size_t         source_length;
        size_t         current_byte_offset;
} LexicalScannerState;

/* ===========================================================================
 * [4] SCANNER OPERATIONS
 * ===========================================================================*/

/* ---------------------------------------------------------------------------
 *  Operation : lexical_scanner_initialize
 *
 *  Bind a scanner state to a source buffer and position the cursor at the
 *  first byte. Does not read the buffer; the first read happens on the first
 *  call to lexical_scanner_next_token.
 *
 *  IN  scanner_state   VALID  POPULATE  ALWAYS  KEEP  NONE  state to set up
 *  IN  source_buffer   VALID  CONSUME   ALWAYS  KEEP  NONE  bytes to scan;
 *                                                           must outlive state
 *  IN  source_length   VALID  CONSUME   ALWAYS  NONE  NONE  length of buffer
 * ---------------------------------------------------------------------------*/
void lexical_scanner_initialize(LexicalScannerState *scanner_state,
                                const uint8_t       *source_buffer,
                                size_t               source_length);

/* ---------------------------------------------------------------------------
 *  Operation : lexical_scanner_next_token
 *
 *  Classify the token beginning at the current cursor, write its record to
 *  token_out, and advance the cursor past it. Every byte of the input is
 *  covered by exactly one token across successive calls; whitespace and
 *  comments are returned as tokens, not skipped, so the caller that wants to
 *  ignore them does so explicitly.
 *
 *  Returns nonzero when a token was produced, zero when the cursor has reached
 *  the end of the buffer and no token remains. A zero return leaves token_out
 *  unmodified.
 *
 *  Remark : the scanner never reports failure by producing a partial or
 *  paraphrased token. A byte sequence that does not form a valid C99 token is
 *  returned as a single LEXICAL_TOKEN_CATEGORY_INVALID token covering the
 *  offending extent, so the boundary of every subsequent token is unaffected
 *  and the caller can locate the exact fault by byte offset.
 *
 *  IN   scanner_state  VALID    MUTATE    ALWAYS      KEEP  NONE  cursor to
 *                                                                 advance
 *  OUT  token_out      GARBAGE  POPULATE  IF_SUCCESS  KEEP  NONE  the token
 * ---------------------------------------------------------------------------*/
int lexical_scanner_next_token(LexicalScannerState *scanner_state,
                               LexicalToken        *token_out);

#endif /* LEXICAL_SCANNER_H */
