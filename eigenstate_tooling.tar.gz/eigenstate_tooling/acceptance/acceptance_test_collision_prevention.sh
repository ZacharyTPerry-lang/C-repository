#!/bin/sh
# ===========================================================================
# ACCEPTANCE TEST 1 : COLLISION PREVENTION (corrected to the proven design)
# ===========================================================================
#  Using a vendor is not a violation; the vendor include stays. An UNGUARDED
#  vendor macro that collides with a project identifier is the violation:
#  prefixing cannot fix an identifier collision, so the tool must DETECT it and
#  stop the build, naming the collision. A WHITELISTED collision crosses
#  deliberately and is permitted. "Prevention" = detect-and-refuse.
#  GCC is the oracle that the collision is real.
# ===========================================================================
set -u
TEST_ROOT="$(mktemp -d)"; trap 'rm -rf "$TEST_ROOT"' EXIT
TOOL="${COMPILE_TIME_TOKEN_REWRITER:-}"

mkdir -p "$TEST_ROOT/vendored_external_dependencies/collision_vendor"
cat > "$TEST_ROOT/vendored_external_dependencies/collision_vendor/collision_vendor.h" <<'FIX'
#ifndef COLLISION_VENDOR_H
#define COLLISION_VENDOR_H
#define index collision_vendor_internal_index
#endif
FIX
cat > "$TEST_ROOT/project_uses_index.c" <<'FIX'
static int project_lookup(int index)
{
        return index + 1;
}
FIX
cd "$TEST_ROOT" || exit 2

cat > control_probe.c <<'FIX'
#include "vendored_external_dependencies/collision_vendor/collision_vendor.h"
static int project_lookup(int index) { return index + 1; }
FIX
if gcc -E -P control_probe.c 2>/dev/null | grep -q 'collision_vendor_internal_index'; then
        printf 'CONTROL  : capture reproduced -- naive preprocess rewrote the identifier\n'
else
        printf 'CONTROL  : FAILED to reproduce capture\n'; exit 2
fi

if [ -z "$TOOL" ] || [ ! -x "$TOOL" ]; then
        printf 'TREATMENT: SKIP -- tool not built\n'; printf 'RESULT   : PENDING\n'; exit 1
fi
mkdir -p .intermediate

# sub-arm A: unguarded capture must be refused and named
UNGUARDED_STDERR="$("$TOOL" --project-root . \
        --vendor-root vendored_external_dependencies \
        --state STATE_C_ISOLATE --output .intermediate \
        project_uses_index.c 2>&1 >/dev/null)"
if [ $? -eq 0 ]; then
        printf 'TREATMENT: FAIL -- unguarded capture was allowed\n'; printf 'RESULT   : FAIL\n'; exit 1
fi
if printf '%s' "$UNGUARDED_STDERR" | grep -q 'index'; then
        printf 'TREATMENT: unguarded capture refused and named -- correct\n'
else
        printf 'TREATMENT: FAIL -- refused but did not name the collision\n'; printf 'RESULT   : FAIL\n'; exit 1
fi

# sub-arm B: whitelisted collision must be permitted
cat > crossing.whitelist <<'WL'
VENDOR_VALUE_SUPERSEDES(index)
WL
if "$TOOL" --project-root . \
        --vendor-root vendored_external_dependencies \
        --whitelist crossing.whitelist \
        --state STATE_C_ISOLATE --output .intermediate \
        project_uses_index.c >/dev/null 2>&1; then
        printf 'TREATMENT: whitelisted collision permitted -- correct\n'
        printf 'RESULT   : PASS\n'; exit 0
fi
printf 'TREATMENT: FAIL -- whitelisted collision was refused\n'; printf 'RESULT   : FAIL\n'; exit 1
