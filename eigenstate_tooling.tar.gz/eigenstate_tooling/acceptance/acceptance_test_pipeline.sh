#!/bin/sh
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# acceptance_test_pipeline.sh
#
# Endstate test for the three-stage pipeline, validated by the compiler itself:
# transform -> compile -> analyze. The decisive assertion is that GCC compiles
# the transformed .intermediate/ output cleanly -- a transform that renamed a
# macro definition out of step with its uses (or vice versa) would produce an
# undeclared-identifier error, so a clean compile proves the rename is
# self-consistent.
#
# This guards the end-to-end path that unit tests do not exercise: the actual
# tool binary driving the actual Makefile producing output the actual compiler
# accepts.
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
set -e

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "acceptance: three-stage pipeline (transform -> compile -> analyze)"

# ---- build the rewriter binary ----------------------------------------------
REWRITER="$WORK/rewriter"
gcc -std=c99 -Wall -Wextra -Werror -pedantic \
    -I"$ROOT/lexical_scanner" -I"$ROOT/symbol_set_from_object" \
    -I"$ROOT/parameter_contract_system" -I"$ROOT/boundary_crossing_system" \
    -I"$ROOT/compile_time_token_rewriter" \
    "$ROOT/lexical_scanner/lexical_scanner.c" \
    "$ROOT/symbol_set_from_object/symbol_set_from_object.c" \
    "$ROOT/parameter_contract_system/parameter_contract_vocabulary.c" \
    "$ROOT/parameter_contract_system/parameter_contract_recognizer.c" \
    "$ROOT/parameter_contract_system/parameter_contract_translator.c" \
    "$ROOT/boundary_crossing_system/boundary_crossing_vocabulary.c" \
    "$ROOT/boundary_crossing_system/boundary_crossing_enforcement.c" \
    "$ROOT/boundary_crossing_system/boundary_crossing_discovery.c" \
    "$ROOT/compile_time_token_rewriter/project_macro_set.c" \
    "$ROOT/compile_time_token_rewriter/project_identifier_set.c" \
    "$ROOT/compile_time_token_rewriter/vendor_macro_table.c" \
    "$ROOT/compile_time_token_rewriter/collision_detection.c" \
    "$ROOT/compile_time_token_rewriter/compile_time_token_rewriter.c" \
    "$ROOT/compile_time_token_rewriter/compile_time_token_rewriter_main.c" \
    -o "$REWRITER"

# ---- lay out a realistic project/vendor tree --------------------------------
mkdir -p "$WORK/source" "$WORK/vendor"
cat > "$WORK/source/hashing.c" <<'EOF'
#define HASHING_BLOCK_SIZE 64
int hashing_compute(int input) {
    int accumulator = input * HASHING_BLOCK_SIZE;
    return accumulator;
}
EOF
cat > "$WORK/source/storage.c" <<'EOF'
int storage_write(int value) {
    return value + 1;
}
EOF
cat > "$WORK/vendor/blake3.h" <<'EOF'
#ifndef BLAKE3_H
#define BLAKE3_H
#define BLAKE3_OUT_LEN 32
#endif
EOF
: > "$WORK/whitelist.txt"

# a stand-in analyzer so stage 3 has a command (the real one is separate)
cat > "$WORK/analyzer.sh" <<'EOF'
#!/bin/sh
echo "report for $1"
EOF
chmod +x "$WORK/analyzer.sh"

cp "$ROOT/source_transformation_pipeline.makefile" "$WORK/Makefile"

# ---- run the pipeline -------------------------------------------------------
make -C "$WORK" pipeline \
     ROOT_DIR="$WORK" \
     COMPILE_TIME_TOKEN_REWRITER="$REWRITER" \
     STATIC_ANALYZER="$WORK/analyzer.sh" \
     WHITELIST="$WORK/whitelist.txt" >/dev/null 2>&1

# ---- assertions -------------------------------------------------------------
fail=0

# stage 1: transformed files exist and the macro was renamed CONSISTENTLY
if [ -f "$WORK/.intermediate/hashing.c" ]; then
    defs=$(grep -c "define COMPILE_TIME_ENFORCEMENT_FRAMEWORK_HASHING_BLOCK_SIZE" "$WORK/.intermediate/hashing.c" || true)
    uses=$(grep -c "input \* COMPILE_TIME_ENFORCEMENT_FRAMEWORK_HASHING_BLOCK_SIZE" "$WORK/.intermediate/hashing.c" || true)
    if [ "$defs" = "1" ] && [ "$uses" = "1" ]; then
        echo "  PASS  stage 1: macro definition and use both prefixed (consistent)"
    else
        echo "  FAIL  stage 1: inconsistent prefixing (def=$defs use=$uses)"
        fail=1
    fi
else
    echo "  FAIL  stage 1: transformed file not produced"
    fail=1
fi

# stage 2: the transformed output COMPILED (the compiler is the oracle)
if [ -f "$WORK/build/hashing.o" ] && [ -f "$WORK/build/storage.o" ]; then
    echo "  PASS  stage 2: GCC compiled the transformed output cleanly"
else
    echo "  FAIL  stage 2: transformed output did not compile"
    fail=1
fi

# stage 3: analysis ran on the same .intermediate/
if [ -f "$WORK/analysis/hashing.report" ] && [ -f "$WORK/analysis/storage.report" ]; then
    echo "  PASS  stage 3: analysis ran on the intermediate tree"
else
    echo "  FAIL  stage 3: analysis reports not produced"
    fail=1
fi

# .intermediate/ persists as a tracked output (not deleted after build)
if [ -f "$WORK/.intermediate/vendor_macro_table.dump" ]; then
    echo "  PASS  tracked: .intermediate/ persisted after build"
else
    echo "  FAIL  tracked: .intermediate/ was not retained"
    fail=1
fi

if [ "$fail" = "0" ]; then
    echo "RESULT   : PASS"
    exit 0
fi
echo "RESULT   : FAIL"
exit 1
