#!/bin/sh
# ===========================================================================
# ACCEPTANCE TEST 2 : REVERSE DEPENDENCY (COMPELLED CROSSING)
# ===========================================================================
#
#  Defines "done" for the reverse-dependency problem (Primitive 3, link
#  stage). A vendor object genuinely demands a project symbol -- an unbound
#  external reference the linker will resolve against project code.
#
#  This crossing is compelled, not chosen: the vendor's compiled object
#  demands the symbol, and the modality is ERROR-on-absence. The tool must
#  discover the crossing from nm on the vendor object, then require it to be
#  declared in the whitelist. Undeclared -> build error naming the symbol.
#  Declared -> build proceeds.
#
#  The oracle is nm (the linker's own symbol table). The control arm shows
#  the vendor's undefined symbol is real. The treatment arm runs the tool
#  twice: once with no declaration (must error, naming the symbol), once with
#  the declaration present (must pass).
#
#  This test FAILS until the tool exists. That is intended: it is the target.
#
# ===========================================================================

set -u

TEST_ROOT="$(mktemp -d)"
trap 'rm -rf "$TEST_ROOT"' EXIT
TOOL="${COMPILE_TIME_TOKEN_REWRITER:-}"

# --- fixture -------------------------------------------------------------
mkdir -p "$TEST_ROOT/vendored_external_dependencies/reverse_vendor"
cat > "$TEST_ROOT/vendored_external_dependencies/reverse_vendor/reverse_vendor.c" <<'FIXTURE'
extern int project_allocator(unsigned long size);
int reverse_vendor_initialize(void)
{
        return project_allocator(64);
}
FIXTURE

cat > "$TEST_ROOT/project_provides_allocator.c" <<'FIXTURE'
int project_allocator(unsigned long size)
{
        return (int)size;
}
FIXTURE

cd "$TEST_ROOT" || exit 2

# --- control arm : prove the reverse dependency is real ---------------------
gcc -c vendored_external_dependencies/reverse_vendor/reverse_vendor.c \
        -o reverse_vendor.o 2>/dev/null
if nm reverse_vendor.o | grep -qE ' U project_allocator$'; then
        printf 'CONTROL  : reverse dependency reproduced -- vendor object demands project_allocator\n'
else
        printf 'CONTROL  : FAILED to reproduce reverse dependency -- fixture is wrong\n'
        exit 2
fi

# --- treatment arm ----------------------------------------------------------
if [ -z "$TOOL" ] || [ ! -x "$TOOL" ]; then
        printf 'TREATMENT: SKIP -- tool not built yet (set COMPILE_TIME_TOKEN_REWRITER)\n'
        printf 'RESULT   : PENDING -- this is the target, not yet met\n'
        exit 1
fi

# sub-arm A : undeclared crossing must ERROR, naming the symbol
cat > crossing_vocabulary_instance.whitelist <<'WHITELIST'
# no VENDOR_LINKS_PROJECT declaration -- the crossing is undeclared
WHITELIST

UNDECLARED_STDERR="$("$TOOL" \
        --project-root . \
        --vendor-root vendored_external_dependencies \
        --whitelist crossing_vocabulary_instance.whitelist \
        --state STATE_C_ISOLATE \
        --output .intermediate \
        project_provides_allocator.c 2>&1 >/dev/null)"
UNDECLARED_STATUS=$?

if [ "$UNDECLARED_STATUS" -eq 0 ]; then
        printf 'TREATMENT: FAIL -- undeclared reverse dependency was allowed\n'
        printf 'RESULT   : FAIL\n'
        exit 1
fi
if printf '%s' "$UNDECLARED_STDERR" | grep -q 'project_allocator'; then
        printf 'TREATMENT: undeclared crossing errored and named the symbol -- correct\n'
else
        printf 'TREATMENT: FAIL -- errored but did not name project_allocator\n'
        printf 'RESULT   : FAIL\n'
        exit 1
fi

# sub-arm B : declared crossing must PASS
cat > crossing_vocabulary_instance.whitelist <<'WHITELIST'
VENDOR_LINKS_PROJECT(project_allocator)
WHITELIST

if "$TOOL" \
        --project-root . \
        --vendor-root vendored_external_dependencies \
        --whitelist crossing_vocabulary_instance.whitelist \
        --state STATE_C_ISOLATE \
        --output .intermediate \
        project_provides_allocator.c >/dev/null 2>&1; then
        printf 'TREATMENT: declared crossing accepted -- correct\n'
        printf 'RESULT   : PASS\n'
        exit 0
fi

printf 'TREATMENT: FAIL -- declared crossing was rejected\n'
printf 'RESULT   : FAIL\n'
exit 1
