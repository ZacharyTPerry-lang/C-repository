# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# source_transformation_pipeline.makefile
#
# System     : Compile Time Token Rewriter tooling
# Belongs to : compile_time_macro_isolation
#
# The three-stage build the specification defines:
#
#   1. transform : project source        -> .intermediate/   (the rewriter)
#   2. compile   : .intermediate/         -> build/           (GCC)
#   3. analyze   : .intermediate/         -> analysis/        (static analysis)
#
# Compile and analysis both consume .intermediate/, so both see the same
# transformed source under the same configuration (move 3 of the soundness
# closure: analysis configuration equals build configuration).
#
# .intermediate/ is a REAL tracked output, not .PHONY. It is retained across
# builds (.SECONDARY) so the analyzer can read it and so rebuilds are
# incremental: a changed project source re-runs only its own file; a changed
# vendor header re-runs every transform, because the vendor macro table is a
# build-wide dependency.
#
# Include this fragment from the root Makefile, which owns all build knowledge.
# It expects ROOT_DIR to be set by the includer; it falls back to CURDIR.
#
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ROOT_DIR ?= $(CURDIR)

# ---- directory layout --------------------------------------------------------
PROJECT_SOURCE_DIR := $(ROOT_DIR)/source
VENDOR_DIR         := $(ROOT_DIR)/vendor
INTERMEDIATE_DIR   := $(ROOT_DIR)/.intermediate
BUILD_DIR          := $(ROOT_DIR)/build
ANALYSIS_DIR       := $(ROOT_DIR)/analysis

# ---- the tools (built elsewhere in the tree) ---------------------------------
COMPILE_TIME_TOKEN_REWRITER ?= $(ROOT_DIR)/compile_time_token_rewriter/compile_time_token_rewriter
STATIC_ANALYZER             ?= $(ROOT_DIR)/static_analysis/static_analyzer

CC     := gcc
CFLAGS := -std=c99 -Wall -Wextra -Werror -pedantic

# ---- the isolation state (one build-wide choice; State C is the default) -----
# A = project supersedes, B = vendor supersedes, C = full isolation.
ISOLATION_STATE ?= C
# inline validation of the state value (no silent acceptance of a bad state)
ifeq ($(filter $(ISOLATION_STATE),A B C),)
$(error ISOLATION_STATE must be one of A, B, C (got '$(ISOLATION_STATE)'))
endif

# ---- the whitelist (declared crossings) --------------------------------------
WHITELIST ?= $(ROOT_DIR)/compile_time_macro_isolation_whitelist.txt

# ---- file sets ---------------------------------------------------------------
PROJECT_SOURCES := $(wildcard $(PROJECT_SOURCE_DIR)/*.c)
VENDOR_HEADERS  := $(wildcard $(VENDOR_DIR)/*.h)

INTERMEDIATES := $(patsubst $(PROJECT_SOURCE_DIR)/%.c,$(INTERMEDIATE_DIR)/%.c,$(PROJECT_SOURCES))
OBJECTS       := $(patsubst $(PROJECT_SOURCE_DIR)/%.c,$(BUILD_DIR)/%.o,$(PROJECT_SOURCES))
REPORTS       := $(patsubst $(PROJECT_SOURCE_DIR)/%.c,$(ANALYSIS_DIR)/%.report,$(PROJECT_SOURCES))

# the vendor macro table: one artifact per build, a prerequisite of every
# transform. Extracted from the vendor headers' own preprocessing (gcc -dM -E),
# so it inherits completeness from the vendors' includes (P4).
VENDOR_MACRO_TABLE := $(INTERMEDIATE_DIR)/vendor_macro_table.dump

# ==============================================================================
# targets
# ==============================================================================

.PHONY: pipeline
pipeline: $(OBJECTS) $(REPORTS)
	@echo "pipeline complete (state $(ISOLATION_STATE)): $(words $(OBJECTS)) objects, $(words $(REPORTS)) reports"

# .intermediate/ files and the macro table must persist as tracked outputs;
# .SECONDARY stops Make from deleting them as chained intermediates while
# keeping them fully tracked (which .PHONY would not).
.SECONDARY: $(INTERMEDIATES) $(VENDOR_MACRO_TABLE)

# ---- pass 1: vendor macro extraction (once per build) ------------------------
$(VENDOR_MACRO_TABLE): $(VENDOR_HEADERS) | $(INTERMEDIATE_DIR)
	@echo "  [vendor-scan] $(words $(VENDOR_HEADERS)) headers -> $(notdir $@)"
	$(CC) -dM -E $(VENDOR_HEADERS) > $@

# ---- pass 2 / stage 1: transform --------------------------------------------
# each transformed file depends on its source AND the build-wide macro table,
# so a vendor change re-transforms everything and a source change re-transforms
# only itself. The rewriter takes --output as a DIRECTORY and writes
# <dir>/<basename> for each source, so the recipe passes the intermediate
# directory and Make tracks the per-file target the tool produces.
$(INTERMEDIATE_DIR)/%.c: $(PROJECT_SOURCE_DIR)/%.c $(VENDOR_MACRO_TABLE) $(WHITELIST) | $(INTERMEDIATE_DIR)
	@echo "  [transform]   $(notdir $<)"
	$(COMPILE_TIME_TOKEN_REWRITER) \
	    --project-root $(PROJECT_SOURCE_DIR) \
	    --vendor-root $(VENDOR_DIR) \
	    --whitelist $(WHITELIST) \
	    --state $(ISOLATION_STATE) \
	    --output $(INTERMEDIATE_DIR) \
	    $<

# ---- stage 2: compile from .intermediate/ ------------------------------------
$(BUILD_DIR)/%.o: $(INTERMEDIATE_DIR)/%.c | $(BUILD_DIR)
	@echo "  [compile]     $(notdir $<)"
	$(CC) $(CFLAGS) -c $< -o $@

# ---- stage 3: analyze the same .intermediate/ (same configuration) -----------
$(ANALYSIS_DIR)/%.report: $(INTERMEDIATE_DIR)/%.c | $(ANALYSIS_DIR)
	@echo "  [analyze]     $(notdir $<)"
	$(STATIC_ANALYZER) $< > $@

# ---- directory creation (order-only prerequisites) ---------------------------
$(INTERMEDIATE_DIR) $(BUILD_DIR) $(ANALYSIS_DIR):
	@mkdir -p $@

# ---- housekeeping ------------------------------------------------------------
.PHONY: clean
clean:
	@rm -rf $(INTERMEDIATE_DIR) $(BUILD_DIR) $(ANALYSIS_DIR)
	@echo "cleaned .intermediate/, build/, analysis/"

.PHONY: print-config
print-config:
	@echo "ROOT_DIR        = $(ROOT_DIR)"
	@echo "ISOLATION_STATE = $(ISOLATION_STATE)"
	@echo "project sources = $(words $(PROJECT_SOURCES))"
	@echo "vendor headers  = $(words $(VENDOR_HEADERS))"
	@echo "whitelist       = $(WHITELIST)"
